# Engineering IQ MCP Server

Engineering IQ includes a powerful Model Context Protocol (MCP) server that exposes Engineering IQ agents as tools and resources that can be used by MCP-compatible clients.

## What is MCP?

The Model Context Protocol (MCP) is a standard that enables communication between AI applications and external tools/resources. Engineering IQ's MCP server allows you to:

- Use Engineering IQ agents as tools in other MCP-compatible applications
- Access Engineering IQ capabilities from various AI clients
- Integrate Engineering IQ into existing workflows and automation

## Quick Start

### Starting the MCP Server

```bash
# Quick start with default settings
eiq server

# Or with custom options
eiq dev_server --port 8000 --host localhost --log-level info

# Start with debug mode
eiq server --debug
```

### CLI Options

The Engineering IQ CLI provides convenient shortcuts for starting the MCP server:

| Command | Description |
|---------|-------------|
| `eiq server` | Shortest command (alias) |
| `eiq dev_server` | Short command with full options |
| `engineering_iq server` | Full command alias for dev_server |
| `engineering_iq dev_server` | Full MCP server with all options |

### Available Options

```bash
engineering_iq dev_server --help
```

**Options:**
- `--port, -p`: Port to run the server on (default: 8000)
- `--host, -h`: Host to bind the server to (default: localhost)
- `--log-level, -l`: Log level (critical, error, warning, info, debug, trace)
- `--debug, -d`: Enable debug mode (sets log level to debug)

## Available Tools

The MCP server exposes the following Engineering IQ agents as tools:

### Analysis Planners
- **ProductAnalysisPlannerAgent** - Creates business analysis plans
- **DevAnalysisPlannerAgent** - Creates technical development analysis plans
- **DevSecOpsAnalysisPlannerAgent** - Creates security and operations analysis plans
- **QEAnalysisPlannerAgent** - Creates quality engineering analysis plans
- **FeatureAnalysisPlannerAgent** - Creates feature-specific analysis plans

Each tool provides:
- **Input**: Analysis requirements and context
- **Output**: Structured analysis plan with specific tasks and approaches

### Example Tool Usage

When connected to an MCP client, you can use these tools like:

```
Use ProductAnalysisPlannerAgent to analyze the business requirements for an e-commerce platform
```

The tool will return a structured plan including:
- Analysis objectives
- Required information gathering steps
- Specific areas to examine
- Recommended follow-up actions

## Available Prompts

The MCP server also provides pre-configured prompts:

### DB2 Analysis Changes
- **Name**: `run_db2_analysis_changes`
- **Description**: Run analysis changes for DB2 to MQ migration
- **Use Case**: Automated migration assistance

## Configuration

### Basic Configuration

The MCP server uses the same configuration as other Engineering IQ components. Create a `config.yaml`:

```yaml
app:
  default_model: gemini-2.0-flash-exp
  git_dir: workdir/repos
  
# Optional MCP server specific settings
mcp_server:
  default_port: 8000
  default_host: localhost
  default_log_level: info
```

### Advanced Configuration

```yaml
# Configure specific models for MCP tools
dev_analysis_planner:
  model: claude-3-5-sonnet-latest

product_analysis_planner:
  model: gemini-2.0-flash-exp

# Memory and performance settings
app:
  memory_optimization: true
  chunk_size: 50000
  max_file_size: 10485760
```

## Integration Examples

### Using with Claude Desktop

1. Start the Engineering IQ MCP server:
```bash
engineering_iq server --port 8000
```

2. Configure Claude Desktop to connect to the MCP server:
```json
{
  "mcpServers": {
    "engineering-iq": {
      "command": "curl",
      "args": ["http://localhost:8000"]
    }
  }
}
```

### Using with Other MCP Clients

The Engineering IQ MCP server is compatible with any MCP client. Common integration patterns:

1. **Development Tools**: Integrate with IDEs and development environments
2. **CI/CD Pipelines**: Automated code analysis in build processes
3. **Documentation Systems**: Automated documentation generation
4. **Project Management**: Integration with planning and tracking tools

## Architecture

### Server Components

```
Engineering IQ MCP Server
├── FastMCP Framework
├── Agent Registry
│   ├── Analysis Planners
│   └── Tool Wrappers
├── Prompt Registry
└── Session Management
```

### Agent Lifecycle

1. **Initialization**: Agents are loaded with required services
2. **Registration**: Each agent is registered as an MCP tool
3. **Execution**: Tools are called via MCP protocol
4. **Response**: Results are returned in structured format

### Service Dependencies

The MCP server initializes with:
- **Memory Service**: InMemoryMemoryService for agent state
- **Session Service**: InMemorySessionService for user sessions
- **Artifact Service**: InMemoryArtifactService for file handling

## Monitoring and Logging

### Log Levels

- **Critical**: System failures
- **Error**: Agent execution errors
- **Warning**: Performance or configuration issues
- **Info**: General operational information
- **Debug**: Detailed execution information
- **Trace**: Complete request/response logging

### Example Monitoring

```bash
# Start with debug logging
engineering_iq server --log-level debug

# Monitor logs in real-time
tail -f logs/engineering_iq.log
```

### Performance Monitoring

The server provides insights into:
- Agent execution times
- Memory usage patterns
- Request/response sizes
- Error rates and types

## Troubleshooting

### Common Issues

| Issue | Solution |
|-------|----------|
| Port already in use | Change port with `--port` option |
| Agent loading errors | Check Python environment and dependencies |
| Memory issues | Reduce `chunk_size` in configuration |
| Slow responses | Enable `memory_optimization` |

### Debug Mode

Enable debug mode for detailed troubleshooting:

```bash
engineering_iq server --debug
```

This provides:
- Detailed agent execution logs
- Request/response tracing
- Performance metrics
- Error stack traces

### Network Issues

If clients can't connect:

1. Check firewall settings
2. Verify host/port configuration
3. Test connectivity: `curl http://localhost:8000/health`

## Advanced Usage

### Custom Tool Development

You can extend the MCP server with custom tools. The `initialize_mcp_server` function would now be located within the new `engineering_iq/shared/mcp/` directory, likely in a file such as `dev_server.py` or a similar central script.

```python
from engineering_iq.shared.mcp.dev_server import initialize_mcp_server # Path updated

# Get the MCP instance
mcp = initialize_mcp_server()

# Add custom tool
@mcp.add_tool
def custom_analysis_tool(code_path: str) -> str:
    """Custom code analysis tool"""
    # Your custom logic here
    return "Analysis results"
```

### Batch Processing

For large-scale analysis:

```python
# Configure for batch processing
app:
  batch_mode: true
  max_concurrent_agents: 5
  timeout_seconds: 300
```

### Integration with External Systems

The MCP server can be integrated with:
- **Jira**: Automated ticket creation
- **Git**: Repository analysis triggers
- **CI/CD**: Build-time code analysis
- **Monitoring**: Integration with observability tools

## Security Considerations

### Network Security
- Run on localhost for development
- Use proper network security for production
- Consider authentication for external access

### Data Security
- Agents process code in memory
- No persistent storage of analyzed code
- Configure appropriate log levels for sensitive data

### Access Control
- MCP server runs with user permissions
- Agents inherit file system access
- Consider containerization for production use

## Performance Optimization

### Memory Management
```yaml
app:
  memory_optimization: true
  gc_threshold: 1000
  max_memory_mb: 4096
```

### Concurrent Processing
```yaml
mcp_server:
  max_workers: 4
  request_timeout: 60
  keep_alive_timeout: 30
```

### Caching
```yaml
app:
  enable_caching: true
  cache_ttl_seconds: 3600
  max_cache_size_mb: 512
```

## API Reference

### Health Check
- **Endpoint**: `/health`
- **Method**: GET
- **Response**: Server status and agent information

### Metrics
- **Endpoint**: `/metrics`
- **Method**: GET
- **Response**: Performance and usage metrics

### Tool Information
- **Endpoint**: `/tools`
- **Method**: GET
- **Response**: Available tools and their descriptions

## Best Practices

### Development
1. Start with debug mode during development
2. Use appropriate log levels for different environments
3. Monitor memory usage with large codebases
4. Test tools individually before integration

### Production
1. Use stable log levels (info or warning)
2. Implement proper monitoring and alerting
3. Configure resource limits appropriately
4. Plan for horizontal scaling if needed

### Integration
1. Handle tool failures gracefully
2. Implement timeout handling
3. Cache results when appropriate
4. Use batch processing for large-scale analysis

## Migration from Direct Agent Usage

If you're currently using Engineering IQ agents directly, migrating to the MCP server provides:

### Benefits
- **Standardized Interface**: Use MCP protocol for consistent access
- **Client Compatibility**: Work with any MCP-compatible client
- **Network Access**: Remote access to Engineering IQ capabilities
- **Protocol Benefits**: Leverage MCP's built-in features

### Migration Steps
1. **Assessment**: Identify current agent usage patterns
2. **Configuration**: Set up MCP server configuration
3. **Client Setup**: Configure MCP client connections
4. **Testing**: Verify functionality through MCP interface
5. **Deployment**: Roll out MCP-based integration

### Compatibility
- All existing agent functionality available through MCP
- Same configuration options and models supported
- Identical analysis output and quality
- Full feature parity with direct agent usage
