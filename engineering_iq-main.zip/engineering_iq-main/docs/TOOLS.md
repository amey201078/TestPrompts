# Engineering IQ Tools Reference

This document provides a comprehensive overview of all tools available in Engineering IQ, their capabilities, and usage patterns.

## Table of Contents
- [Overview](#overview)
- [File Tools](#file-tools)
- [Data Analysis Tools](#data-analysis-tools)
- [Language Server Protocol (LSP) Tools](#language-server-protocol-lsp-tools)
- [Specialized Tools](#specialized-tools)
- [Tool Collections](#tool-collections)
- [Best Practices](#best-practices)

## Overview

Engineering IQ provides a rich set of tools that enable agents to perform various tasks including file operations, code analysis, data processing, and external integrations. Tools are organized into logical groups and can be imported individually or as collections.

## File Tools

### Smart File Tools
Located in `engineering_iq/shared/tools/file_tool/`

The smart file tools, organized within the `file_tool` directory, provide memory-safe file operations with automatic token management and usage guidance. These tools are structured into modules for reading (`read_tools.py`, `read_functions.py`) and writing (`write_tools.py`, `write_functions.py`).

#### Core Functions:
- **smart_file_read_tool**: Read files with automatic truncation and memory management
- **smart_file_list_tool**: List directory contents with limits and filtering
- **smart_file_write_tool**: Write files with backup and validation
- **smart_file_search_tool**: Search for patterns across multiple files
- **regex_replace_tool**: Find and replace using regular expressions
- **file_validation_tool**: Validate file existence and properties
- **multiple_file_validation_tool**: Batch validation for multiple files

#### Key Features:
- **Automatic Token Limits**: Default 8000 token limit for reads, configurable
- **Memory Management**: Built-in truncation with clear indicators
- **Usage Guidance**: Automatic hints to help LLMs use tools effectively
- **Safety Features**: Backup creation, validation, error handling
- **Pattern Matching**: Support for file patterns (*.py, *.{ts,tsx}, etc.)
- **File Validation**: Comprehensive file existence and property validation

#### File Validation Tools
Located in `engineering_iq/shared/tools/file_tool/validation_functions.py` and `validation_tools.py`

Provides robust file validation capabilities for ensuring file existence and checking file properties before performing operations.

**Core Functions:**
- **validate_file_exists()**: Validate single file existence with detailed property checking
- **validate_multiple_files()**: Batch validation for multiple files with comprehensive reporting

**Key Capabilities:**
- **Existence Validation**: Check if files or directories exist at specified paths
- **Type Detection**: Distinguish between files, directories, and other path types
- **Property Checking**: Validate file size, readability, and writability permissions
- **Batch Operations**: Validate multiple files in a single operation
- **Detailed Reporting**: Structured response with comprehensive file information
- **Error Handling**: Graceful handling of permission errors and invalid paths

**Response Structure:**
The validation tools return `FileValidationResponse` objects containing:
- `file_path`: Path to the validated file
- `exists`: Boolean indicating file existence
- `is_file`: Whether the path points to a file
- `is_directory`: Whether the path points to a directory
- `size_bytes`: File size in bytes (if accessible)
- `readable`: File read permissions status
- `writable`: File write permissions status
- `message`: Human-readable validation result

**Usage Examples:**
```python
from engineering_iq.shared.tools.file_tool.validation_functions import validate_file_exists, validate_multiple_files

# Single file validation
result = await validate_file_exists(
    tool_context=context,
    file_path="config.json",
    check_readable=True,
    check_writable=False
)

# Multiple file validation
files = ["src/main.py", "README.md", "package.json"]
results = await validate_multiple_files(
    tool_context=context,
    file_paths=files,
    check_readable=True
)

# Check validation results
for result in results:
    if result.exists and result.is_file:
        print(f"✓ {result.file_path} - {result.size_bytes} bytes")
    else:
        print(f"✗ {result.message}")
```

#### Example Usage:
```python
from engineering_iq.shared.tools.file_tool.read_tools import smart_file_read_tool # Example, actual imports might vary
from engineering_iq.shared.tools.file_tool.write_tools import smart_file_write_tool # Example
from engineering_iq.shared.tools.file_tool.validation_tools import file_validation_tool # Example
# Note: The exact import for a collection like 'smart_file_tools' needs verification based on the new structure.
# For now, we'll assume specific tools are imported or a new collection is defined in an __init__.py.
# from engineering_iq.shared.tools.file_tool import smart_file_tools # If a collection is still provided

class MyAgent(EngineeringIQAgent):
    def _init_tools(self):
        self.add_tools(smart_file_tools)
        self.add_tools(validation_tools)
```

### Traditional File Tools
Individual file operation functions for specific use cases.

## Data Analysis Tools

### Structured Data Tools
Located in `engineering_iq/shared/tools/structured_data_tool/`

This suite of tools provides capabilities for working with various structured data formats, including JSON, Excel, and XML.

#### JSON Analyzer Tools
Located in `engineering_iq/shared/tools/structured_data_tool/json_tool/` (formerly `engineering_iq/shared/tools/json_analyzer.py`)

Comprehensive JSON file analysis and manipulation capabilities.

#### Functions (8 total):

**Basic Operations:**
- **read_json()**: Read and parse JSON files with encoding support
- **validate_json()**: Check JSON syntax and structure validity
- **get_json_stats()**: Generate comprehensive statistics about JSON files
- **get_json_structure()**: Analyze JSON schema and structure with depth control

**Querying and Filtering:**
- **query_json_path()**: JSONPath querying with jsonpath-ng support + fallback
- **filter_json()**: Filter data based on a single key-value pair with recursive search
- **extract_values_by_key()**: Extract all values for specific keys across nested structures

**Comparison:**
- **compare_json_files()**: Deep comparison between two JSON files with detailed difference tracking

#### Key Features:
- **JSONPath Support**: Advanced querying with graceful fallback to simple queries
- **Recursive Analysis**: Deep structure analysis and filtering
- **Encoding Flexibility**: Support for different file encodings
- **Comprehensive Comparison**: Detailed difference tracking with path information
- **Memory Efficient**: Appropriate handling of large JSON files

#### Example Usage:
```python
from engineering_iq.shared.tools.structured_data_tool.json_tool import all_json_tools # Example, verify actual collection name

# Query JSON data
result = query_json_path("config.json", "$.database.connections[*].host")

# Filter JSON data by single key-value pair
filtered = filter_json("config.json", "environment", "production")

# Compare two configuration files
diff = compare_json_files("config-dev.json", "config-prod.json")
```

#### Excel Analyzer Tools
Located in `engineering_iq/shared/tools/structured_data_tool/excel_tool/` (formerly `engineering_iq/shared/tools/excel_analyzer.py`)

Advanced Excel file analysis for business data processing.

#### Functions (10 total):

**File Operations:**
- **read_excel()**: Read Excel files (single/multiple sheets) with data conversion
- **list_sheets()**: Get all sheet names in a workbook
- **get_excel_summary()**: Complete file overview with dimensions, columns, and data types
- **get_excel_stats()**: File statistics including row counts, sizes, and sheet info

**Data Analysis:**
- **query_excel()**: Pandas query syntax for complex data filtering
- **filter_excel()**: Simple single column-value filtering across sheets
- **analyze_column_data()**: Deep statistical analysis for numeric and text columns
- **search_excel_content()**: Full-text search across sheets with match details

**Comparison and Quality:**
- **find_duplicates()**: Duplicate row detection with comma-separated column specification
- **compare_excel_sheets()**: Compare sheets within the same file

#### Key Features:
- **Multi-Sheet Support**: All functions work across multiple sheets
- **Statistical Analysis**: Comprehensive stats for numeric and text data
- **Advanced Querying**: Pandas query syntax support for complex operations
- **Data Quality**: Duplicate detection and data validation
- **Business Intelligence**: Column analysis, trends, and data profiling

#### Example Usage:
```python
from engineering_iq.shared.tools.structured_data_tool.excel_tool import all_excel_tools # Example, verify actual collection name

# Analyze sales data
stats = analyze_column_data("sales.xlsx", "revenue", "Q1_Data")

# Filter data by single column value
filtered = filter_excel("sales.xlsx", "region", "North", "Q1_Data")

# Find data quality issues (comma-separated column names)
duplicates = find_duplicates("customer_data.xlsx", "Sheet1", "email,phone")

# Compare quarterly reports
comparison = compare_excel_sheets("annual_report.xlsx", "Q1", "Q2")
```

#### XML Tools
Located in `engineering_iq/shared/tools/structured_data_tool/xml_tool/` (formerly `engineering_iq/shared/tools/xml_tool.py`)

XML parsing, querying, and analysis capabilities.

#### Key Functions:
- **read_xml()**: Parse XML files with namespace support
- **query_xml_xpath()**: XPath querying with lxml support
- **get_xml_structure()**: Analyze XML schema and hierarchy
- **validate_xml()**: XML well-formedness validation
- **find_elements_by_tag()**: Locate elements by tag name
- **filter_xml_by_attribute()**: Filter elements by attribute values

## Language Server Protocol (LSP) Tools

### LSP Tool Collection
Located in `engineering_iq/shared/tools/lsp_tool/`

Provides code intelligence capabilities through Language Server Protocol integration. The tools are organized within the `lsp_tool` directory.

#### Core Capabilities:
- **Symbol Resolution**: Find definitions, references, and implementations
- **Code Navigation**: Go-to-definition, find-references across projects
- **Semantic Analysis**: Type information, documentation, and code structure
- **Multi-Language Support**: Works with any language that has an LSP server

#### Key Functions:
- **find_symbols()**: Locate symbols (functions, classes, variables) in code
- **get_definition()**: Get symbol definitions and locations
- **find_references()**: Find all references to a symbol
- **get_hover_info()**: Get documentation and type information
- **workspace_symbols()**: Search symbols across entire workspace

#### Example Usage:
```python
from engineering_iq.shared.tools.lsp_tool.lsp_tools import all_lsp_tools # Example, verify actual collection name

# Find all function definitions
symbols = find_symbols("src/", symbol_type="function")

# Get detailed information about a class
definition = get_definition("MyClass", "src/models.py")
```

## Specialized Tools

### Document Tools
Located in `engineering_iq/shared/tools/document_tool/`

Provides capabilities for processing and extracting information from various document formats (e.g., PDF, DOCX). Organized within the `document_tool` directory, with core logic in `document_functions.py` and tool definitions in `document_tools.py`.

#### Potential Capabilities (Illustrative):
- **read_document_text()**: Extract raw text content from documents.
- **get_document_metadata()**: Retrieve metadata like author, creation date, etc.
- **search_in_document()**: Find specific text or patterns within a document.
- **convert_document_format()**: Convert documents between supported formats.

#### Example Usage:
```python
# from engineering_iq.shared.tools.document_tool import all_document_tools # Example, verify collection

# text = read_document_text("report.pdf")
# metadata = get_document_metadata("specification.docx")
```

### Git Tools
Located in `engineering_iq/shared/tools/git_tool/`

Git repository analysis and manipulation. Tools are organized within the `git_tool` directory (e.g., `read_tools.py`, `write_tools.py`).

#### Functions:
- **get_git_status()**: Repository status and changed files
- **get_commit_history()**: Commit logs with filtering options
- **analyze_file_changes()**: Detailed diff analysis
- **get_branch_info()**: Branch structure and relationships

### Exit Loop Tool
Located in `engineering_iq/shared/tools/exit_loop.py`

Control flow management for loop agents.

#### Function:
- **exit_loop()**: Signal completion and exit from agent loops

## Tool Collections

### Pre-defined Collections
Tools are often organized into collections (e.g., a list of tool functions) within the `__init__.py` or a central tools file of their respective directories for easy bulk import. The exact names of these collections (`all_json_tools`, `smart_file_tools`, etc.) and their import paths should be verified from the source code.

```python
# File operations
# Example: from engineering_iq.shared.tools.file_tool import smart_file_tools 
#   or from engineering_iq.shared.tools.file_tool.read_tools import smart_file_read_tool, ...

# Structured Data Tools
# Example: from engineering_iq.shared.tools.structured_data_tool.json_tool import all_json_tools
# Example: from engineering_iq.shared.tools.structured_data_tool.excel_tool import all_excel_tools
# Example: from engineering_iq.shared.tools.structured_data_tool.xml_tool import all_xml_tools 

# LSP capabilities
# Example: from engineering_iq.shared.tools.lsp_tool.lsp_tools import all_lsp_tools

# Git tools
# Example: from engineering_iq.shared.tools.git_tool import all_git_tools 

# Document tools
# Example: from engineering_iq.shared.tools.document_tool import all_document_tools
```

### Agent Tool Integration
Most analysis agents automatically include these tool collections:

```python
class AnalysisAgent(EngineeringIQAgent):
    def _init_tools(self):
        # Core file operations
        self.add_tools(smart_file_tools)
        
        # Code analysis
        self.add_tools(all_lsp_tools)
        
        # Data analysis
        self.add_tools(all_json_tools)
        self.add_tools(all_excel_tools)
```

## Best Practices

### Memory Management
1. **Use Smart File Tools**: They include automatic memory management
2. **Set Appropriate Limits**: Use token limits based on your use case
3. **Check Truncation**: Always verify if content was truncated
4. **Optimize Context**: Use context optimizer when approaching limits

### Data Analysis Workflow
1. **Start with Statistics**: Use get_*_stats() to understand data size and structure
2. **Structure Analysis**: Use get_*_structure() for schema understanding
3. **Targeted Queries**: Use specific query functions for data extraction
4. **Validation**: Use validation functions to ensure data quality

### Error Handling
1. **Check Return Types**: Tools return either data or error strings
2. **Validate Inputs**: Ensure file paths and parameters are correct
3. **Handle Encoding**: Specify encoding when working with non-UTF8 files
4. **Graceful Degradation**: Have fallbacks for optional dependencies

### Performance Optimization
1. **Use Appropriate Tools**: Choose the right tool for the task
2. **Limit Scope**: Use filters and limits to reduce processing
3. **Batch Operations**: Group related operations when possible
4. **Cache Results**: Store results of expensive operations

### Security Considerations
1. **Validate Paths**: Ensure file paths are within expected directories
2. **Sanitize Inputs**: Validate query parameters and search terms
3. **Limit Access**: Use appropriate file permissions
4. **Backup Important Data**: Use backup features when modifying files

## Tool Development Guidelines

### Creating New Tools
1. **Follow Patterns**: Use existing tools as templates
2. **Memory Safety**: Include automatic token management
3. **Error Handling**: Provide clear error messages
4. **Documentation**: Include comprehensive docstrings
5. **Type Hints**: Use full type annotations

### Testing Tools
1. **Unit Tests**: Test individual functions thoroughly
2. **Integration Tests**: Test tool combinations
3. **Edge Cases**: Test with large files, edge cases, malformed data
4. **Performance Tests**: Verify memory and speed characteristics

## Troubleshooting

### Common Issues
1. **File Not Found**: Verify file paths are correct and accessible
2. **Memory Errors**: Use smaller token limits or context optimization
3. **Encoding Issues**: Specify correct file encoding
4. **Permission Errors**: Check file and directory permissions
5. **JSON/XML Parse Errors**: Validate file format and syntax

### Debug Logging
Enable debug logging to trace tool execution:

```yaml
logger:
  level: DEBUG
  handlers:
    - sink: stdout
      level: DEBUG
```

### Performance Monitoring
Monitor tool performance and memory usage:
- Check file sizes before processing
- Monitor token consumption
- Use profiling for slow operations
- Track memory usage patterns

## Future Enhancements

### Implemented Tools (Formerly Future Enhancements)
- **Document Tools**: PDF, Word, and other document format support is now available through `engineering_iq/shared/tools/document_tool/`.

### Planned Additions
- **Database Tools**: Direct database query and analysis capabilities
- **API Tools**: REST API interaction and data fetching
- **Visualization Tools**: Chart and graph generation from data
- **Machine Learning Tools**: Basic ML analysis and pattern detection

### Extension Points
- **Custom Analyzers**: Framework for domain-specific analysis tools
- **Plugin Architecture**: Support for external tool plugins
- **Performance Profiling**: Built-in performance monitoring
- **Advanced Querying**: SQL-like query language for data tools

For the latest updates and additional tools, check the Engineering IQ repository and documentation.
