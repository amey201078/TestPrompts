# Engineering IQ Troubleshooting Guide

This guide helps you resolve common issues when using Engineering IQ.

## Table of Contents
- [Common Issues](#common-issues)
- [Agent-Specific Issues](#agent-specific-issues)
- [Configuration Issues](#configuration-issues)
- [Performance Issues](#performance-issues)
- [Integration Issues](#integration-issues)
- [Debugging Techniques](#debugging-techniques)

## Common Issues

### Installation Problems

| Issue | Solution |
|-------|----------|
| `ModuleNotFoundError: No module named 'engineering_iq'` | Ensure installation completed successfully. Try reinstalling. |
| LSP installation fails on Windows | Skip LSP - use `pip install engineering_iq` without `[lsp]` |
| Permission denied errors | Use virtual environment or `pip install --user` |
| Git URL not accessible | Check VPN/network access to Accenture repository |
| Dependency conflicts | Create fresh virtual environment |

### Runtime Errors

| Issue | Solution |
|-------|----------|
| 400 errors with function names | Shorten agent and function names to stay under 64 characters total |
| 500 errors from Google APIs | Close error dialog and type "continue" in web interface, or add retry logic |
| Context window exceeded | Use `optimized_memory` tool to reduce context size |
| "NoneType and str" error | Check for None values in string concatenation operations |

## Agent-Specific Issues

### File Access Issues

**Problem**: Agent returns "I can't access that file"

**Solutions**:
1. Verify the file path is correct
2. Check path is relative to working directory
3. Ensure file permissions allow reading
4. Use forward slashes in paths, even on Windows

### Git Helper Issues

**Problem**: Git Helper fails to clone repository

**Solutions**:
1. Verify repository URL is correct
2. Check authentication credentials
3. Ensure network connectivity
4. For private repos, set up SSH keys or access tokens

```bash
# Test git access
git ls-remote https://github.com/example/repo.git

# For SSH issues
ssh -T git@github.com
```

### Code Analysis Issues

**Problem**: Code Understanding agent can't find symbols

**Solutions**:
1. Ensure analyzing a properly structured codebase
2. Check that LSP is installed (if using)
3. Verify language is supported
4. Try using file search tools instead

### Analysis Workflow Issues

**Problem**: Analysis workflow breaks or stops

**Solutions**:
1. Check task file paths are correct
2. Ensure previous steps completed successfully
3. Look for error messages in task files
4. Restart from the last successful checkpoint

### Report Generation Issues

**Problem**: Report generation stops unexpectedly

**Solution**: Restart using existing task file:
```
User: Continue analysis using /path/to/ANALYSIS_TASKS.md
Analyzer: [Resumes from last checkpoint]
```

## Configuration Issues

### Settings Not Applied

**Problem**: Configuration changes don't take effect

**Solutions**:
1. Check configuration hierarchy (env vars > local config > defaults)
2. Verify YAML syntax is correct
3. Ensure proper indentation
4. Restart web interface

**Debug configuration loading**:
```python
from engineering_iq.shared.core.settings import app_settings
print(f"Current model: {app_settings.default_model}")
print(f"Git directory: {app_settings.git_dir}")
```

### Model Configuration Issues

**Problem**: Model not found or authentication errors

**Solutions**:
1. Verify model name format (use `LiteLlm:` prefix for non-Google models)
2. Check API keys are set correctly
3. Ensure model name matches provider's naming

```bash
# Check environment variables
echo $ANTHROPIC_API_KEY
echo $OPENAI_API_KEY
```

### MCP Server Issues

**Problem**: Jira or other MCP integrations not working

**Solutions**:
1. Verify MCP server is running
2. Check SSE URL is correct
3. Ensure network connectivity
4. Review MCP server logs

## Performance Issues

### Slow Analysis

**Problem**: Analysis takes too long

**Solutions**:
1. Use faster models for simple tasks
2. Reduce context window size
3. Process files in smaller batches
4. Enable parallel processing where possible

```yaml
# Performance optimization config
app:
  default_max_tokens: 50000  # Reduce from 200000

file_helper_agent:
  model: LiteLlm:gpt-3.5-turbo  # Faster model
```

### Memory Issues

**Problem**: Out of memory or context window exceeded

**Solutions**:
1. Use `optimized_memory` tool proactively
2. Process large files in chunks
3. Clear memory between major tasks
4. Reduce batch sizes

```python
# Use file chunking
chunk_text(file_path, chunk_size=1000)
read_file_in_chunks(file_path, chunk_size=50000)
```

### Token Limit Issues

**Problem**: Hitting token limits frequently

**Solutions**:
1. Check file sizes before reading
2. Use `get_file_stats` to preview token counts
3. Batch operations efficiently
4. Consider using models with larger context windows

## Integration Issues

### Excel Processing

**Problem**: Excel tool errors

**Solutions**:
1. Ensure pandas and openpyxl are installed
2. Check Excel file format is supported
3. Verify file is not corrupted
4. Handle large files in chunks

```bash
pip install pandas openpyxl
```

### Web Interface

**Problem**: Web interface doesn't load

**Solutions**:
1. Check port 8085 isn't already in use
2. Try a different port: `eiq web --port 8086`
3. Check firewall settings
4. Verify Engineering IQ installation

```bash
# Check if port is in use
lsof -i :8085  # macOS/Linux
netstat -an | findstr :8085  # Windows
```

## Debugging Techniques

### Enable Debug Logging

```yaml
# config.yaml
logger:
  level: DEBUG
  handlers:
    - sink: stdout
      level: DEBUG
      format: "<green>{time:HH:mm:ss.SSS}</green> | <level>{level}</level> | <cyan>{name}:{line}</cyan> | {message}"
```

### Trace Tool Execution

Add logging to custom tools:
```python
from engineering_iq.shared.core.logger import get_logger
logger = get_logger(__name__)

def my_tool(param):
    logger.debug(f"Tool called with: {param}")
    result = process(param)
    logger.debug(f"Tool result: {result}")
    return result
```

### Check Memory State

```python
# In your workflow
memory_status = optimized_mem_tool(max_tokens=1000)
print(f"Current memory usage: {memory_status}")
```

### Monitor File Operations

```yaml
app:
  trace_lsp_communication: true  # Enable LSP tracing
```

### Analyze Log Files

```bash
# View recent errors
tail -f logs/error.log

# Search for specific issues
grep -i "error" logs/code_analyzer.log

# View debug output
tail -f logs/code_analyzer.log | grep DEBUG
```

## Getting Help

### Before Asking for Help

1. **Check Documentation**:
   - Review relevant guides in `/docs`
   - Check agent-specific documentation
   - Review configuration examples

2. **Gather Information**:
   - Error messages and stack traces
   - Configuration being used
   - Steps to reproduce
   - Environment details (OS, Python version)

3. **Try Basic Fixes**:
   - Restart web interface
   - Clear and recreate virtual environment
   - Update to latest version
   - Check with minimal configuration

### Diagnostic Information

When reporting issues, include:

```bash
# System info
python --version
pip show engineering_iq
eiq --help

# Configuration
cat config.yaml

# Recent logs
tail -n 100 logs/error.log
```

### Common Fixes Summary

1. **For most errors**: Check logs, verify configuration, restart services
2. **For installation issues**: Use fresh virtual environment
3. **For performance issues**: Adjust model and token limits
4. **For integration issues**: Verify credentials and connectivity
5. **For unexpected behavior**: Enable debug logging and trace execution
