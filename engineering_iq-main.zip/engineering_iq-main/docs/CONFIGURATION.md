# Engineering IQ Configuration Guide

This guide covers all aspects of configuring Engineering IQ, from basic setup to advanced customization.

## Table of Contents
- [Configuration Overview](#configuration-overview)
- [Configuration Hierarchy](#configuration-hierarchy)
- [Global Configuration](#global-configuration)
- [Agent Configuration](#agent-configuration)
- [Logging Configuration](#logging-configuration)
- [Environment Variables](#environment-variables)
- [Advanced Configuration](#advanced-configuration)

## Configuration Overview

Engineering IQ uses a flexible configuration system that supports:
- YAML-based configuration files
- Environment variable overrides
- Deep merge strategy for inheritance
- Agent-specific settings

### Configuration Files Location

```
engineering_iq/
├── static/config/          # Default configurations
│   ├── app.yaml           # Global app settings
│   ├── logger.yaml        # Logging configuration
│   ├── jira.yaml          # Jira agent defaults
│   ├── product_analysis_planner.yaml
│   ├── dev_analysis_planner.yaml
│   └── ...                # Other agent configs
└── config.yaml            # Your local overrides (in working directory)
```

## Configuration Hierarchy

Configuration is loaded and merged in this order (highest priority first):

1. **Environment Variables** - Override any setting
2. **Local config.yaml** - Your project-specific overrides
3. **Agent Config Files** - Default agent configurations
4. **Base Settings** - Built-in defaults

### Deep Merge Strategy

Configurations are deep-merged, meaning you only need to specify what you want to change:

```yaml
# Default config (app.yaml)
app:
  git_dir: workdir/repos
  default_model: gemini-2.5-pro
  trace_lsp_communication: true
  default_max_tokens: 200000

# Your override (config.yaml)
app:
  git_dir: /custom/path/repos  # Only this changes
  # Other settings remain as defaults
```

## Global Configuration

### App Settings (`app.yaml`)

```yaml
app:
  # Directory for git operations
  git_dir: workdir/repos
  
  # Default model for all agents
  default_model: gemini-2.5-pro-preview-05-06
  
  # Token limit for context windows
  default_max_tokens: 200000
  
  # LSP debugging (performance impact)
  trace_lsp_communication: false
  
  # Custom context exceeded message
  context_size_error_message: |
    CONTEXT_WINDOW_EXCEEDED_ERROR: Context size exceeded...
```

### Using Different Models

To use non-Google models, prefix with `LiteLlm:`:

```yaml
app:
  # Google model (no prefix)
  default_model: gemini-2.5-pro
  
  # Anthropic Claude
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
  
  # OpenAI GPT
  default_model: LiteLlm:gpt-4-turbo-preview
  
  # Azure OpenAI
  default_model: LiteLlm:azure/my-deployment
```

## Agent Configuration

### Agent-Specific Settings

Each agent can have its own configuration:

```yaml
# Override model for specific agents
dev_analyzer_agent:
  model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
  description: "Custom description"
  instruction: "Custom instructions..."

product_analyzer_agent:
  model: gemini-2.5-pro
  additional_tools: ["custom_tool"]

feature_analysis_planner_agent:
  model: gemini-2.0-flash-exp
  description: "Feature analysis planner for comprehensive feature impact analysis"
```

### feature_analysis_planner_agent

Configuration for the Feature Analysis Planner agent.

**Parameters:**
- `codebase_path` (required): Path to the codebase to be analyzed
- `feature_requirements` (required): Description of feature requirements
- `repo_url` (optional): URL of the repository being analyzed

**Example Configuration:**
```yaml
feature_analysis_planner_agent:
  name: "feature_analysis_planner"
  short_name: "faplnr"
  model: "gemini-2.0-flash-exp"
  instruction: |
    Custom instructions for feature analysis planning...
  additional_report_sections:
    - |
      ### Custom Feature Impact Assessment
      - **Task:** Analyze feature impact on existing architecture
      - **Output:** Detailed impact analysis with recommendations
```

### MCP Server Configuration

For agents using MCP servers (like Jira):

```yaml
jira_agent:
  mcp_servers:
    - name: MyJiraServer
      sse_url: http://localhost:8082/sse
```

### Adding Custom Report Sections

Extend analysis reports with custom sections:

```yaml
product_analysis_planner_agent:
  additional_report_sections:
    - |
      ### Industry Compliance Check
      - **Task:** Analyze compliance with industry standards
      - **Output:** 
        - Compliance checklist
        - Gap analysis
        - Remediation recommendations

dev_analysis_planner_agent:
  additional_report_sections:
    - |
      ### Cloud Migration Readiness
      - **Task:** Assess cloud migration readiness
      - **Output:**
        - Current architecture assessment
        - Migration complexity score
        - Recommended migration path
```

### Prompt Variables

Use variables in agent instructions:

```yaml
my_agent:
  prompt_variables:
    industry: "healthcare"
    compliance: "HIPAA"
  instruction: |
    Analyze the codebase for {industry} compliance,
    specifically focusing on {compliance} requirements.
```

## Logging Configuration

### Basic Logging Setup

```yaml
logger:
  # Global log level
  level: INFO
  
  # Console output
  handlers:
    - sink: stdout
      level: INFO
      format: "<green>{time:HH:mm:ss}</green> | <level>{level}</level> | <level>{message}</level>"
    
    # File logging
    - sink: logs/engineering_iq.log
      level: DEBUG
      rotation: "10 MB"
      retention: "7 days"
    
    # Error-only log
    - sink: logs/errors.log
      level: ERROR
      rotation: "5 MB"
      retention: "30 days"
```

### Debug Configuration

For troubleshooting:

```yaml
logger:
  level: DEBUG
  handlers:
    - sink: stdout
      level: DEBUG
      format: "<green>{time:HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{line}</cyan> | <level>{message}</level>"
      colorize: true
```

## Environment Variables

### Global Settings

```bash
# App configuration
export APP_GIT_DIR="/custom/repos"
export APP_DEFAULT_MODEL="LiteLlm:anthropic/claude-3-5-sonnet-20241022"
export APP_DEFAULT_MAX_TOKENS="100000"
export APP_TRACE_LSP_COMMUNICATION="false"

# Logger configuration
export LOGGER_LEVEL="DEBUG"
```

### Agent-Specific Variables

```bash
# Override specific agent settings
export DEV_ANALYZER_AGENT_MODEL="LiteLlm:gpt-4-turbo-preview"
export PRODUCT_ANALYZER_AGENT_MODEL="gemini-2.5-pro"
export QE_ANALYZER_AGENT_ADDITIONAL_REPORT_SECTIONS='["### Custom Section"]'
```

### Model Provider Credentials

```bash
# Anthropic
export ANTHROPIC_API_KEY="your-key"

# OpenAI
export OPENAI_API_KEY="your-key"

# Azure
export AZURE_API_KEY="your-key"
export AZURE_API_BASE="https://your-resource.openai.azure.com/"
export AZURE_API_VERSION="2024-02-15-preview"

# AWS Bedrock
export AWS_ACCESS_KEY_ID="your-key"
export AWS_SECRET_ACCESS_KEY="your-secret"
export AWS_REGION_NAME="us-east-1"
```

### Custom Config Path

```bash
# Point to a different config directory
export CODE_ANALYZER_CONFIG_PATH="/path/to/custom/configs"
```

## Advanced Configuration

### Multi-Environment Setup

Create environment-specific configurations:

```yaml
# config.dev.yaml
app:
  default_model: LiteLlm:ollama/llama2  # Local model for dev
  git_dir: dev/repos

# config.prod.yaml
app:
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
  git_dir: /production/repos
```

Load with:
```bash
export CODE_ANALYZER_CONFIG_PATH="config.prod.yaml"
```

### Custom Agent Creation

When creating custom agents:

```yaml
# config.yaml
my_custom_agent:
  name: "custom_analyzer"
  short_name: "ca"  # Keep short!
  model: gemini-2.5-pro
  description: "My custom analysis agent"
  instruction: |
    You are a specialized agent for...
  additional_tools: ["my_tool"]
  prompt_variables:
    focus: "security"
```

### Performance Tuning

```yaml
app:
  # Reduce for faster processing
  default_max_tokens: 50000
  
  # Disable expensive features
  trace_lsp_communication: false

# Use faster models for simple tasks
file_helper_agent:
  model: LiteLlm:gpt-3.5-turbo

# Use powerful models for complex analysis
dev_analyzer_agent:
  model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
```

### Integration Configuration

For external integrations:

```yaml
# Jira integration
jira_config:
  project_key: "PROJ"
  default_issue_type: "Task"
  custom_fields:
    story_points: "customfield_10001"
    sprint: "customfield_10002"

# Git configuration
git_config:
  default_branch: "main"
  clone_depth: 1  # Shallow clone for performance
```

## Configuration Best Practices

### 1. Start Simple

Begin with minimal overrides:

```yaml
# config.yaml
app:
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
```

### 2. Use Environment Variables for Secrets

Never put secrets in config files:

```yaml
# Bad
jira_agent:
  api_key: "secret-key"  # Don't do this!

# Good - use environment variable
# export JIRA_API_KEY="secret-key"
```

### 3. Document Your Configuration

```yaml
# config.yaml
# Project: My Product Analysis
# Updated: 2025-01-15
# Purpose: Custom configuration for healthcare compliance analysis

app:
  # Using Claude for better compliance understanding
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
```

### 4. Version Control Strategy

```
project/
├── .gitignore          # Ignore local config.yaml
├── config.example.yaml # Template for team
└── config.yaml        # Your local config (not in git)
```

### 5. Validate Configuration

Test your configuration:

```python
from engineering_iq.shared.core.settings import app_settings
print(f"Model: {app_settings.default_model}")
print(f"Git Dir: {app_settings.git_dir}")
```

## Logging

Engineering IQ uses loguru for advanced logging capabilities.

### Default Logging Configuration

The application comes with sensible defaults:
- **Console logs**: Informational level
- **File logs**: Detailed debugging in `logs/code_analyzer.log`
- **Error logs**: Errors only in `logs/error.log`

### Log File Locations

```
logs/
├── code_analyzer.log    # Main application log
├── error.log           # Error-only log
└── <date>/             # Date-based logs (if configured)
```

### Advanced Logging Examples

#### Production Logging
```yaml
logger:
  level: INFO
  handlers:
    # Console - minimal output
    - sink: stdout
      level: WARNING
      format: "{time} | {level} | {message}"
    
    # Main log file with rotation
    - sink: logs/engineering_iq.log
      level: INFO
      rotation: "100 MB"
      retention: "30 days"
      compression: "zip"
    
    # Error tracking
    - sink: logs/errors.log
      level: ERROR
      backtrace: true
      diagnose: true
```

#### Development Logging
```yaml
logger:
  level: DEBUG
  handlers:
    # Colorful console output
    - sink: stdout
      level: DEBUG
      format: "<green>{time:HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | <level>{message}</level>"
      colorize: true
    
    # Detailed file log
    - sink: logs/debug.log
      level: DEBUG
      format: "{time} | {level} | {name}:{function}:{line} | {extra} | {message}"
```

#### Performance Monitoring
```yaml
logger:
  level: INFO
  handlers:
    # Performance metrics
    - sink: logs/performance.log
      level: INFO
      filter: lambda record: "performance" in record["extra"]
      format: "{time} | {extra[duration]} | {message}"
```

### Logging Best Practices

1. **Use appropriate log levels**:
   - DEBUG: Detailed information for debugging
   - INFO: General informational messages
   - WARNING: Warning messages for potential issues
   - ERROR: Error messages for failures
   - CRITICAL: Critical failures requiring immediate attention

2. **Structure logs for analysis**:
   ```yaml
   format: "{time} | {level} | {name} | {message} | {extra}"
   ```

3. **Rotate logs to manage disk space**:
   ```yaml
   rotation: "100 MB"  # or "1 day" or "1 week"
   retention: "30 days"
   compression: "zip"
   ```

4. **Use filters for specialized logs**:
   ```yaml
   filter: lambda record: "security" in record["extra"]
   ```

## Troubleshooting Configuration

**Note on Evolving Configurations:** The default global application settings (in `engineering_iq/static/config/app.yaml`) and default agent configurations (e.g., `engineering_iq/static/config/planner_agent.yaml` and other files in `engineering_iq/static/config/`) are subject to change as the project evolves. While this document provides examples and describes common settings, always refer to the latest versions of these YAML files in the `static/config` directory for the most up-to-date default values and available configuration parameters.

| Issue | Solution |
|-------|----------|
| Settings not applying | Check configuration hierarchy - env vars override files |
| YAML parsing errors | Validate YAML syntax, check indentation |
| Model not found | Ensure correct prefix (LiteLlm:) for non-Google models |
| Missing config file | File is optional - defaults will be used |
| Environment variable not working | Check exact variable name format |
| Logs not appearing | Check write permissions on logs directory |
| Log files too large | Configure rotation and retention |

## Configuration Examples

### Example 1: Multi-Model Analysis

```yaml
# Use different models for different types of analysis
product_analysis_planner_agent:
  model: LiteLlm:anthropic/claude-3-5-sonnet-20241022  # Best for business

dev_analysis_planner_agent:
  model: gemini-2.5-pro  # Best for technical

qe_analysis_planner_agent:
  model: LiteLlm:gpt-4-turbo-preview  # Balanced
```

### Example 2: Custom Logging

```yaml
logger:
  level: INFO
  handlers:
    # Console - only warnings and above
    - sink: stdout
      level: WARNING
    
    # Detailed file log with custom format
    - sink: logs/{time:YYYY-MM-DD}/engineering_iq.log
      level: DEBUG
      format: "{time} | {level} | {name}:{function}:{line} | {message}"
      rotation: "00:00"  # Daily rotation
```

### Example 3: Complete Override

```yaml
# Complete configuration example
app:
  git_dir: /data/repositories
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
  default_max_tokens: 100000
  trace_lsp_communication: false

logger:
  level: INFO

# Agent-specific overrides
dev_analyzer_agent:
  model: gemini-2.5-pro-preview-05-06
  additional_report_sections:
    - |
      ### Custom Architecture Review
      - **Task:** Review against company standards
      - **Output:** Compliance report

# MCP servers
jira_agent:
  mcp_servers:
    - name: CompanyJira
      sse_url: http://jira-mcp.company.com:8082/sse
