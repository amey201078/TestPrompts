# LSP Tools: IDE-Like Intelligence for AI Agents

## Overview

Engineering IQ's Language Server Protocol (LSP) integration is a game-changer that gives our AI agents the same code understanding capabilities that developers enjoy in modern IDEs like VS Code, IntelliJ, or Visual Studio. This document explains how LSP tools work and why they make Engineering IQ's analysis uniquely powerful.

## What is LSP?

The Language Server Protocol (LSP) is a standardized protocol used between development tools and language servers to provide intelligent code features. Originally developed by Microsoft for VS Code, it's now an industry standard that enables:

- **Code completion**
- **Go to definition**
- **Find all references**
- **Symbol search**
- **Hover information**
- **Refactoring support**

## How Engineering IQ Uses LSP

### Traditional Code Analysis vs LSP-Powered Analysis

**Traditional Approach:**
```
- Reads files as text
- Uses regex patterns for searching
- Limited understanding of code structure
- No awareness of cross-file relationships
- Can't understand type hierarchies
```

**LSP-Powered Approach:**
```
- Understands code semantically
- Navigates via symbols and definitions
- Full awareness of project structure
- Tracks dependencies across files
- Understands inheritance and interfaces
```

### Real-World Example

Consider analyzing the impact of changing a method signature:

**Without LSP:**
- Agent searches for text matches of the method name
- Might miss references using different syntax
- Can't distinguish between methods with same name
- No understanding of inheritance impact

**With LSP:**
- Agent finds all actual references to the specific method
- Understands which classes inherit/override it
- Identifies interface implementations
- Tracks indirect dependencies

## LSP Tools Available in Engineering IQ

### 1. `search_files`
**Purpose:** Semantic code search across the repository

**Capabilities:**
- Search by symbol type (classes, methods, variables)
- Filter by scope (public, private, protected)
- Understand context (declarations vs usages)

**Example Use:**
```python
# Find all public methods that return User objects
results = lsp_tool.search_files(
    pattern="User",
    symbol_type="method",
    visibility="public",
    context="return_type"
)
```

### 2. `get_symbols_overview`
**Purpose:** Get a high-level view of code structure

**Capabilities:**
- List all symbols in a file or directory
- Show symbol hierarchy (namespaces, classes, methods)
- Include metadata (visibility, parameters, return types)

**Example Output:**
```
📁 src/services/
  📄 UserService.ts
    🏛️ class UserService
      🔧 constructor(db: Database)
      📘 public async createUser(data: UserData): Promise<User>
      📗 private validateUserData(data: UserData): boolean
      📘 public async findUser(id: string): Promise<User | null>
```

### 3. `find_symbol`
**Purpose:** Navigate to symbol definitions and find usages

**Capabilities:**
- Jump to where a symbol is defined
- Find all references to a symbol
- Understand symbol relationships (implements, extends, uses)

**Use Cases:**
- Impact analysis: "What breaks if I change this?"
- Understanding flow: "Where is this called from?"
- Refactoring: "What needs updating if I rename this?"

## How LSP Enhances Each Agent Type

### Analysis Planners
LSP tools help planners understand the codebase structure before creating tasks:
- Identify key architectural components
- Understand module dependencies
- Recognize design patterns in use
- Plan analysis based on actual code structure

### Report Generators
LSP enables more accurate and detailed reports:
- **Product Analyzer**: Traces business logic through actual code paths
- **Dev Analyzer**: Creates accurate dependency graphs and architecture diagrams
- **QE Analyzer**: Identifies what needs testing based on code relationships
- **Feature Analyzer**: Precisely determines impact radius of changes

### Interactive Agents
The Idea Iterator uses LSP to:
- Validate technical feasibility of requirements
- Identify existing similar implementations
- Understand current system constraints
- Suggest implementation approaches based on codebase patterns

### Utility Agents
Enhanced capabilities for utility agents:
- **File Helper**: Smart file operations based on code structure
- **Search Agent**: Semantic search instead of text matching
- **Diagrammer**: Accurate architectural diagrams from real code relationships

## Practical Benefits

### 1. Accurate Impact Analysis
```
Scenario: Changing a database schema
Without LSP: Grep for table name, hope you find everything
With LSP: Trace from entity → repository → service → API → UI
```

### 2. Understanding Complex Inheritance
```
Scenario: Modifying a base class method
Without LSP: Manually check each file for extends/implements
With LSP: Instantly see full inheritance tree and override locations
```

### 3. Cross-Language Intelligence
```
Scenario: Full-stack change (backend API → frontend UI)
Without LSP: Separate analysis for each language
With LSP: Trace data flow across language boundaries
```

### 4. Refactoring Confidence
```
Scenario: Renaming a widely-used interface
Without LSP: Risk missing references, breaking changes
With LSP: Find every usage, including indirect ones
```

## Technical Implementation

### Supported Languages

Engineering IQ's LSP integration currently supports:

- **TypeScript/JavaScript** - Full support via TypeScript Language Server
- **Python** - Full support via Pylsp or Pyright
- **Java** - Full support via Eclipse JDT Language Server
- **C#** - Full support via OmniSharp
- **Go** - Full support via gopls
- **Rust** - Full support via rust-analyzer
- **Ruby** - Support via Solargraph
- **PHP** - Support via Intelephense

### Performance Considerations

LSP servers are optimized for performance:
- **Incremental parsing**: Only reanalyze changed files
- **Caching**: Symbol tables cached for fast lookups
- **Parallel processing**: Multiple files analyzed simultaneously
- **Memory efficiency**: Streaming processing for large codebases

## Configuration

LSP tools in Engineering IQ work automatically without any configuration required. The system automatically:

- Detects the programming languages in your repository
- Starts the appropriate language servers
- Configures them with sensible defaults
- Handles all the complex setup internally

This zero-configuration approach means:
- **No setup required** - LSP tools work out of the box
- **Automatic language detection** - Supports all major languages
- **Smart defaults** - Optimized settings for code analysis
- **Seamless integration** - Just use the tools, they handle the rest

Simply use the LSP tools in your agents, and Engineering IQ handles all the complexity behind the scenes.

## Best Practices

### 1. Repository Preparation
- Ensure project has proper configuration files (tsconfig.json, pyproject.toml, etc.)
- Include dependency lock files for accurate analysis
- Have build configurations available

### 2. Using LSP Tools Effectively
- Start with `get_symbols_overview` for high-level understanding
- Use `find_symbol` for detailed investigation
- Combine with traditional file reading for complete picture

### 3. Performance Optimization
- For large codebases, focus LSP analysis on specific modules
- Use file filtering to reduce initial indexing time
- LSP automatically optimizes based on project size

## Troubleshooting

### Common Issues

**Issue: LSP server not starting**
- Check language runtime is installed
- Verify project configuration files exist
- Review logs for initialization errors

**Issue: Incomplete symbol information**
- Ensure all dependencies are installed
- Check for syntax errors in code
- Verify language server supports required features

**Issue: Slow performance**
- Reduce scope of analysis
- Increase memory allocation
- Use language-specific optimizations

## Future Enhancements

We're continuously improving LSP integration:

1. **Multi-repository analysis** - Trace symbols across repository boundaries
2. **Historical analysis** - Understand how symbols evolved over time
3. **AI-enhanced navigation** - Smart suggestions for related code
4. **Custom language support** - Add LSP servers for domain-specific languages

## Conclusion

LSP tools transform Engineering IQ from a code reader into a code understander. By giving AI agents the same intelligent navigation and analysis capabilities that developers use, we enable:

- More accurate analysis
- Deeper insights
- Better recommendations
- Faster processing
- Higher confidence in results

This is what sets Engineering IQ apart—our agents don't just analyze code, they understand it at the same level as experienced developers using modern IDEs.

---

**Next Steps:** Learn about [Customizing Analysis Workflows](WORKFLOWS.md) →
