# Engineering IQ Best Practices Guide

This guide provides best practices and tips for getting the most out of Engineering IQ.

## Table of Contents
- [Workflow Best Practices](#workflow-best-practices)
- [Agent Selection Guide](#agent-selection-guide)
- [Prompt Engineering](#prompt-engineering)
- [Performance Optimization](#performance-optimization)
- [Analysis Tips](#analysis-tips)
- [Common Patterns](#common-patterns)

## Workflow Best Practices

### 1. Follow the Complete Workflow

For comprehensive analysis, follow the full workflow:
```
Git Helper → Analysis Planners → Analyzers → Task Loader (optional)
```

This ensures:
- Structured, thorough analysis
- Consistent results
- Complete documentation
- Traceability

### 2. Start Small, Then Expand

Begin with one type of analysis:
1. Start with Product Analysis for business understanding
2. Add Dev Analysis for technical details
3. Include QE Analysis for comprehensive coverage

### 3. Use Checkpoints

The task file system provides natural checkpoints:
- Planners create task files you can review
- Analyzers track progress in these files
- You can restart from any checkpoint

### 4. Review Before Proceeding

After each planning phase:
1. Review the generated task file
2. Adjust tasks if needed
3. Proceed with analysis
4. Use Final Reviewer feedback

## Agent Selection Guide

### For Business Requirements
**Primary Flow**: Product Analysis Planner → Product Analyzer

**When to use**:
- Understanding feature sets
- Documenting user journeys
- Identifying business rules
- Creating functional specifications

**Supporting Agents**:
- File Helper for document analysis
- Simple Search for industry context

### For Technical Architecture
**Primary Flow**: Dev Analysis Planner → Dev Analyzer

**When to use**:
- Architecture documentation
- Technology assessment
- Code quality review
- Migration planning

**Supporting Agents**:
- Diagramer for visualizations
- Dev Analyst for code understanding

### For Testing Strategy
**Primary Flow**: QE Analysis Planner → QE Analyzer

**When to use**:
- Test coverage assessment
- Quality strategy development
- Risk analysis
- Automation planning

**Supporting Agents**:
- QE Analyst for test analysis
- Planner for test planning

### For Repository Management
**Primary Agent**: Git Helper

**When to use**:
- Cloning repositories
- Setting up analysis workspace

### For File Operations
**Primary Agent**: File Helper

**When to use**:
- Reading configuration files
- Analyzing directory structures
- Processing large files
- Token counting

### For Project Management
**Primary Flow**: Task Loader → Jira Agent

**When to use**:
- Converting analysis to actionable tasks
- Creating project structure in Jira
- Tracking implementation

## Prompt Engineering

### 1. Be Specific

**Good**:
```
Analyze the repository at /workdir/repos/my-app focusing on the authentication system
```

**Better**:
```
Analyze the repository at /workdir/repos/my-app, specifically:
- OAuth2 implementation in src/auth
- JWT token handling
- Session management
- Security vulnerabilities in authentication flow
```

### 2. Provide Context

Include relevant information:
- Technology stack
- Business domain
- Specific concerns
- Expected outcomes

### 3. Use Structured Requests

For complex tasks, structure your request:
```
1. Clone repository: https://github.com/example/app
2. Analyze authentication system
3. Focus on security vulnerabilities
4. Generate remediation recommendations
```

### 4. Leverage Agent Expertise

Each agent has specialized knowledge:
- Product Analyzer understands business patterns
- Dev Analyzer knows architectural patterns
- QE Analyzer understands testing strategies

## Performance Optimization

### 1. Model Selection Strategy

```yaml
# Use appropriate models for each task
file_helper_agent:
  model: LiteLlm:gpt-3.5-turbo  # Fast for simple operations

dev_analyzer_agent:
  model: LiteLlm:anthropic/claude-3-5-sonnet-20241022  # Powerful for analysis

simple_search_agent:
  model: LiteLlm:gpt-3.5-turbo  # Cost-effective for searches
```

### 2. Context Window Management

- Monitor token usage with File Helper
- Use `optimized_memory` tool proactively
- Process large files in chunks
- Clear memory between major tasks

### 3. Smart File Tool Usage

#### Use Smart File Tools for Memory Safety
The smart file tools automatically manage memory and include validation capabilities:

```python
# Good: Uses smart file tools with automatic limits
from engineering_iq.shared.tools.file_tool import (
    smart_file_read_tool,
    smart_file_list_tool,
    smart_file_write_tool,
    smart_file_search_tool,
    file_validation_tool,
    multiple_file_validation_tool,
)

# Validate files before processing
validation_result = file_validation_tool(
    file_path="config.json",
    check_readable=True,
    check_writable=False
)

if validation_result.exists and validation_result.is_file:
    # Safe to proceed with file operations
    response = smart_file_read_tool(file_path="config.json")
    if response.truncated:
        # Handle truncated content appropriately
        print(f"Content truncated. Use start_position for chunked reading.")
else:
    print(f"File validation failed: {validation_result.message}")
```

#### File Validation Best Practices

**Always Validate Before Processing**:
```python
# Validate single file
result = file_validation_tool(
    file_path="important_config.json",
    check_readable=True,
    check_writable=True  # If you plan to modify
)

if not result.exists:
    print(f"File not found: {result.file_path}")
    return

if not result.is_file:
    print(f"Path is not a file: {result.file_path}")
    return

if not result.readable:
    print(f"File not readable: {result.file_path}")
    return

# Now safe to process
content = smart_file_read_tool(file_path=result.file_path)
```

**Batch Validation for Multiple Files**:
```python
# Validate multiple files at once
files_to_process = [
    "src/main.py",
    "src/config.py", 
    "src/utils.py",
    "README.md"
]

validation_results = multiple_file_validation_tool(
    file_paths=files_to_process,
    check_readable=True
)

# Process only valid files
valid_files = [
    result.file_path for result in validation_results 
    if result.exists and result.is_file and result.readable
]

print(f"Processing {len(valid_files)} out of {len(files_to_process)} files")

for file_path in valid_files:
    content = smart_file_read_tool(file_path=file_path)
    # Process content...
```

**Validation in Error Handling**:
```python
def safe_file_operation(file_path: str):
    """Demonstrate defensive programming with validation"""
    try:
        # Always validate first
        validation = file_validation_tool(file_path=file_path)
        
        if not validation.exists:
            return {"error": f"File not found: {file_path}"}
            
        if validation.is_directory:
            return {"error": f"Path is directory, not file: {file_path}"}
            
        if not validation.readable:
            return {"error": f"File not readable: {file_path}"}
            
        # File is valid, proceed with operation
        content = smart_file_read_tool(file_path=file_path)
        return {"success": True, "content": content.content}
        
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}"}
```

#### Memory Management Patterns
- **Start Small**: Use max_tokens=2000-4000 for exploration
- **Check Truncation**: Always check `truncated` field in responses
- **Use Search**: Use `smart_file_search_tool` instead of reading multiple files
- **Limit Results**: File listings limited to 100 results by default

### 4. Batch Operations

**Inefficient**:
```
Read file1.py
Read file2.py
Read file3.py
```

**Efficient**:
```
# Use search to find content across multiple files
smart_file_search_tool(
    directory_path="src/",
    search_term="function_name",
    file_pattern="*.py",
    max_matches=25
)
```

### 4. Parallel Analysis

Run multiple planners simultaneously:
- Open three terminal sessions
- Run each planner in parallel
- Merge results for comprehensive view

## Analysis Tips

### 1. Repository Preparation

Before analysis:
- Ensure repository is up-to-date
- Remove unnecessary files (node_modules, etc.)
- Document any special setup requirements

### 2. Custom Sections

Add domain-specific sections:
```yaml
product_analysis_planner_agent:
  additional_report_sections:
    - |
      ### Compliance Requirements
      - **Task:** Analyze GDPR compliance
      - **Output:** Compliance checklist and gaps
```

### 3. Incremental Analysis

For large codebases:
1. Analyze core modules first
2. Expand to peripheral components
3. Focus on critical paths
4. Use search to find specific patterns

### 4. Cross-Reference Results

- Compare Product and Dev analysis results
- Validate business rules against implementation
- Check test coverage against features

## Common Patterns

### Pattern 1: Migration Assessment

```yaml
# config.yaml
dev_analysis_planner_agent:
  additional_report_sections:
    - |
      ### Migration Readiness
      - **Task:** Assess cloud migration readiness
      - **Output:** 
        - Current state assessment
        - Migration complexity
        - Risk factors
        - Recommended approach
```

### Pattern 2: Security Audit

```yaml
# Add to all three planners
additional_report_sections:
  - |
    ### Security Assessment
    - **Task:** Security analysis for [planner type]
    - **Output:** Vulnerabilities and recommendations
```

### Pattern 3: Compliance Review

```yaml
product_analysis_planner_agent:
  prompt_variables:
    compliance_framework: "SOC2"
  additional_report_sections:
    - |
      ### {compliance_framework} Compliance
      - **Task:** Assess compliance requirements
      - **Output:** Compliance matrix
```

### Pattern 4: Technical Debt Analysis

```yaml
dev_analysis_planner_agent:
  additional_report_sections:
    - |
      ### Technical Debt Assessment
      - **Task:** Identify and quantify technical debt
      - **Output:**
        - Debt inventory
        - Impact assessment
        - Remediation priority
        - Effort estimates
```

### Pattern 5: Memory-Safe File Analysis

```python
# Memory-safe large file analysis
def analyze_large_codebase(directory_path: str):
    # 1. Get overview with limited results
    file_list = smart_file_list_tool(
        directory_path=directory_path,
        pattern="*.py",
        recursive=True,
        max_results=50  # Prevent memory overload
    )
    
    # 2. Search for specific patterns instead of reading all files
    search_results = smart_file_search_tool(
        directory_path=directory_path,
        search_term="class.*Agent",
        file_pattern="*.py",
        max_matches=25
    )
    
    # 3. Read specific files with memory limits
    for file_path in priority_files:
        response = smart_file_read_tool(
            file_path=file_path,
            max_tokens=4000  # Conservative limit
        )
        if response.truncated:
            # Process in chunks if needed
            continue
```

## Best Practices Summary

### Do's ✓
- Start with planners for structured analysis
- Review task files before proceeding
- Use appropriate models for each task
- Leverage agent specializations
- Save checkpoints for large analyses
- Document assumptions and confidence levels
- Use batch operations for efficiency
- Add custom sections for domain needs

### Don'ts ✗
- Skip planning phase
- Ignore error messages
- Use one model for everything
- Process huge files without chunking
- Forget to manage context size
- Run without configuration
- Ignore agent feedback
- Assume 100% accuracy

## Tips for Specific Scenarios

### Large Monolithic Applications
1. Start with high-level architecture analysis
2. Break down by modules
3. Focus on critical paths
4. Use search for cross-cutting concerns

### Microservices Architecture
1. Analyze service boundaries first
2. Map inter-service communication
3. Check for common patterns
4. Assess individual service complexity

### Legacy Code Analysis
1. Start with Dev Analysis for current state
2. Use Product Analysis to understand intent
3. Compare implementation vs requirements
4. Focus on migration opportunities

### Greenfield Projects
1. Use Planner Agent for requirements
2. Generate architecture recommendations
3. Create test strategy upfront
4. Set up project structure in Jira

## Continuous Improvement

### 1. Iterate on Configuration

Start simple and enhance:
```yaml
# Version 1: Basic
app:
  default_model: gemini-2.5-pro

# Version 2: Optimized
app:
  default_model: gemini-2.5-pro
file_helper_agent:
  model: LiteLlm:gpt-3.5-turbo
dev_analyzer_agent:
  model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
```

### 2. Learn from Results

- Review generated reports
- Identify gaps
- Add custom sections
- Refine prompts

### 3. Build Templates

Create reusable configurations:
- Security audit template
- Migration assessment template
- Compliance review template
- Performance analysis template

### 4. Share Knowledge

- Document successful patterns
- Share configurations with team
- Contribute improvements back
- Build organizational knowledge base
