# Engineering IQ Installation Guide

This guide covers all installation methods and setup procedures for Engineering IQ.

## Table of Contents
- [Prerequisites](#prerequisites)
- [Installation Methods](#installation-methods)
- [Package Installation](#package-installation)
- [Development Installation](#development-installation)
- [Optional Components](#optional-components)
- [Verification](#verification)
- [Troubleshooting](#troubleshooting)

## Prerequisites

### System Requirements
- **Python**: 3.11 or higher
  - **Note for LSP users**: LSP components require Python >=3.11 and <3.12
- **Git**: For repository operations
- **Operating System**: Linux, macOS, or Windows (with some limitations)

### Python Environment
It's recommended to use a virtual environment:

```bash
# Using venv
python -m venv engineering_iq_env
source engineering_iq_env/bin/activate  # On Windows: engineering_iq_env\Scripts\activate

# Using conda
conda create -n engineering_iq python=3.11
conda activate engineering_iq
```

## Installation Methods

### Method 1: Package Installation (Recommended)

For users who want to use Engineering IQ without modifying the source code.

```bash
# Basic installation from repository
pip install "git+https://github.com/your-org/engineering_iq.git"

# With LSP support (optional, may have issues on Windows)
pip install "engineering_iq[lsp] @ git+https://github.com/your-org/engineering_iq.git"

# Development installation
git clone https://github.com/your-org/engineering_iq.git
cd engineering_iq
pip install -e .
```

### Method 2: Development Installation

For developers who want to contribute or modify Engineering IQ.

```bash
# Clone the repository
git clone https://github.com/your-org/engineering_iq.git
cd engineering_iq

# Install in development mode
pip install -e .

# Install with LSP support (optional)
pip install -e ".[lsp]"

# Install development dependencies
pip install -e ".[dev]"
```

## Package Installation

### Core Dependencies

The package installation automatically includes:
- `google-adk` - Google's Agent Development Kit
- `pydantic` - Data validation
- `fastapi` & `uvicorn` - Web framework
- `loguru` - Advanced logging
- `gitpython` - Git operations
- `networkx` - Graph operations
- `tiktoken` - Token counting
- `litellm` - Multi-model support
- `pandas` & `openpyxl` - Excel processing

### Verify Installation

```bash
# Check installation
python -c "import engineering_iq; print('Engineering IQ installed successfully')"

# Check CLI access
eiq --help
engineering_iq --help

# Check Engineering IQ installation
eiq --help
```

## Development Installation

### Setting Up Development Environment

1. **Clone and Install**
```bash
git clone https://github.com/your-org/engineering_iq.git
cd engineering_iq
pip install -e ".[dev]"
```

2. **Install Pre-commit Hooks**
```bash
pre-commit install
```

3. **Configure IDE**

For VSCode:
```json
{
  "python.linting.enabled": true,
  "python.linting.flake8Enabled": true,
  "python.formatting.provider": "black",
  "editor.formatOnSave": true
}
```

### Development Dependencies

The `[dev]` extra includes:
- `pytest` - Testing framework
- `pytest-asyncio` - Async test support
- `pytest-cov` - Coverage reporting
- `black` - Code formatter
- `isort` - Import sorter
- `flake8` - Linter
- `mypy` - Type checker

## Optional Components

### Language Server Protocol (LSP)

The LSP component provides advanced code analysis capabilities:

**⚠️ Important Python Version Requirement**: LSP components require Python >=3.11 and <3.12. Python 3.12 and higher are not currently supported for LSP functionality.

```bash
# Ensure you're using Python 3.11.x
python --version  # Should show 3.11.x

# Install with LSP
pip install "engineering_iq[lsp] @ git+https://github.com/your-org/engineering_iq.git"

# Or for development
pip install -e ".[lsp]"
```

**Note**: 
- LSP installation may fail on Windows
- LSP is optional - Engineering IQ will work without it
- If using Python 3.12+, skip LSP installation and use base Engineering IQ

### Excel Support

Excel functionality requires additional packages:

```bash
pip install pandas openpyxl
```

### Model Provider Dependencies

Depending on which LLM providers you plan to use:

```bash
# For local models (Ollama)
# Install Ollama separately from https://ollama.ai

# For specific providers, set up credentials:
export ANTHROPIC_API_KEY="your-key"
export OPENAI_API_KEY="your-key"
```

## Verification

### Basic Verification

1. **Check Package Installation**
```python
import engineering_iq
from engineering_iq.shared.agents import *
print("All imports successful")
```

2. **Test Interface Options**

**Option A: Web Interface**
```bash
# Using Engineering IQ CLI
eiq web --port 8085                     # Short command
engineering_iq web --port 8085          # Full command
# Navigate to http://localhost:8085
```

**Option B: MCP Server**
```bash
# Start MCP server (short commands)
eiq server --port 8000
engineering_iq server --port 8000       # Full command name

# Or with full options
engineering_iq dev_server --port 8000 --host localhost --log-level info
```

3. **Verify Agent Loading**
```python
from engineering_iq.shared.agents.product_analyzer.agent import ProductAnalyzerAgent
agent = ProductAnalyzerAgent()
print(f"Agent loaded: {agent.get_id()}")
```

### Full System Test

```bash
# Clone a test repository
python -c "
from engineering_iq.shared.agents.git_helper.agent import GitHelperAgent
agent = GitHelperAgent()
# Test agent initialization
"
```

## Troubleshooting

**Note on Evolving Dependencies:** The project's dependencies and Python version compatibilities (especially for optional components like LSP) are defined in `pyproject.toml`. As this file evolves, the specific package versions or Python constraints mentioned in this document may change. Always refer to the latest `pyproject.toml` for the most up-to-date dependency information.

### Common Installation Issues

| Issue | Solution |
|-------|----------|
| `ModuleNotFoundError: No module named 'engineering_iq'` | Ensure installation completed successfully |
| LSP installation fails on Windows | Skip LSP - use `pip install engineering_iq` without `[lsp]` |
| LSP installation fails on Python 3.12+ | LSP requires Python >=3.11 and <3.12. Use Python 3.11.x or skip LSP |
| Permission denied errors | Use virtual environment or `pip install --user` |
| Git URL not accessible | Check network access to repository |
| Dependency conflicts | Create fresh virtual environment |

### Platform-Specific Issues

#### Windows
- LSP components may not install
- Use PowerShell or Git Bash for better compatibility
- Path separators in configs should use forward slashes

#### macOS
- May need to install Xcode Command Line Tools
- `xcode-select --install`

#### Linux
- Ensure Python development headers are installed
- `sudo apt-get install python3.11-dev` (Ubuntu/Debian)

### Dependency Resolution

If you encounter dependency conflicts:

```bash
# Clear pip cache
pip cache purge

# Reinstall with verbose output
pip install -v "engineering_iq @ git+https://..."

# Or use constraints file
pip install -c constraints.txt "engineering_iq @ git+..."
```

### Virtual Environment Issues

```bash
# If venv is corrupted, recreate it
deactivate
rm -rf engineering_iq_env  # Or your venv name
python -m venv engineering_iq_env
source engineering_iq_env/bin/activate
pip install "engineering_iq @ git+..."
```

## Post-Installation Setup

### 1. Create Configuration

Create a `config.yaml` in your working directory:

```yaml
app:
  default_model: gemini-2.5-pro
  git_dir: workdir/repos
```

### 2. Set Up Logging Directory

```bash
mkdir -p logs
```

### 3. Configure Model Providers

```bash
# Example: Set up Anthropic
export ANTHROPIC_API_KEY="your-api-key"
```

### 4. Test Basic Functionality

```bash
# Start web interface
eiq web --port 8085

# In browser, test File Helper agent with a simple request
```

## Updating Engineering IQ

### Update Package Installation

```bash
# Uninstall old version
pip uninstall engineering_iq

# Install latest
pip install "engineering_iq @ git+https://github.com/your-org/engineering_iq.git"
```

### Update Development Installation

```bash
cd engineering_iq
git pull origin main
pip install -e .
```

## Uninstallation

```bash
# Remove package
pip uninstall engineering_iq

# Remove virtual environment (if used)
deactivate
rm -rf engineering_iq_env

# Remove configuration and logs (optional)
rm -rf config.yaml logs/
