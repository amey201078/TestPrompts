# Engineering IQ Documentation

Welcome to the Engineering IQ documentation! This guide provides comprehensive information about using and understanding the Engineering IQ platform.

## Documentation Index

### Getting Started
- [Installation Guide](INSTALLATION.md) - Complete installation instructions
- [Quick Start](../README.md#quick-start) - Get up and running quickly
- [Best Practices](BEST_PRACTICES.md) - Tips and recommendations for effective use

### Core Concepts
- [Agents Reference](AGENTS.md) - Detailed information about all agents
- [LSP Tools](LSP_TOOLS.md) - IDE-like code intelligence capabilities
- [MCP Server](MCP_SERVER.md) - Model Context Protocol server for external integrations
- [Model Configuration](MODELS.md) - Using different LLM providers beyond Google
- [Analysis Reports](ANALYSIS_REPORTS.md) - Understanding and customizing reports

### Configuration
- [Configuration Guide](CONFIGURATION.md) - Complete configuration reference
- [Sample Configuration](../sample.config.yaml) - Example configuration file

### Workflows
- [Analysis Workflows](WORKFLOWS.md#analysis-workflows) - Complete analysis processes with visual diagrams
  - [Product Analysis Workflow](WORKFLOWS.md#product-analysis-workflow)
  - [Dev Analysis Workflow](WORKFLOWS.md#dev-analysis-workflow)
  - [QE Analysis Workflow](WORKFLOWS.md#qe-analysis-workflow)
  - [DevSecOps Analysis Workflow](WORKFLOWS.md#devsecops-analysis-workflow)
- [Task Loading Workflow](WORKFLOWS.md#task-loading-workflow) - Loading analysis results to Jira

### Development
- [Developer Notes](DEVELOPER_NOTES.md) - Critical developer information and best practices
- [Contributing Guidelines](../README.md#contributing) - How to contribute to the project

### Troubleshooting
- [Troubleshooting Guide](TROUBLESHOOTING.md) - Complete troubleshooting reference
- [Common Issues](TROUBLESHOOTING.md#common-issues) - Quick solutions to frequent problems

## Quick Links

### Interface Options
- **Web Interface**: `eiq web --port 8080` (default) or `engineering_iq web --host localhost --port 8080`
- **MCP Server**: `eiq server --port 8000` or `eiq dev_server --port 8000`

### Quick Setup
- **Install Package**: `pip install -e .` (development) or `pip install "engineering_iq @ git+https://github.com/your-repo/engineering_iq.git"`
- **CLI Access**: Use `eiq` or `engineering_iq` commands
- **Configuration**: Create a `config.yaml` in your working directory to override defaults

## Need Help?

1. Check the [Troubleshooting Guide](../README.md#troubleshooting)
2. Review the [Workflows](WORKFLOWS.md) for step-by-step processes
3. Examine the [Sample Configuration](../sample.config.yaml) for configuration examples
