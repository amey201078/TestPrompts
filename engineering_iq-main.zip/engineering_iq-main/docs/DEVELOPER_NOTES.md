# Developer Notes for Engineering IQ

This document contains important information, tips, and best practices for developers working on or extending Engineering IQ.

## Table of Contents
- [Critical Limitations](#critical-limitations)
- [Agent Development](#agent-development)
- [Tool Development](#tool-development)
- [Configuration Best Practices](#configuration-best-practices)
- [Debugging Tips](#debugging-tips)
- [Performance Considerations](#performance-considerations)
- [Common Pitfalls](#common-pitfalls)
- [Architecture Decisions](#architecture-decisions)

## Critical Limitations

### 1. Agent and Function Name Length
**⚠️ CRITICAL**: Keep agent and function names short - they are combined for agent use and have a **64 character limit**.
- You will see 400 errors around function names if you exceed this limit
- Example: `product_analysis_planner_agent_find_symbols` = 42 characters (OK)
- Bad example: `product_business_requirements_analysis_planner_agent_find_all_symbols` = 76 characters (FAILS)

### 2. Google API 500 Errors
- We consistently get 500 errors from Google APIs with runs
- **Workaround for Web Interface**: Just close the error dialog and type "continue"
- **For Production**: Add robust error handling and retry logic in your runners

### 3. Context Window Management
- The system includes automatic context optimization when token limits are exceeded
- **New**: Automatic tool response size management prevents oversized tool outputs
- **Best Practice**: Use the `optimize_context_content` tool proactively for memory management
- Tool responses exceeding token limits are automatically truncated with guidance messages

## Agent Development

### Creating New Agents

1. **Inherit from EngineeringIQAgent**
```python
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent

class MyAgent(EngineeringIQAgent):
    """Your agent description"""
    
    def get_agent_settings(self) -> AgentSettings:
        return self.settings
    
    def _init_tools(self):
        # Initialize your tools here
        self.add_tools(my_tools)
    
    def _get_agent_core_config(self) -> dict:
        return {
            "name": self.get_id(),
            "model": self.settings.model,
            "instruction": self.settings.instruction,
            "tools": self.tools,
            "description": self.settings.description
        }
```

2. **Agent Settings Pattern**
```python
class MyAgentSettings(AgentSettings):
    config_section: ClassVar[str] = "my_agent"  # Keep this short!
    
    model_config = {
        **AgentSettings.model_config,
        "env_prefix": f"{config_section.upper()}_AGENT_",
    }
```

3. **Composing Agents**
- Use `LoopAgent` for iterative workflows
- Use `create_sub_agent()` to maintain memory/session services
- Always pass tools through to sub-agents when needed

### Agent Naming Conventions

- **Config Section**: `<purpose>_<type>` (e.g., `product_analyzer`, `dev_planner`)
- **Short Name**: 2-3 letter abbreviation (e.g., `aa`, `dp`)
- **Class Name**: `<Purpose><Type>Agent` (e.g., `ProductAnalyzerAgent`)
- **File Name**: `agent.py` in a folder named after the agent

## Tool Development

### Smart File Tool Usage

#### Memory-Safe Tool Development
When developing agents, use the simplified file tools:

```python
# Import the enhanced file tools
from engineering_iq.shared.tools.file_tool import (
    smart_file_read_tool,
    smart_file_list_tool,
    smart_file_write_tool,
    smart_file_search_tool,
    regex_replace_tool,
    file_validation_tool,
    multiple_file_validation_tool,
)

class MyAgent(EngineeringIQAgent):
    def _init_tools(self):
        # Use individual tools for explicit control
        self.add_tools([
            smart_file_read_tool,
            smart_file_list_tool,
            smart_file_write_tool,
            smart_file_search_tool,
            regex_replace_tool,  # New: regex find and replace
            file_validation_tool,  # New: file existence validation
            multiple_file_validation_tool,  # New: batch file validation
        ])
```

#### Tool Usage Guidelines
1. **Built-in Memory Management**: Tools automatically limit token usage
2. **Usage Hints**: Tools provide automatic guidance to LLM
3. **Structured Responses**: Pydantic models for consistent responses
4. **Truncation Awareness**: Always check for content truncation

### Creating Tools

1. **Function-Based Tools**
```python
def my_tool(param1: str, param2: int = 10) -> dict:
    """Tool description for the LLM.
    
    Args:
        param1: Description of param1
        param2: Description of param2 (default: 10)
    
    Returns:
        Dictionary with status and result
    """
    try:
        # Tool logic here
        return {"status": "success", "result": result}
    except Exception as e:
        return {"status": "error", "error": str(e)}
```

2. **Tool Registration**
```python
# In agent's _init_tools method
self.add_tool(my_tool)  # Function will be wrapped automatically
```

3. **Tool Naming**
- Keep tool names descriptive but concise
- Use snake_case
- Avoid redundant prefixes

### Creating Custom File Tools
If you need custom file operations, follow the pattern:

```python
from google.genai import types
from google.adk.tools import FunctionTool, ToolContext

class MyFileToolTool(FunctionTool):
    def __init__(self):
        super().__init__(my_file_function)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file"
                    )
                },
                required=["file_path"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
        Your custom tool usage instructions here.
        """])
```

### MCP Server Integration

For external tools via MCP:
```yaml
agent_config:
  mcp_servers:
    - name: MyServer
      sse_url: http://localhost:8082/sse
```

## Configuration Best Practices

### 1. Configuration Hierarchy

Remember the precedence (highest to lowest):
1. Environment variables
2. Local `config.yaml`
3. Agent-specific config files
4. Default settings

### 2. Environment Variables

```bash
# Global settings
export APP_DEFAULT_MODEL="gemini-2.5-pro"
export APP_GIT_DIR="/custom/path"

# Agent-specific
export DEV_ANALYZER_AGENT_MODEL="LiteLlm:anthropic/claude-3-5-sonnet"
export APP_ANALYZER_AGENT_ADDITIONAL_TOOLS='["custom_tool"]'
```

### 3. Prompt Variables

Use prompt variables for dynamic content:
```yaml
my_agent:
  prompt_variables:
    context_type: "technical"
    focus_area: "security"
  instruction: |
    Analyze the {context_type} aspects focusing on {focus_area}
```

## Debugging Tips

### 1. Enable Debug Logging

```yaml
logger:
  level: DEBUG
  handlers:
    - sink: stdout
      level: DEBUG
      format: "<green>{time:HH:mm:ss}</green> | <level>{level}</level> | <cyan>{name}</cyan> | <level>{message}</level>"
```

### 2. Trace Tool Execution

```python
from engineering_iq.shared.core.logger import get_logger
logger = get_logger(__name__)

def my_tool(param):
    logger.debug(f"Tool called with param: {param}")
    # Tool logic
    logger.debug(f"Tool result: {result}")
    return result
```

### 3. Memory Debugging

Use the memory tools to inspect agent state:
```python
# In your agent
memory_status = optimized_mem_tool(max_tokens=1000)
logger.debug(f"Memory state: {memory_status}")
```

### 4. LSP Communication Tracing

```yaml
app:
  trace_lsp_communication: true  # Enables LSP debug output
```

## Performance Considerations

### 1. Smart Memory Management

#### Automatic Token Limits
The simplified file tools include automatic memory management:
- **smart_file_read_tool**: 8000 token default limit with auto-truncation
- **smart_file_list_tool**: 100 file limit with total count reporting  
- **smart_file_search_tool**: 50 match limit with clear truncation indicators

#### Usage Guidance Built-In
Tools automatically provide usage hints to LLM:
- Start with smaller token limits for exploration
- Use search instead of reading multiple files
- Check truncation status before proceeding
- Use appropriate file patterns to narrow scope

#### Memory-Safe Patterns
```python
# Good: Check truncation and handle appropriately
response = smart_file_read_tool(file_path="large_file.py", max_tokens=4000)
if response.truncated:
    logger.info(f"File truncated at {response.token_count} tokens")
    # Process in chunks or use search instead

# Good: Use search for finding specific content
matches = smart_file_search_tool(
    directory_path="src/",
    search_term="authentication",
    file_pattern="*.py",
    max_matches=25
)
```

### 2. Tool Optimization

```python
# Bad: Multiple individual reads
for file in files:
    content = read_file(file)
    
# Good: Use search across multiple files
search_results = smart_file_search_tool(
    directory_path="src/",
    search_term="target_pattern",
    file_pattern="*.py",
    max_matches=50
)
```

### 3. Memory Management

- Clear memory between major tasks
- Use `optimized_memory` with appropriate `max_tokens`
- Consider memory service lifecycle in long-running agents
- Always check `truncated` field in file responses

### 4. Model Selection

- Use cheaper/faster models for simple tasks
- Reserve powerful models for complex analysis
- Consider context window limits when selecting models

## Common Pitfalls

### 1. Circular Imports

```python
# Avoid importing agents directly
# Bad:
from engineering_iq.shared.agents.product_analyzer.agent import ProductAnalyzerAgent

# Good: Import only when needed
def create_analyzer():
    from engineering_iq.shared.agents.product_analyzer.agent import ProductAnalyzerAgent
    return ProductAnalyzerAgent()
```

### 2. Tool Name Conflicts

- Check existing tool names before adding new ones
- Use agent-specific prefixes if needed
- The `add_tool` method skips duplicates silently

### 3. Memory Leaks

- Always use context managers for resources
- Clean up large data structures after use
- Be careful with agent composition and memory services

### 4. Configuration Pollution

- Don't modify global settings from agents
- Use agent-specific configuration sections
- Avoid hardcoding values that should be configurable

## Callback Architecture

### Model Lifecycle Callbacks

Engineering IQ implements a comprehensive callback system for managing model and tool interactions:

#### Before Model Callback
```python
async def custom_before_model_callback_handler(
    callback_context: CallbackContext, 
    llm_request: LlmRequest
) -> LlmResponse | None:
    """
    Executed before every model call.
    - Monitors token usage and triggers context optimization
    - Returns None to proceed with normal model call
    - Returns LlmResponse to bypass model and return custom response
    """
```

**Key Features:**
- **Automatic Token Management**: Monitors request size and triggers optimization when approaching limits
- **Context Size Error Handling**: Automatically triggers `optimize_context_content` tool when limits exceeded
- **Failure Tracking**: Maintains retry counters to prevent infinite optimization loops

#### After Model Callback
```python
async def custom_after_model_response_handler(
    llm_response: LlmResponse, 
    callback_context: CallbackContext
) -> LlmResponse:
    """
    Executed after every model response.
    - Can transform responses before returning to agent
    - Currently simplified but extensible for future enhancements
    """
```

### Tool Lifecycle Callbacks

#### Before Tool Callback
```python
async def custom_before_tool_callback_handler(
    tool: BaseTool, 
    args: Dict[str, Any], 
    tool_context: ToolContext
) -> ToolContext | None:
    """
    Executed before every tool call.
    - Can modify tool context or arguments
    - Returns None to proceed normally
    - Returns modified ToolContext to alter execution
    """
```

#### After Tool Callback
```python
async def custom_after_tool_callback_handler(
    tool: BaseTool, 
    args: Dict[str, Any], 
    tool_context: ToolContext, 
    tool_response: Dict
) -> ToolContext:
    """
    Executed after every tool call.
    - Monitors tool response size
    - Automatically truncates oversized responses
    - Provides guidance for better tool usage
    """
```

**Key Features:**
- **Response Size Management**: Automatically detects oversized tool responses (>default_tool_max_tokens)
- **Intelligent Truncation**: Replaces large responses with guidance messages
- **Tool Usage Optimization**: Helps agents learn to use tools more efficiently

### Memory Optimization Integration

The callback system seamlessly integrates with the enhanced memory management:

```python
# Automatic context optimization trigger
if tokens >= app_settings.default_max_tokens:
    # Transform to optimize_context_content tool call
    return LlmResponse(
        content=types.Content(
            role="model",
            parts=[types.Part(
                function_call=types.FunctionCall(
                    name="optimize_context_content",
                    args={
                        "max_total_tokens": max_tokens_for_tool,
                        "target_reduction_ratio": 0.5
                    }
                )
            )]
        )
    )
```

## Enhanced Memory Management

### Context Optimizer Tool

Replaces the previous `optimized_memory` tool with enhanced functionality:

```python
# New context optimization
result = optimize_context_content(
    max_total_tokens=100000,
    target_reduction_ratio=0.5
)

# Returns detailed optimization metrics
{
    "message": "Context content optimized...",
    "tokens_saved": 15000,
    "parts_optimized": 12,
    "text_parts_processed": 18
}
```

**Key Improvements:**
- **Intelligent Prioritization**: Optimizes older session events first to preserve recent context
- **Structured Content Preservation**: Maintains sentence boundaries and key information
- **Detailed Reporting**: Provides metrics on optimization effectiveness
- **Adaptive Reduction**: Calculates optimal reduction ratios based on actual needs

### Enhanced File Tools

New regex replace functionality for powerful file modifications:

```python
# Regex-based find and replace
result = regex_replace_in_file(
    file_path="src/config.py",
    search_pattern=r"(\w+)_old_(\w+)",
    replacement=r"\1_new_\2",
    flags="i",  # case-insensitive
    backup=True  # automatic backup
)
```

**Safety Features:**
- **Automatic Backups**: Creates .bak files before modifications
- **Pattern Validation**: Validates regex patterns before execution
- **Memory Warnings**: Alerts for large file processing
- **Detailed Error Reporting**: Clear feedback for invalid patterns

## Architecture Decisions

### 1. Agent Composition Pattern

Engineering IQ uses a hierarchical agent composition pattern:
- Base agents provide core functionality
- Specialized agents compose and orchestrate base agents
- LoopAgent enables iterative refinement

### 2. Tool Wrapping

All tools are automatically wrapped to:
- Validate parameters
- Handle errors consistently
- Provide uniform response format
- Enable debugging/tracing

### 3. Memory Service Architecture

- Each agent hierarchy shares memory services
- Sub-agents inherit parent's memory context
- Enables information sharing within workflows
- **New**: Automatic memory optimization through callback system

### 4. Configuration Deep Merge

- Configurations are deep-merged at multiple levels
- Allows granular overrides without repetition
- Supports environment-specific settings

### 5. Extended Model Support

- LiteLLM integration for provider flexibility
- Prefix-based model routing
- Centralized model configuration

### 6. Callback-Driven Memory Management

- **Proactive Optimization**: Prevents context overflow before it occurs
- **Tool Response Management**: Automatically handles oversized tool outputs
- **Intelligent Context Reduction**: Preserves recent context while optimizing older content
- **Transparent Operation**: Works automatically without agent-specific code changes

## Testing Guidelines

### 1. Unit Testing Agents

```python
import pytest
from engineering_iq.shared.agents.my_agent import MyAgent

def test_agent_initialization():
    agent = MyAgent()
    assert agent.get_agent_settings().config_section == "my_agent"
    
def test_agent_tools():
    agent = MyAgent()
    agent.initialize_tools()
    assert len(agent.tools) > 0
```

### 2. Integration Testing

- Test agent compositions in isolation
- Mock external services (MCP servers, APIs)
- Verify memory sharing between agents

### 3. Testing Tools

```python
def test_my_tool():
    result = my_tool("test_param")
    assert result["status"] == "success"
    assert "result" in result
```

### 4. Running Tests

Run tests with pytest:
```bash
pytest
```

With coverage:
```bash
pytest --cov=engineering_iq
```

Generate HTML coverage report:
```bash
pytest --cov=engineering_iq --cov-report=html
```

## Code Quality Tools

### Code Formatting

Format code with Black:
```bash
black .
```

Configure Black in `pyproject.toml`:
```toml
[tool.black]
line-length = 88
target-version = ["py39"]
include = '\.pyi?$'
```

### Import Sorting

Sort imports with isort:
```bash
isort .
```

Configure isort in `pyproject.toml`:
```toml
[tool.isort]
profile = "black"
line_length = 88
```

### Linting

Run linting checks:
```bash
# Flake8 for style violations
flake8

# Type checking with mypy
mypy
```

Configure in `pyproject.toml`:
```toml
[tool.mypy]
python_version = "3.9"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
disallow_incomplete_defs = true
```

### Pre-commit Hooks

Set up pre-commit hooks:
```bash
pre-commit install
```

Example `.pre-commit-config.yaml`:
```yaml
repos:
  - repo: https://github.com/psf/black
    rev: 23.3.0
    hooks:
      - id: black
  
  - repo: https://github.com/pycqa/isort
    rev: 5.12.0
    hooks:
      - id: isort
  
  - repo: https://github.com/pycqa/flake8
    rev: 6.0.0
    hooks:
      - id: flake8

  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.3.0
    hooks:
      - id: mypy
```

## Best Practices Summary

1. **Keep names short** - Remember the 64-character limit
2. **Handle errors gracefully** - Especially for Google API 500 errors
3. **Manage tokens proactively** - Don't rely on automatic context resizing
4. **Use configuration wisely** - Follow the hierarchy and use environment variables
5. **Debug systematically** - Enable logging, trace execution, inspect memory
6. **Optimize for performance** - Batch operations, manage memory, choose models wisely
7. **Test thoroughly** - Unit test agents and tools, integration test workflows
8. **Document clearly** - Update this guide when you discover new patterns or issues

## Contributing

When you discover new issues or solutions:
1. Update this document
2. Add examples where helpful
3. Keep the information practical and actionable
4. Include workarounds for known issues
