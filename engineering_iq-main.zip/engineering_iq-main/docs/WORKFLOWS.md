# Engineering IQ Workflows

This document provides detailed workflow diagrams and descriptions for the Engineering IQ analysis processes.

## Table of Contents
- [Analysis Workflows](#analysis-workflows)
  - [Product Analysis Workflow](#product-analysis-workflow)
  - [Dev Analysis Workflow](#dev-analysis-workflow)
  - [QE Analysis Workflow](#qe-analysis-workflow)
  - [Feature Analysis Workflow](#feature-analysis-workflow)
  - [DevSecOps Analysis Workflow](#devsecops-analysis-workflow)
- [Task Loading Workflow](#task-loading-workflow)
- [Complete End-to-End Workflow](#complete-end-to-end-workflow)

## Analysis Workflows

Each analysis workflow follows a two-phase approach:
1. **Planning Phase**: An analysis planner creates a detailed task plan
2. **Execution Phase**: An analyzer executes the plan and generates reports

### Product Analysis Workflow

The Product Analysis workflow focuses on business and functional requirements of a codebase.

```mermaid
graph TD
    Start([User initiates Product Analysis]) --> Clone{Need to clone?}
    Clone -->|Yes| GitHelper[Git Helper Agent<br/>Clones repository]
    Clone -->|No| LocalPath[Use local repository path]
    
    GitHelper --> ProductPlanner
    LocalPath --> ProductPlanner
    
    ProductPlanner[Product Analysis Planner<br/>Analyzes repository structure] --> CreatePlan[Creates analysis plan<br/>with business-focused tasks]
    
    CreatePlan --> TaskFile[Generates ANALYSIS_TASKS.md<br/>in /agent_reports/product/]
    
    TaskFile --> ProductAnalyzer[Product Analyzer Agent<br/>Reads task file]
    
    ProductAnalyzer --> Execute{Execute Tasks}
    
    Execute --> T1[Analyze User Personas<br/>& Journeys]
    Execute --> T2[Catalog Features<br/>& Capabilities]
    Execute --> T3[Extract Business Rules<br/>& Logic]
    Execute --> T4[Document Data Models<br/>& Entities]
    Execute --> T5[Identify Integrations<br/>& Dependencies]
    
    T1 --> Coordinate[Coordinates with<br/>utility agents]
    T2 --> Coordinate
    T3 --> Coordinate
    T4 --> Coordinate
    T5 --> Coordinate
    
    Coordinate --> FileHelper[File Helper<br/>Reads & analyzes files]
    Coordinate --> DevAnalyst[Dev Analyst<br/>Understands code structure]
    Coordinate --> TaskAdherence[Task Adherence<br/>Ensures focus]
    
    FileHelper --> Report
    DevAnalyst --> Report
    TaskAdherence --> Report
    
    Report[Generate Business<br/>Requirements Report] --> Review[Final Reviewer Agent<br/>Reviews completeness]
    
    Review --> Output([Business Analysis<br/>Report Complete])
    
    style Start fill:#e1f5fe
    style Output fill:#c8e6c9
    style ProductPlanner fill:#fff3e0
    style ProductAnalyzer fill:#fff3e0
    style GitHelper fill:#f3e5f5
    style FileHelper fill:#f3e5f5
    style DevAnalyst fill:#f3e5f5
    style TaskAdherence fill:#f3e5f5
    style Review fill:#f3e5f5
```

#### Product Analysis Key Components:

1. **Product Analysis Planner**
   - Examines repository structure and file types
   - Identifies business-relevant files (configs, UI components, data models)
   - Creates a comprehensive task plan focusing on:
     - User personas and journeys
     - Feature catalog and capabilities
     - Business rules and validation logic
     - Data models and entities
     - External integrations

2. **Product Analyzer**
   - Executes the task plan systematically
   - Coordinates utility agents to gather information
   - Generates a business requirements report including:
     - Executive summary
     - Functional requirements
     - User interface analysis
     - Data flow documentation
     - Integration points

### Dev Analysis Workflow

The Dev Analysis workflow focuses on technical architecture and implementation details.

```mermaid
graph TD
    Start([User initiates Dev Analysis]) --> Clone{Need to clone?}
    Clone -->|Yes| GitHelper[Git Helper Agent<br/>Clones repository]
    Clone -->|No| LocalPath[Use local repository path]
    
    GitHelper --> DevPlanner
    LocalPath --> DevPlanner
    
    DevPlanner[Dev Analysis Planner<br/>Analyzes codebase structure] --> CreatePlan[Creates analysis plan<br/>with technical tasks]
    
    CreatePlan --> TaskFile[Generates ANALYSIS_TASKS.md<br/>in /agent_reports/dev/]
    
    TaskFile --> DevAnalyzer[Dev Analyzer Agent<br/>Reads task file]
    
    DevAnalyzer --> Execute{Execute Tasks}
    
    Execute --> T1[Analyze Architecture<br/>& Design Patterns]
    Execute --> T2[Document Tech Stack<br/>& Dependencies]
    Execute --> T3[Review Code Quality<br/>& Standards]
    Execute --> T4[Assess Performance<br/>& Scalability]
    Execute --> T5[Security Analysis<br/>& Best Practices]
    
    T1 --> Coordinate[Coordinates with<br/>utility agents]
    T2 --> Coordinate
    T3 --> Coordinate
    T4 --> Coordinate
    T5 --> Coordinate
    
    Coordinate --> FileHelper[File Helper<br/>Reads source files]
    Coordinate --> DevAnalyst[Dev Analyst<br/>Analyzes code symbols]
    Coordinate --> Diagramer[Diagramer<br/>Creates architecture diagrams]
    Coordinate --> Search[Simple Search<br/>Research best practices]
    
    FileHelper --> Report
    DevAnalyst --> Report
    Diagramer --> Report
    Search --> Report
    
    Report[Generate Technical<br/>Architecture Report] --> Review[Final Reviewer Agent<br/>Reviews accuracy]
    
    Review --> Output([Technical Analysis<br/>Report Complete])
    
    style Start fill:#e1f5fe
    style Output fill:#c8e6c9
    style DevPlanner fill:#ffebee
    style DevAnalyzer fill:#ffebee
    style GitHelper fill:#f3e5f5
    style FileHelper fill:#f3e5f5
    style DevAnalyst fill:#f3e5f5
    style Diagramer fill:#f3e5f5
    style Search fill:#f3e5f5
    style Review fill:#f3e5f5
```

#### Dev Analysis Key Components:

1. **Dev Analysis Planner**
   - Analyzes technology stack and frameworks
   - Identifies architectural patterns
   - Creates technical analysis tasks covering:
     - System architecture and design patterns
     - Technology stack assessment
     - Code organization and modularity
     - Performance considerations
     - Security implementations

2. **Dev Analyzer**
   - Executes technical analysis systematically
   - Uses specialized tools for code understanding
   - Produces technical documentation including:
     - Architecture overview with diagrams
     - Technology inventory
     - Code quality assessment
     - Performance analysis
     - Security review
     - Deployment architecture

### QE Analysis Workflow

The QE Analysis workflow focuses on testing strategy and quality engineering.

```mermaid
graph TD
    Start([User initiates QE Analysis]) --> Clone{Need to clone?}
    Clone -->|Yes| GitHelper[Git Helper Agent<br/>Clones repository]
    Clone -->|No| LocalPath[Use local repository path]
    
    GitHelper --> QEPlanner
    LocalPath --> QEPlanner
    
    QEPlanner[QE Analysis Planner<br/>Analyzes test structure] --> CreatePlan[Creates test strategy plan<br/>with QE-focused tasks]
    
    CreatePlan --> TaskFile[Generates TEST_STRATEGY_TASKS.md<br/>in /agent_reports/test/]
    
    TaskFile --> QEAnalyzer[QE Analyzer Agent<br/>Reads task file]
    
    QEAnalyzer --> Execute{Execute Tasks}
    
    Execute --> T1[Analyze Existing Tests<br/>& Coverage]
    Execute --> T2[Identify Test Gaps<br/>& Risks]
    Execute --> T3[Define Test Strategy<br/>& Approach]
    Execute --> T4[Document Test Cases<br/>& Scenarios]
    Execute --> T5[Automation Framework<br/>Recommendations]
    
    T1 --> Coordinate[Coordinates with<br/>utility agents]
    T2 --> Coordinate
    T3 --> Coordinate
    T4 --> Coordinate
    T5 --> Coordinate
    
    Coordinate --> FileHelper[File Helper<br/>Analyzes test files]
    Coordinate --> QEAnalyst[QE Analyst<br/>Reviews test patterns]
    Coordinate --> DevAnalyst[Dev Analyst<br/>Understands code coverage]
    Coordinate --> Planner[Planner Agent<br/>Creates test plans]
    
    FileHelper --> Report
    QEAnalyst --> Report
    DevAnalyst --> Report
    Planner --> Report
    
    Report[Generate Test<br/>Strategy Report] --> Review[Final Reviewer Agent<br/>Reviews completeness]
    
    Review --> Output([Test Strategy<br/>Report Complete])
    
    style Start fill:#e1f5fe
    style Output fill:#c8e6c9
    style QEPlanner fill:#e8f5e9
    style QEAnalyzer fill:#e8f5e9
    style GitHelper fill:#f3e5f5
    style FileHelper fill:#f3e5f5
    style QEAnalyst fill:#f3e5f5
    style DevAnalyst fill:#f3e5f5
    style Planner fill:#f3e5f5
    style Review fill:#f3e5f5
```

#### QE Analysis Key Components:

1. **QE Analysis Planner**
   - Examines existing test infrastructure
   - Identifies testing frameworks and tools
   - Creates QE-focused tasks including:
     - Current test coverage analysis
     - Test gap identification
     - Risk assessment
     - Test strategy recommendations
     - Automation opportunities

2. **QE Analyzer**
   - Executes test strategy analysis
   - Evaluates quality engineering practices
   - Delivers comprehensive QE report with:
     - Test coverage metrics
     - Risk assessment matrix
     - Test strategy roadmap
     - Automation recommendations
     - Quality gates definition

### Feature Analysis Workflow

The Feature Analysis workflow focuses on analyzing the impact of new feature requirements on the existing codebase.

```mermaid
graph TD
    Start([User provides<br/>Feature Requirements]) --> Clone{Need to clone?}
    Clone -->|Yes| GitHelper[Git Helper Agent<br/>Clones repository]
    Clone -->|No| LocalPath[Use local repository path]
    
    GitHelper --> FeaturePlanner
    LocalPath --> FeaturePlanner
    
    FeaturePlanner[Feature Analysis Planner<br/>Creates feature impact plan] --> CreatePlan[Creates analysis plan<br/>with comprehensive tasks]
    
    CreatePlan --> TaskFile[Generates FEATURE_ANALYSIS_TASKS.md<br/>in /agent_reports/feature/]
    
    TaskFile --> FeatureAnalyzer[Feature Analyzer Agent<br/>Reads task file]
    
    FeatureAnalyzer --> Loop{Orchestrate Analysis<br/>Loop}
    
    Loop --> DevAnalystLoop[Dev Analyst<br/>Code Impact Analysis]
    Loop --> QEAnalystLoop[QE Analyst<br/>Testing Impact Analysis]
    
    DevAnalystLoop --> T1[Analyze Requirements<br/>& Dependencies]
    DevAnalystLoop --> T2[Identify Affected<br/>Components]
    DevAnalystLoop --> T3[Design<br/>Recommendations]
    
    QEAnalystLoop --> T4[Test Impact<br/>Assessment]
    QEAnalystLoop --> T5[Test Strategy<br/>Updates]
    QEAnalystLoop --> T6[Risk<br/>Evaluation]
    
    T1 --> Synthesize[Synthesize Results]
    T2 --> Synthesize
    T3 --> Synthesize
    T4 --> Synthesize
    T5 --> Synthesize
    T6 --> Synthesize
    
    Synthesize --> Analysis[Generate Comprehensive<br/>Feature Analysis]
    
    Analysis --> Complexity[Complexity & Effort<br/>Assessment]
    Analysis --> Alternatives[Alternative<br/>Implementations]
    Analysis --> Future[Forward-Looking<br/>Considerations]
    
    Complexity --> Report
    Alternatives --> Report
    Future --> Report
    
    Report[Generate Feature<br/>Impact Report] --> Review[Final Reviewer Agent<br/>Reviews analysis]
    
    Review --> Output([Feature Analysis<br/>Report Complete])
    
    style Start fill:#e1f5fe
    style Output fill:#c8e6c9
    style FeaturePlanner fill:#fce4ec
    style FeatureAnalyzer fill:#fce4ec
    style GitHelper fill:#f3e5f5
    style DevAnalystLoop fill:#f3e5f5
    style QEAnalystLoop fill:#f3e5f5
    style Review fill:#f3e5f5
```

#### Feature Analysis Key Components:

1. **Feature Analysis Planner**
   - Analyzes feature requirements provided by the user
   - Creates comprehensive impact analysis tasks
   - Plans for multiple perspectives:
     - Requirements clarification and analysis
     - Code impact assessment
     - Testing impact evaluation
     - Design and architecture considerations
     - Complexity and effort estimation
     - Alternative approaches

2. **Feature Analyzer**
   - Orchestrates analysis using both Dev and QE Analysts in a loop
   - Combines development and testing perspectives
   - Produces comprehensive feature analysis including:
     - Executive summary of feature impact
     - Detailed requirements analysis
     - Component impact mapping
     - Design recommendations with alternatives
     - Complexity and effort estimates
     - Risk assessment
     - Implementation roadmap
     - Future scalability considerations

3. **Unique Characteristics**
   - Uses a loop agent pattern for comprehensive coverage
   - Provides both code and testing perspectives
   - Evaluates multiple implementation approaches
   - Considers long-term implications
   - Ideal for major feature planning and impact assessment

### DevSecOps Analysis Workflow

The DevSecOps Analysis workflow focuses on security, compliance, and DevOps practices within the codebase.

```mermaid
graph TD
    Start([User initiates DevSecOps Analysis]) --> Clone{Need to clone?}
    Clone -->|Yes| GitHelper[Git Helper Agent<br/>Clones repository]
    Clone -->|No| LocalPath[Use local repository path]
    
    GitHelper --> DevSecOpsPlanner
    LocalPath --> DevSecOpsPlanner
    
    DevSecOpsPlanner[DevSecOps Analysis Planner<br/>Analyzes security & ops structure] --> CreatePlan[Creates analysis plan<br/>with security-focused tasks]
    
    CreatePlan --> TaskFile[Generates ANALYSIS_TASKS.md<br/>in /agent_reports/devsecops/]
    
    TaskFile --> DevSecOpsAnalyzer[DevSecOps Analyzer Agent<br/>Reads task file]
    
    DevSecOpsAnalyzer --> Execute{Execute Tasks}
    
    Execute --> T1[Security Architecture<br/>& Implementation Analysis]
    Execute --> T2[Compliance Requirements<br/>& Audit Trails]
    Execute --> T3[DevOps Pipeline<br/>Security Assessment]
    Execute --> T4[Infrastructure as Code<br/>Security Review]
    Execute --> T5[Vulnerability Assessment<br/>& Scanning]
    Execute --> T6[Deployment Security<br/>& Monitoring]
    
    T1 --> Coordinate[Coordinates with<br/>utility agents]
    T2 --> Coordinate
    T3 --> Coordinate
    T4 --> Coordinate
    T5 --> Coordinate
    T6 --> Coordinate
    
    Coordinate --> FileHelper[File Helper<br/>Analyzes config & pipeline files]
    Coordinate --> DevSecOpsAnalyst[DevSecOps Analyst<br/>Security & compliance analysis]
    Coordinate --> DevAnalyst[Dev Analyst<br/>Code security patterns]
    Coordinate --> TaskAdherence[Task Adherence<br/>Ensures security focus]
    
    FileHelper --> Report
    DevSecOpsAnalyst --> Report
    DevAnalyst --> Report
    TaskAdherence --> Report
    
    Report[Generate Security &<br/>Compliance Report] --> Review[Final Reviewer Agent<br/>Reviews security completeness]
    
    Review --> Output([DevSecOps Analysis<br/>Report Complete])
    
    style Start fill:#e1f5fe
    style Output fill:#c8e6c9
    style DevSecOpsPlanner fill:#fce4ec
    style DevSecOpsAnalyzer fill:#fce4ec
    style GitHelper fill:#f3e5f5
    style FileHelper fill:#f3e5f5
    style DevSecOpsAnalyst fill:#f3e5f5
    style DevAnalyst fill:#f3e5f5
    style TaskAdherence fill:#f3e5f5
    style Review fill:#f3e5f5
```

#### DevSecOps Analysis Key Components:

1. **DevSecOps Analysis Planner**
   - Examines security configurations and DevOps infrastructure
   - Identifies security and compliance requirements
   - Creates DevSecOps-focused tasks including:
     - Security architecture assessment
     - Compliance requirements analysis
     - DevOps pipeline security review
     - Infrastructure as code security evaluation
     - Vulnerability scanning and assessment
     - Deployment security and monitoring

2. **DevSecOps Analyzer**
   - Executes comprehensive security and compliance analysis
   - Evaluates DevOps practices and security implementations
   - Delivers comprehensive DevSecOps report with:
     - Security architecture overview
     - Compliance gap analysis
     - Vulnerability assessment results
     - DevOps pipeline security evaluation
     - Infrastructure security recommendations
     - Security monitoring and alerting assessment
     - Remediation roadmap and priorities

3. **Key Focus Areas**
   - **Security**: Authentication, authorization, encryption, data protection
   - **Compliance**: Regulatory requirements, audit trails, documentation
   - **DevOps**: Pipeline security, infrastructure as code, deployment practices
   - **Monitoring**: Security logging, alerting, incident response
   - **Risk Assessment**: Threat modeling, vulnerability prioritization

## Task Loading Workflow

After analysis completion, tasks can be loaded into project management systems.

```mermaid
graph TD
    Start([Analysis Reports Complete]) --> TaskLoader[Task Loader Agent<br/>Reads analysis outputs]
    
    TaskLoader --> Parse{Parse Tasks}
    
    Parse --> ProductTasks[Product Analysis Tasks]
    Parse --> DevTasks[Dev Analysis Tasks]
    Parse --> QETasks[QE Analysis Tasks]
    
    ProductTasks --> Transform[Transform to<br/>Jira Format]
    DevTasks --> Transform
    QETasks --> Transform
    
    Transform --> JiraAgent[Jira Agent<br/>via MCP Server]
    
    JiraAgent --> CreateItems{Create Jira Items}
    
    CreateItems --> Epic[Create Epics<br/>for major initiatives]
    CreateItems --> Story[Create Stories<br/>for features]
    CreateItems --> Task[Create Tasks<br/>for specific work]
    CreateItems --> Bug[Create Bugs<br/>for issues found]
    
    Epic --> Link[Link Related Items]
    Story --> Link
    Task --> Link
    Bug --> Link
    
    Link --> Assign[Assign to Team Members<br/>Set priorities & estimates]
    
    Assign --> Output([Tasks Loaded<br/>to Jira])
    
    style Start fill:#e1f5fe
    style Output fill:#c8e6c9
    style TaskLoader fill:#fff9c4
    style JiraAgent fill:#f3e5f5
```

## Complete End-to-End Workflow

This diagram shows the complete flow from repository analysis to task management.

```mermaid
graph TB
    Start([Start Analysis]) --> GitClone[1. Clone Repository<br/>Git Helper Agent]
    
    GitClone --> Parallel{Run Analyses<br/>In Parallel}
    
    Parallel --> ProductFlow[Product Analysis Flow]
    Parallel --> DevFlow[Dev Analysis Flow]
    Parallel --> QEFlow[QE Analysis Flow]
    Parallel --> FeatureFlow[Feature Analysis Flow]
    Parallel --> DevSecOpsFlow[DevSecOps Analysis Flow]
    
    ProductFlow --> ProductPlan[Product Planner<br/>Creates business tasks]
    ProductPlan --> ProductExec[Product Analyzer<br/>Generates report]
    
    DevFlow --> DevPlan[Dev Planner<br/>Creates technical tasks]
    DevPlan --> DevExec[Dev Analyzer<br/>Generates report]
    
    QEFlow --> QEPlan[QE Planner<br/>Creates test tasks]
    QEPlan --> QEExec[QE Analyzer<br/>Generates report]
    
    FeatureFlow --> FeaturePlan[Feature Planner<br/>Creates impact tasks]
    FeaturePlan --> FeatureExec[Feature Analyzer<br/>Generates report]
    
    DevSecOpsFlow --> DevSecOpsPlan[DevSecOps Planner<br/>Creates security tasks]
    DevSecOpsPlan --> DevSecOpsExec[DevSecOps Analyzer<br/>Generates report]
    
    ProductExec --> Reports[All Reports<br/>Complete]
    DevExec --> Reports
    QEExec --> Reports
    FeatureExec --> Reports
    DevSecOpsExec --> Reports
    
    Reports --> Decision{Load to Jira?}
    
    Decision -->|Yes| TaskLoad[Task Loader<br/>Processes all tasks]
    Decision -->|No| End1([Analysis Complete])
    
    TaskLoad --> Jira[Create Jira Items<br/>Epics, Stories, Tasks]
    
    Jira --> End2([Complete with<br/>Jira Integration])
    
    style Start fill:#e1f5fe
    style End1 fill:#c8e6c9
    style End2 fill:#c8e6c9
    style ProductFlow fill:#fff3e0
    style DevFlow fill:#ffebee
    style QEFlow fill:#e8f5e9
    style FeatureFlow fill:#fce4ec
    style DevSecOpsFlow fill:#f3e5f5
    style TaskLoad fill:#fff9c4
```

## Best Practices for Workflows

1. **Sequential vs Parallel Execution**
   - Analyses can run in parallel if you have multiple terminal sessions
   - Each analyzer works independently once the planner creates the task file

2. **Restarting Interrupted Workflows**
   - Task files track progress automatically
   - Simply provide the task file path to resume where you left off

3. **Customizing Workflows**
   - Add custom report sections via config.yaml
   - Extend analysis scope with additional_report_sections

4. **Optimization Tips**
   - Run planners first to review task scope
   - Adjust task files manually if needed before running analyzers
   - Use Final Reviewer feedback to improve report quality

## Common Workflow Patterns

### Quick Analysis
```
Git Helper → Single Planner → Single Analyzer
```

### Comprehensive Analysis
```
Git Helper → All Planners → All Analyzers → Task Loader
```

### Targeted Technical Review
```
Local Path → Dev Planner → Dev Analyzer
```

### Test Strategy Only
```
Local Path → QE Planner → QE Analyzer
```

### Feature Impact Analysis
```
Local Path → Feature Analysis Planner → Feature Analyzer
```
This workflow is ideal when you need to:
- Evaluate how a new feature will impact the existing codebase
- Get both development and testing perspectives
- Compare multiple implementation approaches
- Understand complexity and effort requirements
- Plan for long-term maintainability

### Security & Compliance Analysis
```
Local Path → DevSecOps Analysis Planner → DevSecOps Analyzer
```
This workflow is ideal when you need to:
- Assess security architecture and implementation
- Evaluate compliance with regulatory requirements
- Review DevOps pipeline security practices
- Analyze infrastructure as code security
- Conduct vulnerability assessments
- Review deployment security and monitoring
