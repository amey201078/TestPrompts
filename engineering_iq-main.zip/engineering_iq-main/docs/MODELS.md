# Model Configuration in Engineering IQ

Engineering IQ supports multiple language model providers beyond Google's models through the LiteLLM integration. This document explains how to configure and use different model providers.

## Table of Contents
- [Supported Model Providers](#supported-model-providers)
- [Model Configuration](#model-configuration)
- [Using Non-Google Models](#using-non-google-models)
- [Provider-Specific Setup](#provider-specific-setup)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)

## Supported Model Providers

Engineering IQ supports any model provider that is compatible with LiteLLM, including:

- **Google Models** (default)
  - Gemini models (e.g., `gemini-2.5-pro-preview-05-06`)
  - No prefix needed for Google models

- **Anthropic**
  - Claude models (e.g., `LiteLlm:anthropic/claude-3-5-sonnet-20241022`)
  
- **OpenAI**
  - GPT models (e.g., `LiteLlm:gpt-4-turbo-preview`)
  
- **Azure OpenAI**
  - Azure-hosted models (e.g., `LiteLlm:azure/<deployment_name>`)
  
- **AWS Bedrock**
  - Various models (e.g., `LiteLlm:bedrock/anthropic.claude-3-sonnet-20240229-v1:0`)
  
- **Local Models**
  - Ollama (e.g., `LiteLlm:ollama/llama2`)
  - vLLM endpoints
  - Any OpenAI-compatible endpoint

## Model Configuration

Models can be configured at multiple levels in Engineering IQ:

### 1. Global Default Model

Set the default model for all agents in `config.yaml`:

```yaml
app:
  default_model: gemini-2.5-pro-preview-05-06  # Google model (no prefix)
  # OR
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022  # Non-Google model
```

### 2. Per-Agent Model Configuration

Override the model for specific agents:

```yaml
# Example: Use Claude for dev analysis
dev_analyzer_agent:
  model: LiteLlm:anthropic/claude-3-5-sonnet-20241022

# Example: Use GPT-4 for app analysis  
product_analyzer_agent:
  model: LiteLlm:gpt-4-turbo-preview

# Example: Keep Google model for QE analysis
qe_analyzer_agent:
  model: gemini-2.5-pro-preview-05-06
```

### 3. Environment Variable Configuration

Set models via environment variables:

```bash
# Global default
export APP_DEFAULT_MODEL="LiteLlm:anthropic/claude-3-5-sonnet-20241022"

# Per-agent
export DEV_ANALYZER_AGENT_MODEL="LiteLlm:gpt-4-turbo-preview"
export PRODUCT_ANALYZER_AGENT_MODEL="LiteLlm:azure/my-gpt4-deployment"
```

### 4. Configuration Hierarchy

The configuration follows this priority order (highest to lowest):
1. Environment variables (e.g., `DEV_ANALYZER_AGENT_MODEL`)
2. Local config.yaml overrides
3. Default agent configuration files
4. Global default model setting

## Using Non-Google Models

To use models from providers other than Google, prefix the model name with `LiteLlm:`:

### Format
```
LiteLlm:<provider>/<model-name>
```

### Examples

#### Anthropic Claude
```yaml
app:
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
```

#### OpenAI GPT
```yaml
dev_analyzer_agent:
  model: LiteLlm:gpt-4-turbo-preview
```

#### Azure OpenAI
```yaml
qe_analyzer_agent:
  model: LiteLlm:azure/my-gpt4-deployment
```

#### AWS Bedrock
```yaml
product_analyzer_agent:
  model: LiteLlm:bedrock/anthropic.claude-3-sonnet-20240229-v1:0
```

## Provider-Specific Setup

Each provider requires specific authentication setup:

### Anthropic

Set your API key:
```bash
export ANTHROPIC_API_KEY="your-api-key"
```

### OpenAI

Set your API key:
```bash
export OPENAI_API_KEY="your-api-key"
```

### Azure OpenAI

Configure Azure-specific settings:
```bash
export AZURE_API_KEY="your-api-key"
export AZURE_API_BASE="https://your-resource.openai.azure.com/"
export AZURE_API_VERSION="2024-02-15-preview"
```

For deployment-specific configuration:
```yaml
# In config.yaml
litellm_settings:
  azure_deployments:
    - deployment_name: my-gpt4-deployment
      model: gpt-4-turbo
      api_base: https://my-resource.openai.azure.com/
      api_version: 2024-02-15-preview
```

### AWS Bedrock

Configure AWS credentials:
```bash
export AWS_ACCESS_KEY_ID="your-access-key"
export AWS_SECRET_ACCESS_KEY="your-secret-key"
export AWS_REGION_NAME="us-east-1"
```

### Local Models (Ollama)

For Ollama:
```bash
# Start Ollama server
ollama serve

# Use in config
app:
  default_model: LiteLlm:ollama/llama2
```

### Custom OpenAI-Compatible Endpoints

```yaml
app:
  default_model: LiteLlm:openai/my-model
  
litellm_settings:
  api_base: http://localhost:8000/v1  # Your custom endpoint
```

## Best Practices

### 1. Model Selection Guidelines

- **Google Models**: Best for general-purpose analysis with large context windows
- **Claude Models**: Excellent for code understanding and technical writing
- **GPT-4**: Strong for complex reasoning and architectural analysis
- **Local Models**: Good for privacy-sensitive codebases

### 2. Context Window Considerations

Different models have different context limits:

```yaml
# Adjust max tokens based on model
app:
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
  default_max_tokens: 100000  # Claude's context window
  
# For GPT-4
app:
  default_model: LiteLlm:gpt-4-turbo-preview
  default_max_tokens: 128000  # GPT-4 Turbo's context window
```

### 3. Cost Optimization

Mix models based on task requirements:

```yaml
# Use cheaper models for simple tasks
file_helper_agent:
  model: LiteLlm:gpt-3.5-turbo

# Use powerful models for complex analysis
dev_analyzer_agent:
  model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
```

### 4. Fallback Configuration

Set up fallbacks for reliability:

```yaml
# Primary model
app:
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022

# Fallback models (requires custom implementation)
app:
  fallback_models:
    - gemini-2.5-pro-preview-05-06
    - LiteLlm:gpt-4-turbo-preview
```

## Troubleshooting

### Common Issues

| Issue | Solution |
|-------|----------|
| "Model not found" error | Ensure the model name is correct and prefixed with `LiteLlm:` for non-Google models |
| Authentication errors | Check that API keys are set in environment variables |
| Rate limiting | Implement retry logic or use multiple API keys |
| Context window errors | Adjust `default_max_tokens` to match your model's limits |
| Azure deployment issues | Verify deployment name matches Azure configuration |
| Local model connection | Ensure local model server is running and accessible |

### Debug Model Loading

Enable debug logging to see model loading details:

```yaml
logger:
  level: DEBUG
```

Check logs for:
```
INFO: Using model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
DEBUG: Model configuration loaded from: app.default_model
```

### Verify Model Configuration

To verify which model an agent is using:

1. Check the agent's configuration file
2. Look for environment variable overrides
3. Review your local config.yaml
4. Check debug logs during agent initialization

### Testing Different Models

Test model configuration without running full analysis:

```python
# Quick test script
from engineering_iq.shared.core.extentded_model_support import get_model

# Test model loading
model = get_model("LiteLlm:anthropic/claude-3-5-sonnet-20241022")
print(f"Loaded model: {model}")
```

## Examples

### Multi-Model Configuration

```yaml
# config.yaml - Using different models for different purposes
app:
  default_model: gemini-2.5-pro-preview-05-06  # Default to Google

# Business analysis with Claude
product_analyzer_agent:
  model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
  
# Technical analysis with GPT-4
dev_analyzer_agent:
  model: LiteLlm:gpt-4-turbo-preview
  
# Test strategy with Gemini
qe_analyzer_agent:
  model: gemini-2.5-pro-preview-05-06

# Utility agents with efficient models
file_helper_agent:
  model: LiteLlm:gpt-3.5-turbo

simple_search_agent:
  model: LiteLlm:gpt-3.5-turbo
```

### Environment-Based Configuration

```bash
# development.env
export APP_DEFAULT_MODEL="LiteLlm:ollama/llama2"  # Local model for dev

# production.env  
export APP_DEFAULT_MODEL="LiteLlm:anthropic/claude-3-5-sonnet-20241022"  # Powerful model for prod
```

### Provider Migration Example

Migrating from Google to Anthropic:

```yaml
# Before
app:
  default_model: gemini-2.5-pro-preview-05-06

# After
app:
  default_model: LiteLlm:anthropic/claude-3-5-sonnet-20241022
  default_max_tokens: 100000  # Adjust for Claude's context window
```

## Additional Resources

- [LiteLLM Documentation](https://docs.litellm.ai/docs/providers)
- [Model Pricing Comparison](https://docs.litellm.ai/docs/proxy/cost_tracking)
- [Provider API Documentation](https://docs.litellm.ai/docs/providers)
