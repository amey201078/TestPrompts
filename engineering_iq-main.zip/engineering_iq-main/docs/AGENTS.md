# Engineering IQ Agents Reference

This document provides detailed information about all agents available in Engineering IQ.

## Table of Contents
- [Agent Categories](#agent-categories)
- [Analysis Planners](#analysis-planners)
- [Report Generators](#report-generators)
- [Interactive Agents](#interactive-agents)
- [Utility Agents](#utility-agents)
- [Agent Interactions](#agent-interactions)

## Agent Categories

Engineering IQ agents are organized into four main categories:

1. **Analysis Planners** - Create detailed task plans for analyzing codebases
2. **Report Generators** - Execute task plans and generate comprehensive reports
3. **Interactive Agents** - Iteratively refine requirements through structured conversations
4. **Utility Agents** - Provide specialized support functions

## Analysis Planners

### Providing Additional Guidance

**IMPORTANT_ANALYSIS_NOTES.txt Configuration**

All analysis planners can be customized with additional guidance without modifying their prompts. Simply create a file named `IMPORTANT_ANALYSIS_NOTES.txt` in the root directory of the repository being analyzed.

**How It Works:**
- Place `IMPORTANT_ANALYSIS_NOTES.txt` in the repository root (same level as README.md)
- Planners will automatically detect and incorporate this file into their analysis
- Content should provide specific guidance, constraints, or focus areas for the analysis
- The file is read during the planning phase and influences task generation

**Example IMPORTANT_ANALYSIS_NOTES.txt:**
```text
IMPORTANT ANALYSIS NOTES

## Focus Areas
- Pay special attention to microservices architecture patterns
- This is a legacy system migration - identify modernization opportunities
- Security compliance with GDPR and SOX requirements is critical

## Constraints
- Must maintain backward compatibility with v1.2 API
- Database changes require approval from DBA team
- Performance cannot degrade more than 5% during migration

## Business Context
- Peak usage: 10,000 concurrent users during market hours
- Critical system - 99.9% uptime SLA
- Regulatory reporting deadlines cannot be missed

## Technical Priorities
- Containerization and Kubernetes migration
- Replace deprecated authentication system
- Implement proper observability and monitoring
```

**Best Practices:**
- Keep guidance specific and actionable
- Include both technical and business context
- Mention any regulatory or compliance requirements
- Note performance or architectural constraints
- Highlight areas requiring special attention

**Supported by All Planners:**
- Product Analysis Planner - Business and functional requirements guidance
- Dev Analysis Planner - Technical architecture and implementation guidance
- QE Analysis Planner - Testing strategy and quality requirements guidance
- Feature Analysis Planner - Feature-specific constraints and requirements
- DevSecOps Analysis Planner - Security, compliance, and DevOps requirements

### Product Analysis Planner
**Agent ID:** `product_analysis_planner`  
**Purpose:** Creates a task plan for analyzing business and functional requirements

**Focus Areas:**
- User personas and journeys
- Feature catalogs and capabilities
- Business rules and validation logic
- Data models and entities
- External integrations

**Output:**
- Task file: `<REPO_PATH>/agent_reports/product/ANALYSIS_TASKS.md`
- Guides the Product Analyzer in generating business requirements documentation

**Usage Example:**
```
User: Create an analysis plan for the repository at /workdir/repos/my-app
Agent: Analysis plan created. Tasks file: /workdir/repos/my-app/agent_reports/product/ANALYSIS_TASKS.md
```

### Dev Analysis Planner
**Agent ID:** `dev_analysis_planner`  
**Purpose:** Creates a task plan for analyzing technical architecture and implementation

**Focus Areas:**
- Technology stack and frameworks
- Architecture patterns and design
- Code organization and quality
- Performance and scalability
- Security implementations

**Output:**
- Task file: `<REPO_PATH>/agent_reports/dev/ANALYSIS_TASKS.md`
- Guides the Dev Analyzer in generating technical documentation

**Usage Example:**
```
User: Create a technical analysis plan for /workdir/repos/my-app
Agent: Analysis plan created. Tasks file: /workdir/repos/my-app/agent_reports/dev/ANALYSIS_TASKS.md
```

### QE Analysis Planner
**Agent ID:** `qe_analysis_planner`  
**Purpose:** Creates a task plan for analyzing testing needs and quality engineering

**Focus Areas:**
- Test strategy and coverage
- Testing frameworks and tools
- Quality engineering approaches
- Risk assessment
- Automation opportunities

**Output:**
- Task file: `<REPO_PATH>/agent_reports/test/TEST_STRATEGY_TASKS.md`
- Guides the QE Analyzer in generating test strategy documentation

**Usage Example:**
```
User: Create a test strategy plan for /workdir/repos/my-app
Agent: Analysis plan created. Tasks file: /workdir/repos/my-app/agent_reports/test/TEST_STRATEGY_TASKS.md
```

### Feature Analysis Planner
**Agent ID:** `feature_analysis_planner`  
**Purpose:** Creates a task plan for analyzing feature requirements and their impact on the codebase

**Focus Areas:**
- Requirements analysis and clarification
- Impact assessment on existing functionality
- Design recommendations and patterns
- Complexity and effort estimation
- Alternative implementation approaches
- Forward-looking considerations (scalability, maintainability)

**Output:**
- Task file: `<REPO_PATH>/agent_reports/feature/FEATURE_ANALYSIS_TASKS.md`
- Guides the Feature Analyzer in comprehensive feature impact analysis

**Usage Example:**
```
User: Create a feature analysis plan for adding user authentication to /workdir/repos/my-app
Agent: Feature analysis plan created. Tasks file: /workdir/repos/my-app/agent_reports/feature/FEATURE_ANALYSIS_TASKS.md
```

### DevSecOps Analysis Planner
**Agent ID:** `devsecops_analysis_planner`  
**Purpose:** Creates a task plan for analyzing security, compliance, and DevOps requirements

**Focus Areas:**
- Security architecture and implementation
- Compliance requirements and audit trails
- DevOps pipelines and automation
- Infrastructure as code
- Security scanning and vulnerability assessment
- Deployment security and monitoring

**Output:**
- Task file: `<REPO_PATH>/agent_reports/devsecops/ANALYSIS_TASKS.md`
- Guides the DevSecOps Analyzer in generating security and compliance documentation

**Usage Example:**
```
User: Create a DevSecOps analysis plan for /workdir/repos/my-app
Agent: Analysis plan created. Tasks file: /workdir/repos/my-app/agent_reports/devsecops/ANALYSIS_TASKS.md
```

## Report Generators

### Product Analyzer
**Agent ID:** `product_analyzer`  
**Purpose:** Executes business/functional analysis plans

**Capabilities:**
- Processes task plans from Product Analysis Planner
- Coordinates utility agents for information gathering
- Generates comprehensive business requirements reports

**Output:**
- Final report: `<REPO_PATH>/agent_reports/product/APPLICATION_REPORT.md`
- Individual task results in separate files

**Dependencies:**
- Requires task file from Product Analysis Planner
- Uses File Helper, Product Analyst, and Task Adherence agents

### Dev Analyzer
**Agent ID:** `dev_analyzer`  
**Purpose:** Executes technical analysis plans

**Capabilities:**
- Processes task plans from Dev Analysis Planner
- Performs deep technical analysis
- Creates architecture diagrams and technical documentation

**Output:**
- Final report: `<REPO_PATH>/agent_reports/dev/APPLICATION_REPORT.md`
- Technical diagrams and supplementary documentation

**Dependencies:**
- Requires task file from Dev Analysis Planner
- Uses File Helper, Dev Analyst, Diagramer, and Search agents (which may include LSP tools from `engineering_iq/shared/tools/lsp_tool/` for code understanding and search functionalities).

### QE Analyzer
**Agent ID:** `qe_analyzer`  
**Purpose:** Executes test strategy analysis plans

**Capabilities:**
- Processes task plans from QE Analysis Planner
- Analyzes existing test coverage
- Develops comprehensive test strategies

**Output:**
- Final report: `<REPO_PATH>/agent_reports/test/TEST_STRATEGY_REPORT.md`
- Test matrices and strategy documents

**Dependencies:**
- Requires task file from QE Analysis Planner
- Uses File Helper, QE Analyst, Dev Analyst, and Planner agents

### Feature Analyzer
**Agent ID:** `feature_analyzer`  
**Purpose:** Executes comprehensive feature impact analysis

**Capabilities:**
- Processes task plans from Feature Analysis Planner
- Orchestrates both development and QE perspectives
- Performs impact analysis on code and testing
- Generates design recommendations and alternatives

**Output:**
- Final report: `<REPO_PATH>/agent_reports/feature/FEATURE_ANALYSIS_REPORT.md`
- Impact assessments, design documents, and complexity evaluations

**Key Features:**
- Uses a sequential orchestration of Dev Analyst and QE Analyst
- Provides both code and testing impact perspectives
- Evaluates multiple implementation approaches
- Assesses future scalability and maintenance implications

**Dependencies:**
- Requires task file from Feature Analysis Planner
- Uses Dev Analyst and QE Analyst in a sequential workflow
- Leverages Team Lead, Task Adherence, and Final Reviewer agents

### DevSecOps Analyzer
**Agent ID:** `devsecops_analyzer`  
**Purpose:** Executes security, compliance, and DevOps analysis plans

**Capabilities:**
- Processes task plans from DevSecOps Analysis Planner
- Performs comprehensive security and compliance analysis
- Analyzes DevOps pipelines and infrastructure
- Generates security recommendations and compliance reports

**Output:**
- Final report: `<REPO_PATH>/agent_reports/devsecops/README.md`
- Individual task reports: `<REPO_PATH>/agent_reports/devsecops/TASK_<num>_<name>.md`
- Security assessments, compliance documentation, and DevOps evaluations

**Key Features:**
- Identifies security vulnerabilities and compliance gaps
- Analyzes infrastructure as code and deployment pipelines
- Provides security best practices and remediation guidance
- Assesses regulatory compliance requirements

**Dependencies:**
- Requires task file from DevSecOps Analysis Planner
- Uses File Helper, DevSecOps Analyst, Dev Analyst, and security scanning tools
- Leverages Task Adherence and Final Reviewer agents

## Interactive Agents

### Idea Iterator Agent
**Agent ID:** `idea_iterator`  
**Purpose:** Iteratively clarifies requirements and defines business outcomes through structured analysis

**Unique Architecture:**
- First agent designed for iterative interaction patterns
- Returns structured markdown documents for implementing classes to handle
- Maintains conversation context through memory/session services
- Does NOT handle human interaction directly

**Capabilities:**
- Analyzes user requirements in repository context
- Generates specific, actionable clarifying questions
- Identifies business outcomes with confidence levels
- Drafts acceptance criteria using SMART/INVEST principles
- Tracks iteration progress until ready for implementation

**Output Format:**
```markdown
# Idea Iterator Analysis - Iteration [NUMBER]

## Executive Summary
[Concise summary of what the user wants to achieve]

## Clarifying Questions

### Priority 1: Critical Questions
1. **Question**: [Specific, actionable question]
   - **Why this matters**: [Brief explanation of impact on implementation]
   - **Options** (if applicable):
     - Option A: [Description]
     - Option B: [Description]

### Priority 2: Important Questions
[Questions that would improve the solution but aren't blockers]

### Priority 3: Nice-to-Have Clarifications
[Questions for optimization or future considerations]

## Identified Business Outcomes

### High Confidence Outcomes
- **Outcome**: [Clear business outcome statement]
  - **Assumptions**: 
    - [Assumption 1]
    - [Assumption 2]

### Medium/Low Confidence Outcomes
[Outcomes that depend on clarifications]

## Draft Acceptance Criteria

### Functional Requirements
- [ ] [SMART criteria statement] - **Status**: Draft
- [ ] [SMART criteria statement] - **Status**: Needs Clarification
- [x] [SMART criteria statement] - **Status**: Confirmed

### Performance/Security/Usability Requirements
[Categorized requirements with status indicators]

## Repository Context Analysis

### Relevant Components
- `path/to/component1.py` - [How it relates to the request]
- `path/to/component2.js` - [Its relevance]

### Similar Existing Features
- **[Feature Name]** - [How it's similar and what we can learn]

### Technical Considerations
- **[Consideration 1]**: [Details and implications]

## Analysis Status
- **Iteration Number**: [NUMBER]
- **Next Iteration Needed**: Yes/No
- **Ready for Implementation**: Yes/No
- **Confidence Level**: [Overall confidence percentage]

## Next Steps
[Clear guidance on what should happen next]
```

**Integration Pattern:**
```python
# Implementing class handles the iteration loop
agent = IdeaIteratorAgent()
agent_instance = agent.get_agent()

# Process iterations until ready_for_implementation is true
# Present questions to users and collect responses
# Feed responses back to agent for next iteration
```

**Key Differentiators:**
- **Stateless Iterations**: Each call produces complete analysis
- **Context Retention**: Uses memory service for conversation history
- **No Direct UI**: Implementing class manages user interaction
- **Structured Output**: Always returns well-formatted markdown documents

**Use Cases:**
- Clarifying vague feature requests
- Defining business outcomes from high-level ideas
- Creating acceptance criteria before development
- Bridging communication gaps between stakeholders

## Utility Agents

### Generic Agent
**Usage:** `from engineering_iq.shared.agents.base import GenericAgent`  
**Purpose:** Create simple agents on the fly using configuration objects

**Features:**
- Takes an AgentSettings object for configuration
- Accepts a list of tools to use
- Supports all standard agent features (tools, memory, sessions)
- Perfect for creating sub-agents dynamically

**Usage Example:**

```python
from engineering_iq.shared.agents.base import GenericAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.tools.file_tool import read_file, write_file

# Create settings
settings = AgentSettings(
    name="file_processor",
    description="Processes files according to user instructions",
    instruction="You are a file processing agent. Read and modify files as requested.",
    model="gemini-2.0-flash-exp"
)

# Create the agent
generic_agent = GenericAgent(
    agent_settings=settings,
    tools=[read_file, write_file]
)
agent_instance = generic_agent.get_agent()
```

**Use Cases:**
- Creating sub-agents within orchestrator agents
- Dynamic agent creation based on configuration
- Simplifying agent implementation when custom logic isn't needed

### Code Understanding Agents
**Agent IDs:** `dev_analyst`, `qe_analyst`, `devsecops_analyst`, `product_analyst` (and potentially others deriving from `BaseAnalystAgent`)  
**Purpose:** Provide code analysis and understanding capabilities. These agents often build upon `BaseAnalystAgent`.

**Features:**
- Find symbols and definitions
- Search files with regex patterns
- Analyze code structure
- Provide code navigation
- Security vulnerability assessment (DevSecOps Analyst)
- Compliance and audit analysis (DevSecOps Analyst)
- Business logic and functional analysis (Product Analyst)
- User journey and business rule extraction (Product Analyst)

### Base Analyst Agent
**Location:** `engineering_iq/shared/agents/base/base_analyst_agent.py`
**Purpose:** Provides a foundational class for various analyst agents. It likely encapsulates common functionalities and toolsets used by specialized analyst agents like `DevAnalyst`, `QEAnalyst`, etc. This agent is new and provides a common base for analyst agents.

**Features (Illustrative):**
- Pre-configured with common analysis tools (e.g., file tools from `engineering_iq/shared/tools/file_tool/`, LSP tools from `engineering_iq/shared/tools/lsp_tool/`).
- Standardized structure for analyst agent development.
- May handle common input/output patterns for analysis tasks.

### File Helper Agent
**Agent ID:** `file_helper`  
**Purpose:** Memory-safe file and directory operations, primarily by leveraging the tools available in the `engineering_iq/shared/tools/file_tool/` directory.

**Capabilities:**
- Smart file reading with automatic truncation (e.g., using `smart_file_read_tool` from the file tools)
- Directory listing with result limits (e.g., using `smart_file_list_tool`)
- Safe file writing with overwrite protection (e.g., using `smart_file_write_tool`)
- Efficient text search across multiple files (e.g., using `smart_file_search_tool`)
- **File validation and property checking** (e.g., using `file_validation_tool` and `multiple_file_validation_tool`)

**File Validation Features:**
- Validate file existence before performing operations
- Check file properties (size, permissions, type)
- Batch validation for multiple files
- Distinguish between files and directories
- Comprehensive error handling for invalid paths

**Memory Management Features:**
- Automatic token counting and limits
- Truncation warnings when content is cut off
- Result limits to prevent memory overload
- Built-in usage guidance for optimal performance

**Best Practices:**
- **Validate files before processing** to avoid errors and improve reliability
- Use max_tokens parameter to control memory usage
- Check truncated field in responses
- Use search_in_files for finding content across multiple files
- **Use batch validation** for multiple files to improve efficiency
- Start with smaller token limits and increase only when needed

### Git Helper Agent
**Agent ID:** `git_helper`  
**Purpose:** Git repository operations, primarily by leveraging the tools available in the `engineering_iq/shared/tools/git_tool/` directory.

**Primary Function:**
- Clone repositories from various sources
- Return local repository paths for analysis
- Interact with Git repositories, for example, to get status, commit history, or branch information using the underlying Git tools.

**Usage Example:**
```
User: Clone https://github.com/example/repo.git
Agent: Repository cloned successfully. Local path: /workdir/repos/repo
```

### Jira Helper Agent
**Agent ID:** `jira_helper`  
**Purpose:** Jira integration and project management operations

**Capabilities:**
- Create and manage Jira issues
- Link related work items
- Set Epic Parent fields
- Apply SMART/INVEST principles to work items
- Handle project selection and validation
- Add comments and descriptions with proper formatting

**Features:**
- Automatic project validation and selection
- Jira formatting for descriptions and comments
- Markdown support for user responses
- Related issue linking
- Epic hierarchy management
- Comprehensive change tracking

**Usage Example:**
```
User: Create a Jira task for implementing user authentication
Agent: Which project should I create this in? Available projects: [PROJECT-1, PROJECT-2]
User: PROJECT-1
Agent: Task created successfully. Issue: PROJECT-1-123 - "Implement User Authentication"
```

**Integration:**
- Used by Task Loader Agent for automated task creation
- Supports MCP server integration
- Requires Jira configuration in config.yaml

### Simple Search Agent
**Agent ID:** `simple_search`  
**Purpose:** Web search capabilities

**Use Cases:**
- Research best practices
- Find documentation
- Answer technical questions
- Gather external information

### Task Adherence Agent
**Agent ID:** `task_adherence`  
**Purpose:** Keeps agents focused on assigned tasks

**Function:**
- Monitors agent responses
- Ensures task completion
- Prevents scope creep
- Maintains workflow efficiency

### Final Reviewer Agent
**Agent ID:** `final_reviewer`  
**Purpose:** Quality assurance for agent outputs

**Responsibilities:**
- Review generated content
- Check for completeness
- Verify accuracy
- Suggest improvements

### Diagramer Agent
**Agent ID:** `diagramer`  
**Purpose:** Create visual diagrams

**Capabilities:**
- Generate mermaid diagrams
- Create architecture visualizations
- Build network graphs
- Illustrate data flows

### Planner Agent
**Agent ID:** `planner`  
**Purpose:** Create structured work plans

**Function:**
- Takes requirements as input
- Generates actionable task lists
- Provides clear deliverables
- Estimates effort when possible

### Team Lead Agent
**Agent ID:** `team_lead`  
**Purpose:** Coordinate multi-agent workflows

**Responsibilities:**
- Task distribution
- Workflow orchestration
- Progress monitoring
- Result aggregation

### Task Loader Agent
**Agent ID:** `task_loader`  
**Purpose:** Loads analysis tasks from a file into Jira for project management

**Architecture:**
- Uses a loop agent pattern for iterative task processing.
- Coordinates sub-agents (potentially GenericAgent instances) for its workflow:
  - An **Orchestrator Agent** likely manages the overall process.
  - A **Task Processing Agent** (or the Task Loader itself) reads and parses task files.
  - **Jira Integration**: Achieved via tools that interact with a Jira service (e.g., through an MCP server providing Jira tools, or direct API interaction tools if available, as configured in `config.yaml` and requiring MCP server setup). The "Jira Agent" sub-component mentioned previously is now handled by this integrated Jira functionality rather than a separate, dedicated agent.

**Implementation:**
- Uses GenericAgent for dynamic sub-agent creation
- Leverages configuration from `task_loader` and `task_loader_orchestrator` settings
- Simplifies agent creation without custom classes

**Workflow:**
1. Orchestrator manages the task loading process
2. Task loader reads and parses the tasks file
3. Jira agent creates tasks with proper fields
4. Loop continues until all tasks are processed

**Usage Example:**
```
User: Load tasks from /workdir/repos/my-app/agent_reports/product/ANALYSIS_TASKS.md
Agent: Reading tasks file...
Agent: Creating Jira task 1 of 12...
Agent: All tasks successfully created in project INS
```

**Requirements:**
- Valid tasks file path
- Jira configuration in config.yaml
- MCP server setup for Jira integration

## Agent Interactions

### Hierarchical Structure

```mermaid
graph TD
    subgraph "Analysis Planning"
        PAP[Product Analysis Planner]
        DEV[Dev Analysis Planner]
        QE[QE Analysis Planner]
        FAP[Feature Analysis Planner]
        DSOP[DevSecOps Analysis Planner]
    end
    
    subgraph "Report Generation"
        PA[Product Analyzer]
        DA[Dev Analyzer]
        QA[QE Analyzer]
        FA[Feature Analyzer]
        DSO[DevSecOps Analyzer]
    end
    
    subgraph "Interactive Agents"
        II[Idea Iterator]
    end
    
    subgraph "Utility Agents"
        FH[File Helper]
        GH[Git Helper]
        JH[Jira Helper]
        SS[Simple Search]
        TA[Task Adherence]
        FR[Final Reviewer]
        DG[Diagramer]
        PL[Planner]
        TL[Team Lead]
        TLA[Task Loader]
        DANA[Dev Analyst]
        QANA[QE Analyst]
        DSOA[DevSecOps Analyst]
        PANA[Product Analyst]
    end

    subgraph "External Integrations (via MCP or direct tools)"
        JIRA_MCP[Jira Integration via MCP/Tools]
    end
    
    II --> PAP
    II --> FAP
    
    PAP --> PA
    DEV --> DA
    QE --> QA
    FAP --> FA
    DSOP --> DSO
    
    PA --> FH
    PA --> PANA
    PA --> TA
    PA --> FR
    
    DA --> FH
    DA --> DANA
    DA --> DG
    DA --> SS
    DA --> FR
    
    QA --> FH
    QA --> QANA
    QA --> DANA
    QA --> PL
    QA --> FR
    
    FA --> FH
    FA --> DANA
    FA --> QANA
    FA --> TL
    FA --> TA
    FA --> FR
    
    DSO --> FH
    DSO --> DSOA
    DSO --> DANA
    DSO --> TA
    DSO --> FR
    
    PA --> TLA
    DA --> TLA
    QA --> TLA
    FA --> TLA
    DSO --> TLA
    
    TLA --> JH
    TLA --> JIRA_MCP
```

### Common Agent Combinations

1. **Full Analysis Pipeline**
   ```
   Git Helper → All Planners → All Analyzers → Task Loader
   ```

2. **Technical Review Only**
   ```
   Dev Analysis Planner → Dev Analyzer
   ```

3. **Business Requirements Focus**
   ```
   Product Analysis Planner → Product Analyzer → Task Loader
   ```

4. **Test Strategy Development**
   ```
   QE Analysis Planner → QE Analyzer
   ```

5. **Feature Impact Analysis**
   ```
   Feature Analysis Planner → Feature Analyzer
   ```
   This combination is ideal for:
   - Evaluating new feature requirements
   - Assessing implementation complexity
   - Understanding cross-cutting concerns
   - Planning major enhancements

6. **Interactive Requirements Refinement**
   ```
   Idea Iterator → (iterative clarification) → Feature/Product Planner → Analyzer
   ```
   This new pattern enables:
   - Transforming vague ideas into clear requirements
   - Iterative stakeholder engagement
   - Building consensus before development
   - Creating well-defined acceptance criteria

7. **Security & Compliance Analysis**
   ```
   DevSecOps Analysis Planner → DevSecOps Analyzer
   ```
   This combination is ideal for:
   - Security vulnerability assessments
   - Compliance audits and regulatory reviews
   - DevOps pipeline security analysis
   - Infrastructure as code security evaluation

### Agent Communication

Agents communicate through:
- **Task Files**: Planners create structured task files for analyzers
- **Shared Memory**: Agents in the same workflow share memory context
- **File System**: Results are written to predictable locations
- **Tool Calls**: Agents invoke each other's capabilities as tools

### Best Practices for Agent Usage

1. **Always Start with Planners**: They create the structure for thorough analysis
2. **Use Appropriate Combinations**: Match agent selection to your goals
3. **Leverage Utility Agents**: They provide powerful supporting capabilities
4. **Monitor Progress**: Task files track completion status
5. **Review Outputs**: Use Final Reviewer feedback to improve results
