import typer

from google.adk.memory import BaseMemoryService, InMemoryMemoryService
from google.adk.sessions import BaseSessionService, InMemorySessionService
from google.adk.artifacts import BaseArtifactService, InMemoryArtifactService

from engineering_iq.shared.mcp.dev_server_endpoints import DevServerEndpoints

from fastmcp import FastMCP

####################################################################################
# Temporary monkeypatch which avoids crashing when a POST message is received
# before a connection has been initialized, e.g: after a deployment.
# pylint: disable-next=protected-access

from mcp.server.session import ServerSession

old__received_request = ServerSession._received_request

async def _received_request(self, *args, **kwargs):
    try:
        return await old__received_request(self, *args, **kwargs)
    except RuntimeError:
        pass

# pylint: disable-next=protected-access
ServerSession._received_request = _received_request

####################################################################################
# Finally, the implementation

memory_service: BaseMemoryService = InMemoryMemoryService()
session_service: BaseSessionService = InMemorySessionService()
artifact_service: BaseArtifactService = InMemoryArtifactService()

def initialize_mcp_server(agent_filter: list[str] = None) -> FastMCP:
    """
    Initialize the MCP server with dynamic agent discovery.
    
    Args:
        agent_filter: Optional list of agent types/personas to include.
                     Example: ["planner", "analyzer", "developer"]
    """

    mcp = FastMCP(
        name="Engineering IQ Toolkit",
        instructions="""
        Help with analyzing code, iterating on features, and discovery planning tasks.
        This server provides access to a comprehensive suite of engineering agents
        organized by type (planners, analyzers, analysts, etc.) and domain expertise
        (developer, devsecops, QE, product).
        """,
    )

    # Initialize endpoints with optional filtering
    dev_server_endpoints = DevServerEndpoints(
        agent_filter=agent_filter,
        memory_service=memory_service,
        session_service=session_service,
        artifact_service=artifact_service,
        mcp=mcp,
    )

    # Add agent endpoints
    dev_server_endpoints.add_agent_endpoints(mcp)

    return mcp

server: FastMCP = None

def start_server(
    port: int = 8000, 
    host: str = "localhost", 
    log_level: str = "info",
):
    """
    Start the MCP server with configurable port and host using uvicorn
    
    Args:
        port: Port number to run the server on (default: 8000)
        host: Host address to bind to (default: localhost)
        log_level: Log level for uvicorn (default: info)
    """
    global server
    
    try:
        
        print(f"Starting Engineering IQ MCP Server on {host}:{port} with all agents")
        server = initialize_mcp_server()

        server.run(
            transport="sse",
            host=host,
            port=port,
            log_level=log_level,
        )
        
    except KeyboardInterrupt:
        print("\nServer stopped by user")
    except Exception as e:
        print(f"Server error: {e}")

def main(
    port: int = typer.Option(8000, "--port", "-p", help="Port to run the server on"),
    host: str = typer.Option("localhost", "--host", "-h", help="Host to bind the server to"),
    log_level: str = typer.Option(
        "info", 
        "--log-level", 
        "-l", 
        help="Log level for server",
        case_sensitive=False
    ),
    debug: bool = typer.Option(False, "--debug", "-d", help="Enable debug mode"),
    filter_types: str = typer.Option(
        None,
        "--filter-types",
        "-f",
        help="Comma-separated list of agent types/personas to include (e.g., 'planner,analyzer,developer')"
    ),
) -> None:
    """
    🚀 Engineering IQ MCP Server
    
    A powerful MCP server that provides streaming agent execution 
    for code analysis, feature iteration, and discovery planning.
    
    Agents are automatically discovered and can be filtered by type or persona.
    """
    # Validate log level
    valid_levels = ["critical", "error", "warning", "info", "debug", "trace"]
    if log_level.lower() not in valid_levels:
        typer.echo(f"❌ Invalid log level: {log_level}")
        typer.echo(f"Valid levels: {', '.join(valid_levels)}")
        raise typer.Exit(1)
    
    # Set debug log level if debug flag is used
    if debug:
        log_level = "debug"
        typer.echo("🐛 Debug mode enabled")    
    
    start_server(port=port, host=host, log_level=log_level.lower())


if __name__ == "__main__":
    app = typer.Typer(
        name="engineering-iq-mcp",
        help="🚀 Engineering IQ MCP Server - Streaming agent execution for code analysis",
        add_completion=False,
        rich_markup_mode="rich"
    )
    
    app.command()(main)
    app()
