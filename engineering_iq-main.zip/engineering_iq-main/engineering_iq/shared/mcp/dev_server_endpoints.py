from typing import Optional, Dict, List, Type
from pydantic import BaseModel, Field

from google.adk.memory import BaseMemoryService
from google.adk.sessions import BaseSessionService, Session
from google.adk.artifacts import BaseArtifactService

from fastmcp import FastMCP

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.agents import (
    REGISTRY, 
    all_agents, 
    get_agents_by_type, 
    get_agents_by_persona,
    get_agent_info
)

class DevServerEndpoints(BaseModel):
    """
    Endpoints for the development server to manage sessions and events.
    Uses dynamic agent discovery and meta-based categorization.
    """

    model_config = {
        "arbitrary_types_allowed": True,
    }

    memory_service: BaseMemoryService = None
    session_service: BaseSessionService = None
    artifact_service: BaseArtifactService = None

    _agents: List[EngineeringIQAgent] = []
    _agent_filter: Optional[List[str]] = None  # Optional filter for agent types to include

    def __init__(self, agent_filter: Optional[List[str]] = None, **kwargs):
        """
        Initialize endpoints with optional agent filtering.
        
        Args:
            agent_filter: Optional list of agent types/personas to include. 
                         If None, includes all agents. Example: ["planner", "analyzer", "developer"]
        """
        super().__init__(**kwargs)
        self._agent_filter = agent_filter or []

    def _should_include_agent(self, agent_name: str, agent_class: Type[EngineeringIQAgent]) -> bool:
        """
        Determine if an agent should be included based on filters.
        
        Args:
            agent_name: Name of the agent
            agent_class: Agent class
            
        Returns:
            True if agent should be included
        """
        if not self._agent_filter:
            return True
            
        # Get agent info to check meta
        try:
            temp_instance = agent_class()
            meta = temp_instance.get_meta()
            
            # Check if any filter criteria matches the agent's meta
            for filter_item in self._agent_filter:
                if filter_item in meta:
                    return True
                    
            return False
        except Exception:
            # If we can't instantiate, exclude by default
            return False

    def get_available_agents(self) -> Dict[str, Type[EngineeringIQAgent]]:
        """
        Get all available agents, filtered by criteria if specified.
        
        Returns:
            Dictionary of agent_name -> agent_class
        """
        available_agents = {}
        
        for agent_name, agent_class in all_agents.items():
            if self._should_include_agent(agent_name, agent_class):
                available_agents[agent_name] = agent_class
                
        return available_agents

    def add_agent_endpoints(self, mcp: FastMCP) -> None:
        """
        Dynamically add endpoints for all discovered agents.
        """
        available_agents = self.get_available_agents()
        
        for agent_name, agent_class in available_agents.items():
            try:
                iq_agent = agent_class(
                    memory_service=self.memory_service,
                    session_service=self.session_service,
                    artifact_service=self.artifact_service,
                )

                # Set up the tool metadata
                agent_settings = iq_agent.get_agent_settings()
                tool_name = agent_settings.name or agent_name
                tool_description = agent_settings.description or f"Agent: {agent_name}"

                # Update the method metadata
                agent_class.run_tool_in_background.__doc__ = tool_description
                agent_class.run_tool_in_background.__name__ = f"fn_{agent_name}"

                self._agents.append(iq_agent)

                mcp.tool(
                    name=tool_name,
                    name_or_fn=iq_agent.run_tool_in_background,
                    description=tool_description,
                    tags=[
                        agent_name,
                        *iq_agent.get_meta(),
                    ]
                )

                mcp.tool(
                    name=f"cancel_all_{agent_name}",
                    name_or_fn=iq_agent.cancel_all_run_as_tool,
                    description=f"Cancel all runs for agent {agent_name}",
                    tags=[
                        agent_name,
                        *iq_agent.get_meta(),
                    ]
                )

            except Exception as e:
                print(f"Warning: Could not add endpoint for agent '{agent_name}': {e}")
                continue

        tools = [
            self.list_agents,
            self.list_agents_by_category,
            self.list_agents_by_persona,
            self.get_agent_details,
            self.get_registry_info,
            self.list_sessions,
            self.get_session_events,
            self.get_available_agents,
        ]

        for tool in tools:
            mcp.tool(
                name=tool.__name__,
                name_or_fn=tool,
                description=tool.__doc__ or "No description provided",
            )


    async def list_agents(self) -> List[Dict]:
        """
        Get the list of active agents with their metadata.
        """
        results = []
        for agent in self._agents:
            agent_info = {
                "name": agent.get_agent_settings().name,
                "description": agent.get_agent_settings().description,
                "meta": agent.get_meta(),
            }
            
            # Add type and persona information
            meta = agent.get_meta()
            agent_info["type"] = next((m for m in meta if m in AC.AGENT_TYPES), "unknown")
            agent_info["persona"] = next((m for m in meta if m in AC.AGENT_PERSONAS), "unknown")
            
            results.append(agent_info)

        return results
    
    async def list_agents_by_category(self) -> Dict[str, List[Dict]]:
        """
        Get agents organized by category based on their meta information.
        """
        categories = {
            "planning": [],
            "analysis": [],
            "workflow": [],
            "utility": [],
        }
        
        for agent in self._agents:
            meta = agent.get_meta()
            agent_info = {
                "name": agent.get_agent_settings().name,
                "description": agent.get_agent_settings().description,
                "meta": meta,
            }
            
            # Categorize based on agent type
            if AC.AGENT_TYPE_PLANNER in meta:
                categories["planning"].append(agent_info)
            elif AC.AGENT_TYPE_ANALYZER in meta or AC.AGENT_TYPE_ANALYST in meta:
                categories["analysis"].append(agent_info)
            elif AC.AGENT_TYPE_LEAD in meta or AC.AGENT_TYPE_REVIEWER in meta:
                categories["workflow"].append(agent_info)
            else:
                categories["utility"].append(agent_info)
        
        return categories

    async def list_agents_by_persona(self) -> Dict[str, List[Dict]]:
        """
        Get agents organized by persona based on their meta information.
        """
        personas = {persona: [] for persona in AC.AGENT_PERSONAS}
        
        for agent in self._agents:
            meta = agent.get_meta()
            agent_info = {
                "name": agent.get_agent_settings().name,
                "description": agent.get_agent_settings().description,
                "meta": meta,
            }
            
            # Find persona
            agent_persona = next((m for m in meta if m in AC.AGENT_PERSONAS), AC.AGENT_PERSONA_UNCATEGORIZED)
            personas[agent_persona].append(agent_info)
        
        return personas

    async def get_agent_details(self, agent_name: str) -> Optional[Dict]:
        """
        Get detailed information about a specific agent.
        
        Args:
            agent_name: Name of the agent to get details for
            
        Returns:
            Agent details or None if not found
        """
        return get_agent_info(agent_name)

    async def get_registry_info(self) -> Dict:
        """
        Get information about the agent registry.
        """
        return {
            "total_agents": len(REGISTRY.agent_names),
            "agent_names": sorted(REGISTRY.agent_names),
            "categories": {
                "planning": len(get_agents_by_type(AC.AGENT_TYPE_PLANNER)),
                "analyzers": len(get_agents_by_type(AC.AGENT_TYPE_ANALYZER)),
                "analysts": len(get_agents_by_type(AC.AGENT_TYPE_ANALYST)),
                "reviewers": len(get_agents_by_type(AC.AGENT_TYPE_REVIEWER)),
                "leads": len(get_agents_by_type(AC.AGENT_TYPE_LEAD)),
                "utility": len(get_agents_by_type(AC.AGENT_TYPE_UTILITY)),
            },
            "personas": {
                persona: len(get_agents_by_persona(persona))
                for persona in AC.AGENT_PERSONAS
            }
        }

    async def list_sessions(
            self,
            app_name: str = Field(description="Name of the application to filter sessions by"),
            user_id: str = Field(description="ID of the user to filter sessions by"),
        ) -> List[Session]:
        """
        Get the list of active agent sessions
        """
        sessions = await self.session_service.list_sessions(
            app_name=app_name,
            user_id=user_id,
        )
        return sessions.sessions

    async def get_session_events(
            self,
            app_name: str = Field(description="Name of the application to filter sessions by"),
            user_id: str = Field(description="ID of the user to filter sessions by"),
            session_id: str = Field(description="ID of the session to retrieve events for"),
        ) -> List[Dict]:
        """
        Get the events for a specific session
        """
        session = await self.session_service.get_session(
            session_id=session_id,
            app_name=app_name,
            user_id=user_id,
        )
        if not session or not session.events:
            return [
                {
                    "final_response": True,
                    "event_id": None,
                    "event_author": "system",
                    "event_type": "error",
                    "event_content": "No events found for the specified session.",
                    "session_id": session_id,
                    "app_name": app_name,
                    "user_id": user_id
                }
            ]
        result = []
        for event in session.events:
            if event.content.parts:
                event_content = [part.text for part in event.content.parts]
                result.append({
                    "final_response": False,
                    "event_id": event.id,
                    "event_author": event.author,
                    "event_type": "message",
                    "event_content": event_content,
                    "event_timestamp": event.timestamp,
                })
            
        return result