from __future__ import annotations

from typing_extensions import override

from google.genai import types
from google.adk.tools import ToolContext, FunctionTool
from google.adk.models.llm_request import LlmRequest

from engineering_iq.shared.memory.smart_inmemory_service import SearchMemoryResponse

async def search_memory(
    query: str, 
    tool_context: ToolContext
) -> SearchMemoryResponse:
  """
  Searches the memory for the current user.

  Args:
    query: A regex to find memories

  Returns:
    A list of memory results.
  """
  search_memory_response = await tool_context.search_memory(query)
  return search_memory_response


class SearchMemoryTool(FunctionTool):
  """
  Allows you to search memory for the current user.
  NOTE: Currently this tool only uses text part from the memory.
  """

  def __init__(self):
    super().__init__(search_memory)

  @override
  def _get_declaration(self) -> types.FunctionDeclaration | None:
    return types.FunctionDeclaration(
        name=self.name,
        description=self.description,
        parameters=types.Schema(
            type=types.Type.OBJECT,
            properties={
                'query': types.Schema(
                    type=types.Type.STRING,
                    description="A regex to find meaningful memories",
                )
            },
        ),
    )

  @override
  async def process_llm_request(
      self,
      *,
      tool_context: ToolContext,
      llm_request: LlmRequest,
  ) -> None:
    await super().process_llm_request(
        tool_context=tool_context, llm_request=llm_request
    )
    # Tell the model about the memory.
    llm_request.append_instructions(["""
**CRITICAL**:
- You have access to memories and events to help with your current response.
- Using the `search_memory` tool, you can find these to help you answer questions not in your current context.
- Utilize **regex expressions** to search for what you need.
"""])


search_memory_tool = SearchMemoryTool()
