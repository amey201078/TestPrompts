# A dictionary of tree-sitter queries to find function, class, and other symbol definitions for various languages.
# The [ ... ] @definition pattern is used to capture the entire node for any of the patterns inside the brackets.
# This makes the queries more robust, especially for languages with optional modifiers like annotations.
DEFINITION_QUERIES = {
    "bash": """
    (function_definition name: (word) @name) @definition
    """,
    "c": """
    [
      (function_definition declarator: (function_declarator declarator: (identifier) @name))
      (struct_specifier name: (type_identifier) @name)
      (union_specifier name: (type_identifier) @name)
      (enum_specifier name: (type_identifier) @name)
      (type_definition declarator: (type_identifier) @name)
    ] @definition
    """,
    "cpp": """
    [
      (function_definition declarator: (function_declarator declarator: . (identifier) @name))
      (class_specifier name: (type_identifier) @name)
      (struct_specifier name: (type_identifier) @name)
      (enum_specifier name: (type_identifier) @name)
      (namespace_definition name: (identifier) @name)
    ] @definition
    """,
    "csharp": """
    [
      (class_declaration name: (identifier) @name)
      (interface_declaration name: (identifier) @name)
      (struct_declaration name: (identifier) @name)
      (enum_declaration name: (identifier) @name)
      (method_declaration name: (identifier) @name)
      (namespace_declaration name: . (identifier) @name)
    ] @definition
    """,
    "dart": """
    [
      (class_definition name: (identifier) @name)
      (function_declaration name: (identifier) @name)
      (method_declaration name: (identifier) @name)
    ] @definition
    """,
    "elixir": """
    (def name: (unquoted_atom) @name) @definition
    (defp name: (unquoted_atom) @name) @definition
    (defmodule name: (alias) @name) @definition
    """,
    "go": """
    [
      (function_declaration name: (identifier) @name)
      (method_declaration name: (field_identifier) @name)
      (type_spec name: (type_identifier) @name)
    ] @definition
    """,
    "haskell": """
    [
      (function name: (variable) @name)
      (data_declaration name: (type_constructor) @name)
      (newtype_declaration name: (type_constructor) @name)
    ] @definition
    """,
    "java": """
    [
      (class_declaration name: (identifier) @name)
      (interface_declaration name: (identifier) @name)
      (method_declaration name: (identifier) @name)
      (enum_declaration name: (identifier) @name)
    ] @definition
    """,
    "javascript": """
    [
      (function_declaration name: (identifier) @name)
      (class_declaration name: (identifier) @name)
      (variable_declarator name: (identifier) @name value: [(arrow_function) (function)])
    ] @definition
    """,
    "julia": """
    [
      (function_definition name: (identifier) @name)
      (struct_definition name: (identifier) @name)
      (module_definition name: (identifier) @name)
    ] @definition
    """,
    "kotlin": """
    [
      (class_declaration name: (simple_identifier) @name)
      (function_declaration name: (simple_identifier) @name)
      (object_declaration name: (simple_identifier) @name)
    ] @definition
    """,
    "lua": """
    (function_declaration name: (identifier) @name) @definition
    """,
    "objc": """
    [
      (class_interface name: (identifier) @name)
      (class_implementation name: (identifier) @name)
      (method_declaration)
    ] @definition
    """,
    "ocaml": """
    [
      (let_binding (pattern (value_identifier) @name))
      (type_declaration name: (type_constructor) @name)
    ] @definition
    """,
    "perl": """
    (sub_definition name: (identifier) @name) @definition
    """,
    "php": """
    [
      (class_declaration name: (name) @name)
      (function_definition name: (name) @name)
      (trait_declaration name: (name) @name)
      (interface_declaration name: (name) @name)
    ] @definition
    """,
    "python": """
    [
      (function_definition name: (identifier) @name)
      (class_definition name: (identifier) @name)
    ] @definition
    """,
    "r": """
    (assignment left: (identifier) @name right: (function_definition)) @definition
    """,
    "ruby": """
    [
      (class name: (constant) @name)
      (module name: (constant) @name)
      (method name: (identifier) @name)
      (singleton_method name: (identifier) @name)
    ] @definition
    """,
    "rust": """
    [
      (function_item name: (identifier) @name)
      (struct_item name: (type_identifier) @name)
      (enum_item name: (type_identifier) @name)
      (trait_item name: (type_identifier) @name)
      (impl_item trait: (type_identifier) @name)
      (mod_item name: (identifier) @name)
    ] @definition
    """,
    "scala": """
    [
      (class_definition name: (identifier) @name)
      (object_definition name: (identifier) @name)
      (trait_definition name: (identifier) @name)
      (function_definition name: (identifier) @name)
    ] @definition
    """,
    "solidity": """
    [
      (contract_definition name: (identifier) @name)
      (function_definition name: (identifier) @name)
      (struct_definition name: (identifier) @name)
    ] @definition
    """,
    "sql": """
    [
      (create_table_statement name: (table_name) @name)
      (create_view_statement name: (view_name) @name)
      (create_function_statement name: (function_name) @name)
    ] @definition
    """,
    "swift": """
    [
      (class_declaration name: (identifier) @name)
      (struct_declaration name: (identifier) @name)
      (enum_declaration name: (identifier) @name)
      (protocol_declaration name: (identifier) @name)
      (function_declaration name: (identifier) @name)
    ] @definition
    """,
    "typescript": """
    [
      (function_declaration name: (identifier) @name)
      (class_declaration name: (type_identifier) @name)
      (interface_declaration name: (type_identifier) @name)
      (type_alias_declaration name: (type_identifier) @name)
      (enum_declaration name: (identifier) @name)
    ] @definition
    """,
    "zig": """
    (fn_proto name: (identifier) @name) @definition
    """,
}

def get_definition_query(language: str) -> str:
    """
    Returns the definition query for the specified language.
    
    Args:
        language (str): The programming language for which to get the definition query.
        
    Returns:
        str: The tree-sitter query string for function and class definitions in the specified language.
    """
    return DEFINITION_QUERIES.get(language, "")
