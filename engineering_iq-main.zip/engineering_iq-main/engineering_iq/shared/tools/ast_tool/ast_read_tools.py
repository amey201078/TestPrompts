"""Tool wrappers for AST reading functions."""

from google.genai import types
from google.adk.tools import FunctionTool, ToolContext
from google.adk.models import LlmRequest

from typing_extensions import override
from engineering_iq.shared.core.models.app_settings import app_settings

from engineering_iq.shared.tools.ast_tool.ast_read_functions import (
    ast_search_regex, 
    ast_find_symbol, 
    ast_list_definitions, 
    ast_find_function_calls
)


class ASTRegexSearchTool(FunctionTool):
    """AST-powered regex search across codebase"""
    
    def __init__(self):
        super().__init__(ast_search_regex)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file or directory to search"
                    ),
                    'pattern': types.Schema(
                        type=types.Type.STRING,
                        description="The regex pattern to search for"
                    )
                },
                required=["path", "pattern"]
            ),
        )
    
    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: AST Regex Search
- You have an AST-powered regex search tool that searches across codebases using tree-sitter parsing.
- This tool parses supported programming languages and provides accurate pattern matching.
- Use this for finding specific code patterns, implementations, or text across multiple files.
- Supports many languages including Python, JavaScript, Java, Go, Rust, C++, and more.
"""])



class ASTSymbolFinderTool(FunctionTool):
    """AST-powered symbol definition and reference finder"""
    
    def __init__(self):
        super().__init__(ast_find_symbol)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file or directory to analyze"
                    ),
                    'symbol_name': types.Schema(
                        type=types.Type.STRING,
                        description="The name of the class or function to find"
                    )
                },
                required=["path", "symbol_name"]
            ),
        )
    
    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: AST Symbol Finder
- You have an AST-powered symbol finder that locates definitions and references of symbols in codebases.
- This tool uses tree-sitter parsing to accurately find where functions, classes, and variables are defined and used.
- Returns both definitions (where symbols are declared) and references (where they are used).
- Supports cross-file analysis and multiple programming languages.
"""])


class ASTListDefinitionsTool(FunctionTool):
    """AST-powered tool to list all definitions in codebase"""
    
    def __init__(self):
        super().__init__(ast_list_definitions)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file or directory to analyze"
                    ),
                    'symbol_type': types.Schema(
                        type=types.Type.STRING,
                        description="Optional filter by symbol type (function, class, etc.)"
                    )
                },
                required=["path"]
            ),
        )
    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: AST List Definitions
- You have an AST-powered tool that lists all definitions (functions, classes, etc.) in a codebase.
- This provides a comprehensive overview of the code structure and available symbols.
- Can be filtered by symbol type to focus on specific kinds of definitions.
- Useful for understanding codebase architecture and available APIs.
"""])

class ASTFunctionCallsTool(FunctionTool):
    """AST-powered tool to find function call sites"""
    
    def __init__(self):
        super().__init__(ast_find_function_calls)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file or directory to analyze"
                    ),
                    'function_name': types.Schema(
                        type=types.Type.STRING,
                        description="The name of the function to find calls for"
                    )
                },
                required=["path", "function_name"]
            ),
        )
    
    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: AST Function Calls Finder
- You have an AST-powered tool that finds all call sites for a specific function.
- This tool uses tree-sitter parsing to accurately identify where functions are called throughout the codebase.
- Shows the exact line content and location of each function call.
- Useful for understanding function usage patterns and finding all places where a function is invoked.
"""])



# Create tool instances
ast_regex_search_tool = ASTRegexSearchTool()
ast_symbol_finder_tool = ASTSymbolFinderTool()
ast_list_definitions_tool = ASTListDefinitionsTool()
ast_function_calls_tool = ASTFunctionCallsTool()

# Collection of AST read tools
if not app_settings.enable_lsp_tools:
    all_ast_tools = [
        ast_regex_search_tool,
        ast_symbol_finder_tool,
        ast_list_definitions_tool,
        ast_function_calls_tool
    ]
else:
    all_ast_tools = []
