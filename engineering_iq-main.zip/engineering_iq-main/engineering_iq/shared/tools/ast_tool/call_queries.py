# A dictionary of tree-sitter queries to find function/method calls for various languages.
CALL_QUERIES = {
    "bash": """
    (command name: (command_name (word) @call-name)) @call
    """,
    "c": """
    (call_expression function: (identifier) @call-name) @call
    """,
    "cpp": """
    (call_expression function: [
      (identifier) @call-name
      (field_expression field: (field_identifier) @call-name)
    ]) @call
    """,
    "csharp": """
    (invocation_expression expression: [
      (identifier_name) @call-name
      (member_access_expression name: (identifier_name) @call-name)
    ]) @call
    """,
    "dart": """
    (method_invocation method_name: (identifier) @call-name) @call
    """,
    "go": """
    (call_expression function: [
        (identifier) @call-name
        (selector_expression field: (field_identifier) @call-name)
    ]) @call
    """,
    "haskell": """
    (expression (variable) @call-name) @call
    """,
    "java": """
    (method_invocation name: (identifier) @call-name) @call
    (method_invocation object: (identifier) name: (identifier) @call-name) @call
    """,
    "javascript": """
    (call_expression function: [
        (identifier) @call-name
        (member_expression property: (property_identifier) @call-name)
    ]) @call
    """,
    "julia": """
    (call_expression (identifier) @call-name) @call
    """,
    "kotlin": """
    (call_expression (simple_identifier) @call-name) @call
    """,
    "lua": """
    (function_call name: (identifier) @call-name) @call
    """,
    "objc": """
    (message_expression selector: (selector) @call-name) @call
    """,
    "ocaml": """
    (application_expression (value_path (value_identifier) @call-name)) @call
    """,
    "php": """
    (function_call_expression name: (name) @call-name) @call
    (member_call_expression name: (name) @call-name) @call
    """,
    "python": """
    (call function: [
        (identifier) @call-name
        (attribute attribute: (identifier) @call-name)
    ]) @call
    """,
    "ruby": """
    (call method: (identifier) @call-name) @call
    (call receiver: [
        (identifier)
        (constant)
    ] method: (identifier) @call-name) @call
    """,
    "rust": """
    (call_expression function: [
        (identifier) @call-name
        (field_expression field: (field_identifier) @call-name)
    ]) @call
    """,
    "scala": """
    (call_expression function: (identifier) @call-name) @call
    """,
    "solidity": """
    (call_expression (identifier) @call-name) @call
    """,
    "swift": """
    (call_expression (simple_identifier) @call-name) @call
    """,
    "typescript": """
    (call_expression function: [
        (identifier) @call-name
        (member_expression property: (property_identifier) @call-name)
    ]) @call
    """,
    "zig": """
    (call_expression callee: (identifier) @call-name) @call
    """,
}

def get_call_query(language: str) -> str:
    """
    Returns the call query for the specified language.
    
    Args:
        language (str): The programming language for which to get the call query.
        
    Returns:
        str: The tree-sitter query string for function/method calls in the specified language.
    """
    return CALL_QUERIES.get(language, "")
