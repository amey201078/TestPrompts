from typing import Dict, List, Any
import re
import os
import json
import typer
from tree_sitter_language_pack import get_language, get_parser
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

# Assuming these files exist in the specified path
from engineering_iq.shared.tools.ast_tool.parsers import filename_to_lang
from engineering_iq.shared.tools.ast_tool.definition_queries import get_definition_query
from engineering_iq.shared.tools.ast_tool.call_queries import get_call_query

app = typer.Typer()
console = Console()

# --- CORE FUNCTIONS FOR TOOL WRAPPING ---

def ast_search_regex(path: str, pattern: str) -> List[Dict[str, Any]]:
    """
    Perform a regex search across the codebase using AST analysis.
    
    Args:
        path: Path to the file or directory to search
        pattern: The regex pattern to search for
        
    Returns:
        List of dictionaries containing file_path, line_number, and line content
    """
    searcher = CodebaseSearcher(path)
    return searcher.search_regex(pattern)

def ast_find_symbol(path: str, symbol_name: str) -> Dict[str, List[Dict[str, Any]]]:
    """
    Find definitions and references for a given symbol in the codebase.
    
    Args:
        path: Path to the file or directory to analyze
        symbol_name: The name of the class or function to find
        
    Returns:
        Dictionary with 'definitions' and 'references' keys containing lists of matches
    """
    searcher = CodebaseSearcher(path)
    return searcher.find_symbol(symbol_name)

def ast_list_definitions(path: str, symbol_type: str = None) -> List[Dict[str, Any]]:
    """
    List all definitions found in the codebase.
    
    Args:
        path: Path to the file or directory to analyze
        symbol_type: Optional filter by type ('function', 'class', 'interface', etc.)
        
    Returns:
        List of dictionaries containing definition information
    """
    searcher = CodebaseSearcher(path)
    return searcher.list_definitions(symbol_type)

def ast_find_function_calls(path: str, function_name: str) -> List[Dict[str, Any]]:
    """
    Find all call sites for a function with a given name.
    
    Args:
        path: Path to the file or directory to analyze
        function_name: The name of the function to find calls for
        
    Returns:
        List of dictionaries containing call site information
    """
    searcher = CodebaseSearcher(path)
    return searcher.find_function_calls(function_name)

# --- CORE LOGIC ---

class CodebaseSearcher:
    """
    A class to search for patterns and analyze symbol connections in a codebase (file or directory).
    """

    def __init__(self, path):
        """
        Initializes the CodebaseSearcher.

        Args:
            path (str): The path to a file or directory to be analyzed.
        """
        self.root_path = path
        self.files = {}  # {path: {'code': str, 'lines': [], 'tree': obj, 'lang': str}}
        self.definitions = {}  # {symbol_name: [{'file_path': str, 'line_number': int, 'node_type': str}]}
        self.references = {} # {symbol_name: [{'file_path': str, 'line_number': int, 'node_type': str}]}

        self._discover_and_parse_files()
        self._analyze_codebase()

    def _discover_and_parse_files(self):
        """Discovers, reads, and parses all supported files in the path."""
        if os.path.isfile(self.root_path):
            self._process_file(self.root_path)
        elif os.path.isdir(self.root_path):
            for dirpath, _, filenames in os.walk(self.root_path):
                for filename in filenames:
                    file_path = os.path.join(dirpath, filename)
                    self._process_file(file_path)

    def _process_file(self, file_path):
        """Reads, determines language, and parses a single file."""
        lang = filename_to_lang(file_path)
        if not lang:
            return  # Skip unsupported file types

        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                code = f.read()
            
            parser = get_parser(lang)
            tree = parser.parse(bytes(code, "utf8"))
            
            self.files[file_path] = {
                "code": code,
                "lines": code.splitlines(),
                "tree": tree,
                "lang": lang,
            }
        except Exception as e:
            console.print(f"[bold red]Failed to process file {file_path}: {e}[/bold red]")


    def _analyze_codebase(self):
        """Analyzes all parsed files to find definitions and references."""
        for file_path, data in self.files.items():
            self._find_definitions_in_tree(file_path, data['tree'], data['lang'])
            self._find_references_in_tree(file_path, data['tree'])

    def _find_definitions_in_tree(self, file_path, tree, lang):
        """Finds function and class definitions in a file's AST."""
        query_str = get_definition_query(lang)
        if not query_str:
            return
            
        try:
            language = get_language(lang)
            query = language.query(query_str)
            captures = query.captures(tree.root_node)
            
            # Handle the case where captures is a dictionary with capture names as keys
            if isinstance(captures, dict):
                definition_nodes = captures.get('definition', [])
                name_nodes = captures.get('name', [])
                
                # Create a mapping of definition nodes by their span for better matching
                definition_map = {}
                for def_node in definition_nodes:
                    definition_map[def_node.id] = def_node
                
                # Process each name node
                for name_node in name_nodes:
                    symbol_name = name_node.text.decode('utf8')
                    if symbol_name not in self.definitions:
                        self.definitions[symbol_name] = []
                    
                    # Find the corresponding definition node by looking for a parent match
                    parent_definition_node = None
                    current_node = name_node
                    while current_node.parent:
                        if current_node.parent.id in definition_map:
                            parent_definition_node = definition_map[current_node.parent.id]
                            break
                        current_node = current_node.parent
                    
                    # If no specific definition parent found, use the closest parent
                    if not parent_definition_node:
                        parent_definition_node = name_node.parent
                        # Try to find a definition node that contains this name node
                        for def_node in definition_nodes:
                            if (def_node.start_point <= name_node.start_point and 
                                def_node.end_point >= name_node.end_point):
                                parent_definition_node = def_node
                                break

                    self.definitions[symbol_name].append({
                        'file_path': file_path,
                        'line_number': name_node.start_point[0] + 1,
                        'node_type': parent_definition_node.type if parent_definition_node else 'unknown',
                        'symbol_node_type': name_node.type,
                    })
            else:
                # Handle the case where captures is a list of tuples (fallback)
                definition_nodes = {cap[0].id: cap[0] for cap in captures if len(cap) == 2 and cap[1] == 'definition'}

                for capture_tuple in captures:
                    if len(capture_tuple) != 2:
                        continue
                    node, capture_name = capture_tuple
                    
                    if capture_name == "name":
                        symbol_name = node.text.decode('utf8')
                        if symbol_name not in self.definitions:
                            self.definitions[symbol_name] = []
                        
                        parent_definition_node = None
                        current_node = node
                        while current_node.parent:
                            if current_node.parent.id in definition_nodes:
                                parent_definition_node = definition_nodes[current_node.parent.id]
                                break
                            current_node = current_node.parent
                        
                        if not parent_definition_node:
                            parent_definition_node = node.parent

                        self.definitions[symbol_name].append({
                            'file_path': file_path,
                            'line_number': node.start_point[0] + 1,
                            'node_type': parent_definition_node.type,
                            'symbol_node_type': node.type,
                        })
                        
        except Exception as e:
            console.print(f"[bold red]Error processing definitions in {file_path} for language {lang}: {e}[/bold red]")
            import traceback
            console.print(f"[bold red]Traceback: {traceback.format_exc()}[/bold red]")


    def _find_references_in_tree(self, file_path, tree):
        """Finds all identifiers (potential references) in a file's AST."""
        def walk_tree(node):
            if 'identifier' in node.type:
                symbol_name = node.text.decode('utf8')
                if symbol_name not in self.references:
                    self.references[symbol_name] = []
                self.references[symbol_name].append({
                    'file_path': file_path,
                    'line_number': node.start_point[0] + 1,
                    'node_type': node.type,
                })
            
            for child in node.children:
                walk_tree(child)
        
        walk_tree(tree.root_node)

    def list_definitions(self, symbol_type=None):
        """
        Lists all definitions found in the codebase.
        Can be filtered by type (e.g., 'function', 'class', 'interface').
        """
        results = []
        for name, defs in self.definitions.items():
            for defi in defs:
                node_type = defi.get('node_type', 'unknown')
                
                # Use substring matching for more flexible filtering
                if symbol_type and symbol_type.lower() not in node_type:
                    continue

                # Categorize for display purposes
                semantic_type = 'unknown'
                if 'function' in node_type or 'method' in node_type:
                    semantic_type = 'function'
                elif 'class' in node_type:
                    semantic_type = 'class'
                elif 'interface' in node_type:
                    semantic_type = 'interface'
                elif 'struct' in node_type:
                    semantic_type = 'struct'
                elif 'enum' in node_type:
                    semantic_type = 'enum'

                results.append({
                    'name': name,
                    'semantic_type': semantic_type,
                    'node_type': node_type,
                    'file_path': defi['file_path'],
                    'line_number': defi['line_number']
                })
        return sorted(results, key=lambda x: (x['file_path'], x['line_number']))
    
    def find_function_calls(self, function_name):
        """Finds all call sites for a function with a given name."""
        results = []
        for file_path, data in self.files.items():
            query_str = get_call_query(data['lang'])
            if not query_str:
                continue

            try:
                language = get_language(data['lang'])
                query = language.query(query_str)
                captures = query.captures(data['tree'].root_node)
                
                for node, capture_name in captures:
                    if capture_name == "call-name" and node.text.decode('utf8') == function_name:
                        line_num = node.start_point[0]
                        results.append({
                            'file_path': file_path,
                            'line_number': line_num + 1,
                            'line': data['lines'][line_num].strip(),
                            'node_type': node.parent.type,
                        })
            except Exception:
                continue
        return results

    def search_regex(self, pattern):
        """
        Performs a simple regex search across all files.
        """
        results = []
        for file_path, data in self.files.items():
            for i, line in enumerate(data['lines']):
                if re.search(pattern, line):
                    results.append({
                        'file_path': file_path,
                        'line_number': i + 1,
                        'line': line,
                    })
        return results

    def find_symbol(self, symbol_name):
        """
        Finds definitions and references for a given symbol.
        """
        return {
            "definitions": self.definitions.get(symbol_name, []),
            "references": self.references.get(symbol_name, [])
        }


# --- CLI COMMANDS ---

def _format_search_results(results: List[Dict[str, Any]], pattern: str):
    """Format regex search results with rich formatting."""
    if not results:
        console.print(f"[yellow]No matches found for pattern: {pattern}[/yellow]")
        return
    
    console.print(f"\n[green]Found {len(results)} matches for pattern: [bold]{pattern}[/bold][/green]\n")
    
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("File", style="cyan")
    table.add_column("Line", style="magenta", justify="right")
    table.add_column("Content", style="white")
    
    for result in results:
        table.add_row(
            result['file_path'],
            str(result['line_number']),
            result['line'].strip()
        )
    
    console.print(table)


def _format_symbol_results(results: Dict[str, List[Dict[str, Any]]], symbol_name: str):
    """Format symbol search results with rich formatting."""
    definitions = results.get('definitions', [])
    references = results.get('references', [])
    
    if not definitions and not references:
        console.print(f"[yellow]No definitions or references found for symbol: [bold]{symbol_name}[/bold][/yellow]")
        return
    
    console.print(f"\n[green]Symbol Analysis for: [bold]{symbol_name}[/bold][/green]\n")
    
    if definitions:
        console.print(Panel.fit(f"[bold green]Definitions ({len(definitions)})[/bold green]", style="green"))
        def_table = Table(show_header=True, header_style="bold green")
        def_table.add_column("File", style="cyan", no_wrap=True)
        def_table.add_column("Line", style="magenta", justify="right")
        def_table.add_column("Node Type", style="yellow")
        
        for definition in definitions:
            def_table.add_row(
                definition['file_path'], 
                str(definition['line_number']),
                definition['node_type']
            )
        console.print(def_table)
        console.print()
    
    if references:
        console.print(Panel.fit(f"[bold blue]References ({len(references)})[/bold blue]", style="blue"))
        ref_table = Table(show_header=True, header_style="bold blue")
        ref_table.add_column("File", style="cyan", no_wrap=True)
        ref_table.add_column("Line", style="magenta", justify="right")
        ref_table.add_column("Node Type", style="yellow")
        
        for ref in references:
            ref_table.add_row(
                ref['file_path'], 
                str(ref['line_number']),
                ref['node_type']
            )
        console.print(ref_table)


def _format_definitions_results(results: List[Dict[str, Any]], symbol_type: str = None):
    """Format definitions list results with rich formatting."""
    if not results:
        type_filter = f" of type '{symbol_type}'" if symbol_type else ""
        console.print(f"[yellow]No definitions found{type_filter}[/yellow]")
        return
    
    type_filter = f" ({symbol_type})" if symbol_type else ""
    console.print(f"\n[green]Found {len(results)} definitions{type_filter}[/green]\n")
    
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Name", style="yellow")
    table.add_column("Semantic Type", style="cyan", justify="center")
    table.add_column("Node Type", style="blue")
    table.add_column("File", style="blue")
    table.add_column("Line", style="magenta", justify="right")
    
    for result in results:
        table.add_row(
            result['name'],
            result.get('semantic_type', 'unknown'),
            result['node_type'],
            result['file_path'],
            str(result['line_number'])
        )
    
    console.print(table)


def _format_function_calls_results(results: List[Dict[str, Any]], function_name: str):
    """Format function calls results with rich formatting."""
    if not results:
        console.print(f"[yellow]No calls found for function: [bold]{function_name}[/bold][/yellow]")
        return
    
    console.print(f"\n[green]Found {len(results)} calls to function: [bold]{function_name}[/bold][/green]\n")
    
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("File", style="cyan")
    table.add_column("Line", style="magenta", justify="right")
    table.add_column("Node Type", style="yellow")
    table.add_column("Content", style="white")
    
    for result in results:
        table.add_row(
            result['file_path'],
            str(result['line_number']),
            result['node_type'],
            result['line']
        )
    
    console.print(table)


@app.command()
def search_regex(
    path: str = typer.Argument(..., help="Path to the file or directory to search"),
    pattern: str = typer.Argument(..., help="The regex pattern to search for"),
    raw: bool = typer.Option(False, "--raw", help="Output raw JSON instead of formatted results")
):
    """Search for a regex pattern across the codebase."""
    results = ast_search_regex(path, pattern)
    
    if raw:
        print(json.dumps(results, indent=2))
    else:
        _format_search_results(results, pattern)


@app.command("find-symbol")
def find_symbol_cli(
    path: str = typer.Argument(..., help="Path to the file or directory to analyze"),
    symbol_name: str = typer.Argument(..., help="The name of the class or function to find"),
    raw: bool = typer.Option(False, "--raw", help="Output raw JSON instead of formatted results")
):
    """Find definitions and references for a symbol."""
    results = ast_find_symbol(path, symbol_name)
    
    if raw:
        print(json.dumps(results, indent=2))
    else:
        _format_symbol_results(results, symbol_name)


@app.command("list-definitions")
def list_definitions_cli(
    path: str = typer.Argument(..., help="Path to the file or directory to analyze"),
    symbol_type: str = typer.Argument(None, help="Filter by symbol type (function, class, interface, etc.)"),
    raw: bool = typer.Option(False, "--raw", help="Output raw JSON instead of formatted results")
):
    """List all definitions found in the codebase."""
    results = ast_list_definitions(path, symbol_type)
    
    if raw:
        print(json.dumps(results, indent=2))
    else:
        _format_definitions_results(results, symbol_type)


@app.command("find-function-calls")
def find_function_calls_cli(
    path: str = typer.Argument(..., help="Path to the file or directory to analyze"),
    function_name: str = typer.Argument(..., help="The name of the function to find calls for"),
    raw: bool = typer.Option(False, "--raw", help="Output raw JSON instead of formatted results")
):
    """Find all call sites for a function with a given name."""
    results = ast_find_function_calls(path, function_name)
    
    if raw:
        print(json.dumps(results, indent=2))
    else:
        _format_function_calls_results(results, function_name)


if __name__ == "__main__":
    app()
