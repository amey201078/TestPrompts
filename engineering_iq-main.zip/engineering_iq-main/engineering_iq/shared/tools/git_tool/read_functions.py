"""Git reading and analysis functions."""

import os
import git
import git.types
from typing import Dict, Union, Optional, Any, List

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings

settings = app_settings
logger = get_logger(__name__)
repo_base_dir: str = settings.git_dir

def get_diff(repo_url: str, commit1: str, commit2: str) -> Union[str, Dict[str, Any]]:
    """
    Get the diff between two commits.
    
    Args:
        repo_url: The URL of the Git repository
        commit1: The first commit hash
        commit2: The second commit hash
    
    Returns:
        Dictionary with diff information or error message
    """
    logger.debug(f"Getting diff between {commit1} and {commit2} for repo: {repo_url}")
    
    try:
        # Extract module name from URL
        module_name = repo_url.split("/")[-1].split(".")[0]
        local_path = os.path.join(repo_base_dir, module_name)
        
        # Clone or use existing repo
        if os.path.exists(local_path):
            repo = git.Repo(local_path)
        else:
            repo = git.Repo.clone_from(repo_url, local_path)
        
        # Get the diff
        diff_output = repo.git.diff(commit1, commit2)
        
        result = {
            'repo_url': repo_url,
            'commit1': commit1,
            'commit2': commit2,
            'diff': diff_output,
            'local_path': local_path
        }
        
        logger.debug(f"Successfully retrieved diff for {repo_url}")
        return result
        
    except git.GitCommandError as e:
        logger.error(f"Git command error: {str(e)}")
        return f"Git command error: {str(e)}"
    except Exception as e:
        logger.error(f"Error getting diff: {str(e)}")
        return f"Error getting diff: {str(e)}"

def get_commit_info(repo_path: str, commit_hash: str) -> Union[str, Dict[str, Any]]:
    """
    Get detailed information about a specific commit.
    
    Args:
        repo_path: Path to the local Git repository
        commit_hash: The commit hash to analyze
    
    Returns:
        Dictionary with commit information or error message
    """
    logger.debug(f"Getting commit info for {commit_hash} in {repo_path}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        commit = repo.commit(commit_hash)
        
        result = {
            'commit_hash': commit.hexsha,
            'short_hash': commit.hexsha[:7],
            'author': {
                'name': commit.author.name,
                'email': commit.author.email
            },
            'committer': {
                'name': commit.committer.name,
                'email': commit.committer.email
            },
            'message': commit.message.strip(),
            'date': commit.committed_datetime.isoformat(),
            'parents': [parent.hexsha for parent in commit.parents],
            'stats': {
                'files_changed': len(commit.stats.files),
                'insertions': commit.stats.total['insertions'],
                'deletions': commit.stats.total['deletions']
            }
        }
        
        logger.debug(f"Successfully retrieved commit info for {commit_hash}")
        return result
        
    except git.BadName:
        logger.error(f"Invalid commit hash: {commit_hash}")
        return f"Invalid commit hash: {commit_hash}"
    except Exception as e:
        logger.error(f"Error getting commit info: {str(e)}")
        return f"Error getting commit info: {str(e)}"

def get_repo_status(repo_path: str) -> Union[str, Dict[str, Any]]:
    """
    Get the current status of a Git repository.
    
    Args:
        repo_path: Path to the local Git repository
    
    Returns:
        Dictionary with repository status or error message
    """
    logger.debug(f"Getting repo status for {repo_path}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        
        # Get current branch
        try:
            current_branch = repo.active_branch.name
        except TypeError:
            current_branch = "HEAD (detached)"
        
        # Get status information
        result = {
            'repo_path': repo_path,
            'current_branch': current_branch,
            'is_dirty': repo.is_dirty(),
            'untracked_files': repo.untracked_files,
            'modified_files': [item.a_path for item in repo.index.diff(None)],
            'staged_files': [item.a_path for item in repo.index.diff("HEAD")],
            'total_commits': len(list(repo.iter_commits())),
            'remotes': [remote.name for remote in repo.remotes],
            'branches': [branch.name for branch in repo.branches]
        }
        
        logger.debug(f"Successfully retrieved repo status for {repo_path}")
        return result
        
    except git.InvalidGitRepositoryError:
        logger.error(f"Invalid Git repository: {repo_path}")
        return f"Invalid Git repository: {repo_path}"
    except Exception as e:
        logger.error(f"Error getting repo status: {str(e)}")
        return f"Error getting repo status: {str(e)}"

def get_commit_history(repo_path: str, max_count: int = 20, branch: str = "HEAD") -> Union[str, Dict[str, Any]]:
    """
    Get commit history for a repository.
    
    Args:
        repo_path: Path to the local Git repository
        max_count: Maximum number of commits to retrieve (default: 20)
        branch: Branch to get history from (default: "HEAD")
    
    Returns:
        Dictionary with commit history or error message
    """
    logger.debug(f"Getting commit history for {repo_path}, branch: {branch}, max: {max_count}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        commits = []
        
        for commit in repo.iter_commits(branch, max_count=max_count):
            commits.append({
                'hash': commit.hexsha,
                'short_hash': commit.hexsha[:7],
                'author': commit.author.name,
                'email': commit.author.email,
                'date': commit.committed_datetime.isoformat(),
                'message': commit.message.strip().split('\n')[0],  # First line only
                'files_changed': len(commit.stats.files)
            })
        
        result = {
            'repo_path': repo_path,
            'branch': branch,
            'commit_count': len(commits),
            'commits': commits
        }
        
        logger.debug(f"Successfully retrieved {len(commits)} commits from {repo_path}")
        return result
        
    except git.GitCommandError as e:
        logger.error(f"Git command error: {str(e)}")
        return f"Git command error: {str(e)}"
    except Exception as e:
        logger.error(f"Error getting commit history: {str(e)}")
        return f"Error getting commit history: {str(e)}"

def get_file_history(repo_path: str, file_path: str, max_count: int = 10) -> Union[str, Dict[str, Any]]:
    """
    Get commit history for a specific file.
    
    Args:
        repo_path: Path to the local Git repository
        file_path: Path to the file within the repository
        max_count: Maximum number of commits to retrieve (default: 10)
    
    Returns:
        Dictionary with file history or error message
    """
    logger.debug(f"Getting file history for {file_path} in {repo_path}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        commits = []
        
        for commit in repo.iter_commits(paths=file_path, max_count=max_count):
            commits.append({
                'hash': commit.hexsha,
                'short_hash': commit.hexsha[:7],
                'author': commit.author.name,
                'date': commit.committed_datetime.isoformat(),
                'message': commit.message.strip().split('\n')[0]
            })
        
        result = {
            'repo_path': repo_path,
            'file_path': file_path,
            'commit_count': len(commits),
            'commits': commits
        }
        
        logger.debug(f"Successfully retrieved {len(commits)} commits for file {file_path}")
        return result
        
    except Exception as e:
        logger.error(f"Error getting file history: {str(e)}")
        return f"Error getting file history: {str(e)}"

def get_branch_info(repo_path: str) -> Union[str, Dict[str, Any]]:
    """
    Get information about all branches in a repository.
    
    Args:
        repo_path: Path to the local Git repository
    
    Returns:
        Dictionary with branch information or error message
    """
    logger.debug(f"Getting branch info for {repo_path}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        branches = []
        
        # Get current branch
        try:
            current_branch = repo.active_branch.name
        except TypeError:
            current_branch = None
        
        # Get all branches
        for branch in repo.branches:
            try:
                last_commit = branch.commit
                branches.append({
                    'name': branch.name,
                    'is_current': branch.name == current_branch,
                    'last_commit': {
                        'hash': last_commit.hexsha[:7],
                        'author': last_commit.author.name,
                        'date': last_commit.committed_datetime.isoformat(),
                        'message': last_commit.message.strip().split('\n')[0]
                    }
                })
            except Exception:
                branches.append({
                    'name': branch.name,
                    'is_current': branch.name == current_branch,
                    'last_commit': None
                })
        
        result = {
            'repo_path': repo_path,
            'current_branch': current_branch,
            'branch_count': len(branches),
            'branches': branches
        }
        
        logger.debug(f"Successfully retrieved info for {len(branches)} branches")
        return result
        
    except Exception as e:
        logger.error(f"Error getting branch info: {str(e)}")
        return f"Error getting branch info: {str(e)}"

def get_origin(repo_path: str) -> Union[str, Dict[str, Any]]:
    """
    Get the origin remote URL and related information for a repository.
    
    Args:
        repo_path: Path to the local Git repository
    
    Returns:
        Dictionary with origin information or error message
    """
    logger.debug(f"Getting origin info for {repo_path}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        
        # Get all remotes
        remotes = {}
        origin_url = None
        origin_fetch_url = None
        origin_push_url = None
        
        for remote in repo.remotes:
            remote_urls = list(remote.urls)
            remotes[remote.name] = {
                'name': remote.name,
                'urls': remote_urls,
                'fetch_url': remote_urls[0] if remote_urls else None,
                'push_url': remote_urls[0] if remote_urls else None
            }
            
            # Special handling for origin
            if remote.name == 'origin':
                origin_url = remote_urls[0] if remote_urls else None
                origin_fetch_url = origin_url
                origin_push_url = origin_url
        
        result = {
            'repo_path': repo_path,
            'origin_url': origin_url,
            'origin_fetch_url': origin_fetch_url,
            'origin_push_url': origin_push_url,
            'has_origin': origin_url is not None,
            'all_remotes': remotes,
            'remote_count': len(remotes)
        }
        
        logger.debug(f"Successfully retrieved origin info for {repo_path}")
        return result
        
    except git.InvalidGitRepositoryError:
        logger.error(f"Invalid Git repository: {repo_path}")
        return f"Invalid Git repository: {repo_path}"
    except Exception as e:
        logger.error(f"Error getting origin info: {str(e)}")
        return f"Error getting origin info: {str(e)}"
