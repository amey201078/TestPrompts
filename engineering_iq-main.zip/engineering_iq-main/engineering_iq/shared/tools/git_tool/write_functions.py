"""Git writing and repository management functions."""

import os
import git
import git.types
from typing import Dict, Union, Optional, Any

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings

settings = app_settings
logger = get_logger(__name__)
repo_base_dir: str = settings.git_dir

def clone_repo(repo_url: str, module_name: str = "") -> Union[str, Dict[str, Any]]:
    """
    Clones a Git repository from a given URL to a specified local path.

    Args:
        repo_url: The URL of the Git repository to clone (e.g., HTTPS or SSH URL)
        module_name: The name of the module (default: auto-generated from URL)

    Returns:
        Dictionary with clone information or error message
    """
    logger.debug(f"Attempting to clone repository: {repo_url}")
    
    if not module_name:
        logger.info("Module name is empty, dynamically generating based on repo URL...")
        module_name = repo_url.split("/")[-1].split(".")[0]

    base_path = os.path.join(repo_base_dir, module_name)
    
    try:
        # Check if directory already exists
        if os.path.exists(base_path):
            logger.warning(f"Directory already exists: {base_path}")
            return {
                'status': 'exists',
                'message': 'Repository directory already exists',
                'local_path': os.path.abspath(base_path),
                'repo_url': repo_url,
                'module_name': module_name
            }
        
        logger.info(f"Cloning repository from {repo_url} into {base_path}...")
        repo = git.Repo.clone_from(repo_url, base_path)
        
        result = {
            'status': 'success',
            'message': 'Repository cloned successfully',
            'local_path': os.path.abspath(base_path),
            'repo_url': repo_url,
            'module_name': module_name,
            'current_branch': repo.active_branch.name if repo.active_branch else 'HEAD',
            'commit_count': len(list(repo.iter_commits()))
        }
        
        logger.info(f"Repository cloned successfully - {os.path.abspath(base_path)}")
        return result
        
    except git.GitCommandError as e:
        logger.error(f"Git command error cloning repository: {str(e)}")
        return f"Git command error: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error cloning repository: {str(e)}")
        return f"Error cloning repository: {str(e)}"

def create_branch(repo_path: str, branch_name: str, checkout: bool = True) -> Union[str, Dict[str, Any]]:
    """
    Create a new branch in a Git repository.
    
    Args:
        repo_path: Path to the local Git repository
        branch_name: Name of the new branch to create
        checkout: Whether to checkout the new branch (default: True)
    
    Returns:
        Dictionary with branch creation information or error message
    """
    logger.debug(f"Creating branch {branch_name} in {repo_path}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        
        # Check if branch already exists
        if branch_name in [branch.name for branch in repo.branches]:
            logger.warning(f"Branch already exists: {branch_name}")
            return f"Branch already exists: {branch_name}"
        
        # Create new branch
        new_branch = repo.create_head(branch_name)
        
        if checkout:
            new_branch.checkout()
        
        result = {
            'status': 'success',
            'message': f'Branch {branch_name} created successfully',
            'branch_name': branch_name,
            'checked_out': checkout,
            'current_branch': repo.active_branch.name if repo.active_branch else 'HEAD',
            'repo_path': repo_path
        }
        
        logger.info(f"Branch {branch_name} created successfully in {repo_path}")
        return result
        
    except git.GitCommandError as e:
        logger.error(f"Git command error creating branch: {str(e)}")
        return f"Git command error: {str(e)}"
    except Exception as e:
        logger.error(f"Error creating branch: {str(e)}")
        return f"Error creating branch: {str(e)}"

def checkout_branch(repo_path: str, branch_name: str) -> Union[str, Dict[str, Any]]:
    """
    Checkout a specific branch in a Git repository.
    
    Args:
        repo_path: Path to the local Git repository
        branch_name: Name of the branch to checkout
    
    Returns:
        Dictionary with checkout information or error message
    """
    logger.debug(f"Checking out branch {branch_name} in {repo_path}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        
        # Check if branch exists
        if branch_name not in [branch.name for branch in repo.branches]:
            logger.error(f"Branch does not exist: {branch_name}")
            return f"Branch does not exist: {branch_name}"
        
        # Checkout branch
        repo.git.checkout(branch_name)
        
        result = {
            'status': 'success',
            'message': f'Checked out branch {branch_name}',
            'branch_name': branch_name,
            'previous_branch': repo.active_branch.name if repo.active_branch else 'HEAD',
            'repo_path': repo_path
        }
        
        logger.info(f"Checked out branch {branch_name} in {repo_path}")
        return result
        
    except git.GitCommandError as e:
        logger.error(f"Git command error checking out branch: {str(e)}")
        return f"Git command error: {str(e)}"
    except Exception as e:
        logger.error(f"Error checking out branch: {str(e)}")
        return f"Error checking out branch: {str(e)}"

def pull_changes(repo_path: str, remote: str = "origin", branch: str = "") -> Union[str, Dict[str, Any]]:
    """
    Pull changes from a remote repository.
    
    Args:
        repo_path: Path to the local Git repository
        remote: Name of the remote (default: "origin")
        branch: Branch to pull (default: current branch)
    
    Returns:
        Dictionary with pull information or error message
    """
    logger.debug(f"Pulling changes from {remote} in {repo_path}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        
        # Get current branch if not specified
        if not branch:
            branch = repo.active_branch.name if repo.active_branch else "HEAD"
        
        # Pull changes
        origin = repo.remotes[remote]
        pull_info = origin.pull(branch)
        
        result = {
            'status': 'success',
            'message': f'Pulled changes from {remote}/{branch}',
            'remote': remote,
            'branch': branch,
            'repo_path': repo_path,
            'changes_pulled': len(pull_info) > 0
        }
        
        logger.info(f"Pulled changes from {remote}/{branch} in {repo_path}")
        return result
        
    except git.GitCommandError as e:
        logger.error(f"Git command error pulling changes: {str(e)}")
        return f"Git command error: {str(e)}"
    except Exception as e:
        logger.error(f"Error pulling changes: {str(e)}")
        return f"Error pulling changes: {str(e)}"

def add_remote(repo_path: str, remote_name: str, remote_url: str) -> Union[str, Dict[str, Any]]:
    """
    Add a new remote to a Git repository.
    
    Args:
        repo_path: Path to the local Git repository
        remote_name: Name for the new remote
        remote_url: URL of the remote repository
    
    Returns:
        Dictionary with remote addition information or error message
    """
    logger.debug(f"Adding remote {remote_name} ({remote_url}) to {repo_path}")
    
    if not os.path.exists(repo_path):
        logger.error(f"Repository path not found: {repo_path}")
        return f"Repository path not found: {repo_path}"
    
    try:
        repo = git.Repo(repo_path)
        
        # Check if remote already exists
        if remote_name in [remote.name for remote in repo.remotes]:
            logger.warning(f"Remote already exists: {remote_name}")
            return f"Remote already exists: {remote_name}"
        
        # Add remote
        repo.create_remote(remote_name, remote_url)
        
        result = {
            'status': 'success',
            'message': f'Remote {remote_name} added successfully',
            'remote_name': remote_name,
            'remote_url': remote_url,
            'repo_path': repo_path,
            'total_remotes': len(repo.remotes)
        }
        
        logger.info(f"Remote {remote_name} added successfully to {repo_path}")
        return result
        
    except git.GitCommandError as e:
        logger.error(f"Git command error adding remote: {str(e)}")
        return f"Git command error: {str(e)}"
    except Exception as e:
        logger.error(f"Error adding remote: {str(e)}")
        return f"Error adding remote: {str(e)}"
