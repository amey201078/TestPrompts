"""Tool wrappers for Git reading functions."""

from google.genai import types
from google.adk.tools import FunctionTool, ToolContext
from google.adk.models import LlmRequest
from typing_extensions import override

from engineering_iq.shared.tools.git_tool.read_functions import (
    get_diff,
    get_commit_info,
    get_repo_status,
    get_commit_history,
    get_file_history,
    get_branch_info,
    get_origin
)

class GitDiffTool(FunctionTool):
    """Git diff tool for comparing commits"""
    
    def __init__(self):
        super().__init__(get_diff)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_url': types.Schema(
                        type=types.Type.STRING,
                        description="URL of the Git repository"
                    ),
                    'commit1': types.Schema(
                        type=types.Type.STRING,
                        description="First commit hash to compare"
                    ),
                    'commit2': types.Schema(
                        type=types.Type.STRING,
                        description="Second commit hash to compare"
                    )
                },
                required=["repo_url", "commit1", "commit2"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Diff
- You have a Git diff tool that can compare changes between two commits.
- Use this to analyze code changes, track modifications, and understand commit differences.
"""])

class GitCommitInfoTool(FunctionTool):
    """Git commit information tool"""
    
    def __init__(self):
        super().__init__(get_commit_info)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    ),
                    'commit_hash': types.Schema(
                        type=types.Type.STRING,
                        description="Commit hash to analyze"
                    )
                },
                required=["repo_path", "commit_hash"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Commit Info
- You have a Git commit info tool that provides detailed information about specific commits.
- Use this to get commit metadata, author info, statistics, and related details.
"""])

class GitStatusTool(FunctionTool):
    """Git repository status tool"""
    
    def __init__(self):
        super().__init__(get_repo_status)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    )
                },
                required=["repo_path"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Status
- You have a Git status tool that shows the current state of a repository.
- Use this to check for uncommitted changes, branch information, and repository status.
"""])

class GitHistoryTool(FunctionTool):
    """Git commit history tool"""
    
    def __init__(self):
        super().__init__(get_commit_history)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    ),
                    'max_count': types.Schema(
                        type=types.Type.INTEGER,
                        description="Maximum number of commits to retrieve (default: 20)"
                    ),
                    'branch': types.Schema(
                        type=types.Type.STRING,
                        description="Branch to get history from (default: 'HEAD')"
                    )
                },
                required=["repo_path"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git History
- You have a Git history tool that retrieves commit history for repositories.
- Use this to analyze project evolution, track changes over time, and understand development patterns.
"""])

class GitFileHistoryTool(FunctionTool):
    """Git file history tool"""
    
    def __init__(self):
        super().__init__(get_file_history)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    ),
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file within the repository"
                    ),
                    'max_count': types.Schema(
                        type=types.Type.INTEGER,
                        description="Maximum number of commits to retrieve (default: 10)"
                    )
                },
                required=["repo_path", "file_path"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git File History
- You have a Git file history tool that tracks changes to specific files.
- Use this to understand how individual files evolved and who made changes to them.
"""])

class GitBranchInfoTool(FunctionTool):
    """Git branch information tool"""
    
    def __init__(self):
        super().__init__(get_branch_info)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    )
                },
                required=["repo_path"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Branch Info
- You have a Git branch info tool that provides information about all branches in a repository.
- Use this to understand branch structure, current branch, and branch relationships.
"""])

class GitOriginTool(FunctionTool):
    """Git origin information tool"""
    
    def __init__(self):
        super().__init__(get_origin)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    )
                },
                required=["repo_path"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Origin
- You have a Git origin tool that provides information about the origin remote and all remotes in a repository.
- Use this to get remote URLs, check origin configuration, and understand repository remote setup.
"""])

# Create tool instances
git_diff_tool = GitDiffTool()
git_commit_info_tool = GitCommitInfoTool()
git_status_tool = GitStatusTool()
git_history_tool = GitHistoryTool()
git_file_history_tool = GitFileHistoryTool()
git_branch_info_tool = GitBranchInfoTool()
git_origin_tool = GitOriginTool()

# Collection of read tools
git_read_tools = [
    git_diff_tool,
    git_commit_info_tool,
    git_status_tool,
    git_history_tool,
    git_file_history_tool,
    git_branch_info_tool,
    git_origin_tool
]
