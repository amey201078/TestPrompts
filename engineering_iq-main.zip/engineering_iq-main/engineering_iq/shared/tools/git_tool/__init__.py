"""
Git Tool Package - Comprehensive Git repository operations and management.

This package provides a complete set of tools for Git operations including:
- Repository cloning and setup
- Commit analysis and diff comparison
- Branch management and switching
- Repository status and history tracking
- File-specific history analysis
- Remote repository management

All tools include proper error handling and validation for AI agent use.
"""

# Import core functions
from .read_functions import (
    get_diff,
    get_commit_info,
    get_repo_status,
    get_commit_history,
    get_file_history,
    get_branch_info,
    get_origin
)

from .write_functions import (
    clone_repo,
    create_branch,
    checkout_branch,
    pull_changes,
    add_remote
)

# Import tool instances
from .read_tools import (
    GitDiffTool,
    GitCommitInfoTool,
    GitStatusTool,
    GitHistoryTool,
    GitFileHistoryTool,
    GitBranchInfoTool,
    GitOriginTool,
    git_diff_tool,
    git_commit_info_tool,
    git_status_tool,
    git_history_tool,
    git_file_history_tool,
    git_branch_info_tool,
    git_origin_tool,
    git_read_tools
)

from .write_tools import (
    GitCloneTool,
    GitCreateBranchTool,
    GitCheckoutTool,
    GitPullTool,
    GitAddRemoteTool,
    git_clone_tool,
    git_create_branch_tool,
    git_checkout_tool,
    git_pull_tool,
    git_add_remote_tool,
    git_write_tools
)

# Create the complete tool collection (maintains backward compatibility)
all_git_tools = [
    git_diff_tool,
    git_commit_info_tool,
    git_status_tool,
    git_history_tool,
    git_file_history_tool,
    git_branch_info_tool,
    git_origin_tool,
    git_clone_tool,
    git_create_branch_tool,
    git_checkout_tool,
    git_pull_tool,
    git_add_remote_tool
]

# Export all public interfaces
__all__ = [
    # Core functions
    'get_diff',
    'get_commit_info',
    'get_repo_status',
    'get_commit_history',
    'get_file_history',
    'get_branch_info',
    'get_origin',
    'clone_repo',
    'create_branch',
    'checkout_branch',
    'pull_changes',
    'add_remote',
    
    # Tool classes
    'GitDiffTool',
    'GitCommitInfoTool',
    'GitStatusTool',
    'GitHistoryTool',
    'GitFileHistoryTool',
    'GitBranchInfoTool',
    'GitOriginTool',
    'GitCloneTool',
    'GitCreateBranchTool',
    'GitCheckoutTool',
    'GitPullTool',
    'GitAddRemoteTool',
    
    # Tool instances
    'git_diff_tool',
    'git_commit_info_tool',
    'git_status_tool',
    'git_history_tool',
    'git_file_history_tool',
    'git_branch_info_tool',
    'git_origin_tool',
    'git_clone_tool',
    'git_create_branch_tool',
    'git_checkout_tool',
    'git_pull_tool',
    'git_add_remote_tool',
    
    # Tool collections
    'git_read_tools',
    'git_write_tools',
    'all_git_tools'
]
