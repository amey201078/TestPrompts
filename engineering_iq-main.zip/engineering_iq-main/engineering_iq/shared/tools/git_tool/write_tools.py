"""Tool wrappers for Git writing functions."""

from google.genai import types
from google.adk.tools import FunctionTool, ToolContext
from google.adk.models import LlmRequest
from typing_extensions import override

from engineering_iq.shared.tools.git_tool.write_functions import (
    clone_repo,
    create_branch,
    checkout_branch,
    pull_changes,
    add_remote
)

class GitCloneTool(FunctionTool):
    """Git repository cloning tool"""
    
    def __init__(self):
        super().__init__(clone_repo)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_url': types.Schema(
                        type=types.Type.STRING,
                        description="URL of the Git repository to clone (HTTPS or SSH)"
                    ),
                    'module_name': types.Schema(
                        type=types.Type.STRING,
                        description="Name of the module (default: auto-generated from URL)"
                    )
                },
                required=["repo_url"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Clone
- You have a Git clone tool that can clone repositories from remote URLs.
- Use this to download and set up local copies of Git repositories for analysis or development.
"""])

class GitCreateBranchTool(FunctionTool):
    """Git branch creation tool"""
    
    def __init__(self):
        super().__init__(create_branch)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    ),
                    'branch_name': types.Schema(
                        type=types.Type.STRING,
                        description="Name of the new branch to create"
                    ),
                    'checkout': types.Schema(
                        type=types.Type.BOOLEAN,
                        description="Whether to checkout the new branch (default: True)"
                    )
                },
                required=["repo_path", "branch_name"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Create Branch
- You have a Git branch creation tool for creating new branches in repositories.
- Use this to create feature branches, experiment branches, or organize development work.
"""])

class GitCheckoutTool(FunctionTool):
    """Git branch checkout tool"""
    
    def __init__(self):
        super().__init__(checkout_branch)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    ),
                    'branch_name': types.Schema(
                        type=types.Type.STRING,
                        description="Name of the branch to checkout"
                    )
                },
                required=["repo_path", "branch_name"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Checkout
- You have a Git checkout tool for switching between branches in repositories.
- Use this to change the active branch and switch between different development contexts.
"""])

class GitPullTool(FunctionTool):
    """Git pull changes tool"""
    
    def __init__(self):
        super().__init__(pull_changes)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    ),
                    'remote': types.Schema(
                        type=types.Type.STRING,
                        description="Name of the remote (default: 'origin')"
                    ),
                    'branch': types.Schema(
                        type=types.Type.STRING,
                        description="Branch to pull (default: current branch)"
                    )
                },
                required=["repo_path"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Pull
- You have a Git pull tool for updating local repositories with remote changes.
- Use this to synchronize local repositories with remote updates and fetch new commits.
"""])

class GitAddRemoteTool(FunctionTool):
    """Git add remote tool"""
    
    def __init__(self):
        super().__init__(add_remote)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'repo_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the local Git repository"
                    ),
                    'remote_name': types.Schema(
                        type=types.Type.STRING,
                        description="Name for the new remote"
                    ),
                    'remote_url': types.Schema(
                        type=types.Type.STRING,
                        description="URL of the remote repository"
                    )
                },
                required=["repo_path", "remote_name", "remote_url"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Git Add Remote
- You have a Git add remote tool for adding new remote repositories.
- Use this to configure additional remote repositories for collaboration and backup.
"""])

# Create tool instances
git_clone_tool = GitCloneTool()
git_create_branch_tool = GitCreateBranchTool()
git_checkout_tool = GitCheckoutTool()
git_pull_tool = GitPullTool()
git_add_remote_tool = GitAddRemoteTool()

# Collection of write tools
git_write_tools = [
    git_clone_tool,
    git_create_branch_tool,
    git_checkout_tool,
    git_pull_tool,
    git_add_remote_tool
]
