"""
Document Analysis Tools - ADK tool wrappers for document understanding capabilities.
"""

from typing import Optional, Any, Dict
from typing_extensions import override

import google.genai.types as genai_types

from google.adk.tools import FunctionTool, ToolContext
from google.adk.models import LlmRequest

from engineering_iq.shared.tools.document_tool.document_functions import (
    analyze_document,
    analyze_document_batch,
    get_document_info,
    DocumentAnalysisResponse
)
from engineering_iq.shared.core.extended_model_support import DEFAULT_MODEL
from engineering_iq.shared.core.logger import get_logger

logger = get_logger(__name__)


async def analyze_document_tool(
    tool_context: ToolContext,
    file_path: str,
    custom_prompt: Optional[str] = None
) -> DocumentAnalysisResponse:
    """
    Analyze a document (local file or URL) to extract content summary, imagery description, and key insights using AI vision capabilities.
    
    Args:
        file_path: Path to local file or URL to remote file to analyze
        custom_prompt: Optional custom prompt to guide the analysis focus
        tool_context: Tool context with callback context
        
    Returns:
        DocumentAnalysisResponse with analysis results
    """
    logger.info(f"Analyzing document: {file_path}")

    result = DocumentAnalysisResponse(
        success=False,
        file_path=file_path,
        error_message="Unknown error occurred during analysis",
    )

    artifact: genai_types.Part = await tool_context.load_artifact(file_path)

    if artifact:

        logger.debug(f"Using cached artifact for {file_path}")

        logger.info(f"Document analysis successful using cached artifact for {file_path}")
        logger.info(f"Content summary: {artifact.text}")
        result = DocumentAnalysisResponse(
            success=True,
            file_path=file_path,
            content_summary=artifact.text
        )

    else:
    
        try:
            result = analyze_document(
                file_path=file_path,
                model=DEFAULT_MODEL,
                custom_prompt=custom_prompt
            )
            
            if result.success:
                logger.info(f"Document analysis successful for {file_path}")
                await tool_context.save_artifact(
                    filename=file_path,
                    artifact=genai_types.Part(text=result.content_summary),
                )
            else:
                logger.error(f"Document analysis failed for {file_path}: {result.error_message}")

        except Exception as e:
            logger.error(f"Error in document analysis tool: {e}")
            return DocumentAnalysisResponse(
                success=False,
                file_path=file_path,
                error_message=str(e)
            )
        
    return result


async def analyze_document_batch_tool(
    tool_context: ToolContext,
    file_paths: list[str],
    custom_prompt: Optional[str] = None
) -> list[DocumentAnalysisResponse]:
    """
    Analyze multiple documents in batch to extract content summaries, imagery descriptions, and key insights.
    
    Args:
        file_paths: List of file paths or URLs to analyze
        custom_prompt: Optional custom prompt to guide the analysis focus
        tool_context: Tool context with callback context
        
    Returns:
        List of DocumentAnalysisResponse objects
    """
    logger.info(f"Batch analyzing {len(file_paths)} documents")
    
    try:
        results = analyze_document_batch(
            file_paths=file_paths,
            model=DEFAULT_MODEL,
            custom_prompt=custom_prompt
        )
        
        successful = sum(1 for r in results if r.success)
        logger.info(f"Batch analysis completed: {successful}/{len(results)} successful")
        
        return results
        
    except Exception as e:
        logger.error(f"Error in batch document analysis tool: {e}")
        # Return error responses for all files
        return [
            DocumentAnalysisResponse(
                success=False,
                file_path=path,
                error_message=str(e)
            ) for path in file_paths
        ]


async def get_document_info_tool(
    tool_context: ToolContext,
    file_path: str
) -> Dict[str, Any]:
    """
    Get basic information about a document (file type, size, etc.) without performing full AI analysis.
    
    Args:
        file_path: Path to local file or URL to remote file
        tool_context: Tool context
        
    Returns:
        Dictionary with basic file information
    """
    logger.info(f"Getting document info for: {file_path}")
    
    try:
        result = get_document_info(file_path)
        
        if result.get("success"):
            logger.info(f"Document info retrieved for {file_path}")
        else:
            logger.error(f"Failed to get document info for {file_path}: {result.get('error_message')}")
            
        return result
        
    except Exception as e:
        logger.error(f"Error in document info tool: {e}")
        return {
            "success": False,
            "file_path": file_path,
            "error_message": str(e)
        }


class DocumentAnalysisTool(FunctionTool):
    """Tool for analyzing individual documents using LiteLLM document understanding."""
    
    def __init__(self):
        super().__init__(analyze_document_tool)

    @override
    def _get_declaration(self) -> genai_types.FunctionDeclaration | None:
        return genai_types.FunctionDeclaration(
            name=self.name,
            description="Analyze a document (local file or URL) to extract content summary, imagery description, and key insights using AI vision capabilities",
            parameters=genai_types.Schema(
                type=genai_types.Type.OBJECT,
                properties={
                    'file_path': genai_types.Schema(
                        type=genai_types.Type.STRING,
                        description="Path to local file or URL to remote file to analyze"
                    ),
                    'custom_prompt': genai_types.Schema(
                        type=genai_types.Type.STRING,
                        description="Optional custom prompt to guide the analysis focus"
                    )
                },
                required=['file_path']
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
                                         
#### TOOL: Document Analysis (binary files, images, office documents, etc.)
- You have a document_analysis tool that can analyze documents containing text, images, charts, or other visual content.
- PDF, image files (PNG, JPG, GIF), and office documents (DOCX, etc.) are supported.
- The tool extracts content summaries, describes imagery, and identifies key insights.
- Examples
    - analyze_document("/path/to/report.pdf")
    - analyze_document("https://example.com/chart.png", custom_prompt="Focus on data trends")
    - analyze_document("./financial_report.pdf", custom_prompt="Extract key financial metrics")
"""])


class DocumentBatchAnalysisTool(FunctionTool):
    """Tool for analyzing multiple documents in batch."""
    
    def __init__(self):
        super().__init__(analyze_document_batch_tool)

    @override
    def _get_declaration(self) -> genai_types.FunctionDeclaration | None:
        return genai_types.FunctionDeclaration(
            name=self.name,
            description="Analyze multiple documents in batch to extract content summaries, imagery descriptions, and key insights",
            parameters=genai_types.Schema(
                type=genai_types.Type.OBJECT,
                properties={
                    'file_paths': genai_types.Schema(
                        type=genai_types.Type.ARRAY,
                        description="List of file paths or URLs to analyze",
                        items=genai_types.Schema(type=genai_types.Type.STRING)
                    ),
                    'custom_prompt': genai_types.Schema(
                        type=genai_types.Type.STRING,
                        description="Optional custom prompt to guide the analysis focus"
                    )
                },
                required=['file_paths']
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Batch Document Analysis (batch processing of binary files, images, office documents, etc.)
- You have a document_batch_analysis tool for analyzing multiple documents at once.
- This tool returns analysis results for all documents.
- Consider file sizes and processing time for large batches
- Examples:
    - analyze_document_batch(["/path/to/doc1.pdf", "/path/to/doc2.pdf"])
    - analyze_document_batch(["https://example.com/report1.pdf", "./local_chart.png"])
    - analyze_document_batch(["file1.pdf", "file2.docx"], custom_prompt="Compare key findings")
"""])


class DocumentInfoTool(FunctionTool):
    """Tool for getting basic document information without full analysis."""
    
    def __init__(self):
        super().__init__(get_document_info_tool)

    @override
    def _get_declaration(self) -> genai_types.FunctionDeclaration | None:
        return genai_types.FunctionDeclaration(
            name=self.name,
            description="Get basic information about a document (file type, size, etc.) without performing full AI analysis",
            parameters=genai_types.Schema(
                type=genai_types.Type.OBJECT,
                properties={
                    'file_path': genai_types.Schema(
                        type=genai_types.Type.STRING,
                        description="Path to local file or URL to remote file"
                    )
                },
                required=['file_path']
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Document Info (binary files, images, office documents, etc.)
- You have a **document_info tool** for getting basic document information without using AI analysis tokens.
- Details returned include:
    - File type detection (PDF, image, office document, etc.)
    - File size in bytes
    - Whether file is local or remote
    - File accessibility validation
- Examples:
    - get_document_info("/path/to/document.pdf")
    - get_document_info("https://example.com/image.png")
"""])


# Create tool instances
document_analysis_tool = DocumentAnalysisTool()
document_batch_analysis_tool = DocumentBatchAnalysisTool()
document_info_tool = DocumentInfoTool()

# Tool collections
document_tools = [
    document_analysis_tool,
    document_batch_analysis_tool,
    document_info_tool
]

analysis_tools = [
    document_analysis_tool,
    document_batch_analysis_tool
]

info_tools = [
    document_info_tool
]
