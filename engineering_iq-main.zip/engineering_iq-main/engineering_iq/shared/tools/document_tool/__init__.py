"""
Document Tool Package - AI-powered document analysis using LiteLLM document understanding.

This package provides comprehensive document analysis capabilities including:
- Document content summarization
- Visual content description (images, charts, diagrams)
- Key insights extraction
- Support for local and remote files
- Batch processing capabilities

All tools leverage LiteLLM's document understanding capabilities for accurate analysis.
"""

# Import all functions for direct access
from .document_functions import (
    analyze_document,
    analyze_document_batch,
    get_document_info,
    DocumentAnalysisResponse
)

# Import all tool instances
from .document_tools import (
    DocumentAnalysisTool,
    DocumentBatchAnalysisTool,
    DocumentInfoTool,
    document_analysis_tool,
    document_batch_analysis_tool,
    document_info_tool,
    document_tools,
    analysis_tools,
    info_tools
)

# Export all public interfaces
__all__ = [
    # Functions
    'analyze_document',
    'analyze_document_batch',
    'get_document_info',
    
    # Response models
    'DocumentAnalysisResponse',
    
    # Tool classes
    'DocumentAnalysisTool',
    'DocumentBatchAnalysisTool', 
    'DocumentInfoTool',
    
    # Tool instances
    'document_analysis_tool',
    'document_batch_analysis_tool',
    'document_info_tool',
    
    # Tool collections
    'document_tools',
    'analysis_tools',
    'info_tools'
]
