"""
Document analysis functions using LiteLLM document understanding capabilities.
"""

import base64
from typing import Union, Optional, Dict, Any
from pathlib import Path
from urllib.parse import urlparse

import requests

from pydantic import BaseModel, Field

from litellm import completion
from engineering_iq.shared.core.extended_model_support import get_model, DEFAULT_MODEL
from engineering_iq.shared.core.logger import get_logger

logger = get_logger(__name__)

class DocumentAnalysisResponse(BaseModel):
    """Response model for document analysis."""
    
    success: bool = Field(description="Whether the analysis was successful")
    file_path: Optional[str] = Field(default=None, description="Path or URL of the analyzed file")
    file_type: Optional[str] = Field(default=None, description="Detected file type/extension")
    file_size: Optional[int] = Field(default=None, description="File size in bytes")
    content_summary: Optional[str] = Field(default=None, description="Summary of document content")
    imagery_summary: Optional[str] = Field(default=None, description="Summary of any images/visuals in document")
    key_insights: Optional[list] = Field(default=None, description="Key insights extracted from document")
    error_message: Optional[str] = Field(default=None, description="Error message if analysis failed")


def _download_remote_file(url: str) -> bytes:
    """Download a file from a remote URL."""
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        return response.content
    except requests.RequestException as e:
        msg = f"Error downloading file from {url}: {str(e)}"
        logger.error(msg)
        raise e


def _load_local_file(file_path: str) -> bytes:
    """Load a file from the local filesystem."""
    try:
        path_obj = Path(file_path)
        if not path_obj.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        with open(path_obj, 'rb') as f:
            return f.read()
    except Exception as e:
        logger.error(f"Failed to read local file {file_path}: {str(e)}")
        raise e


def _encode_to_base64(file_content: bytes) -> str:
    """Encode file content to base64."""
    return base64.b64encode(file_content).decode('utf-8')

def _detect_file_type(file_path: str, content: bytes) -> str:
    """Detect file type from path and content."""
    # Get extension from path
    path_obj = Path(file_path)
    extension = path_obj.suffix.lower()
    
    if extension:
        return extension[1:]  # Remove the dot
    
    # Try to detect from content magic bytes
    if content.startswith(b'%PDF'):
        return 'pdf'
    elif content.startswith(b'\x89PNG'):
        return 'png'
    elif content.startswith(b'\xff\xd8\xff'):
        return 'jpg'
    elif content.startswith(b'GIF8'):
        return 'gif'
    
    return None


def analyze_document(
    file_path: str,
    model: Union[str, Any] = DEFAULT_MODEL,
    custom_prompt: Optional[str] = None
) -> DocumentAnalysisResponse:
    """
    Analyze a document (local or remote) using LiteLLM document understanding.
    
    Args:
        file_path: Path to local file or URL to remote file
        model: Model to use for analysis (defaults to app default)
        custom_prompt: Optional custom prompt for analysis
        
    Returns:
        DocumentAnalysisResponse with analysis results
    """
    try:
        # Determine if file is local or remote
        parsed_url = urlparse(file_path)
        is_remote = parsed_url.scheme in ['http', 'https']
        
        # Load file content
        if is_remote:
            file_content = _download_remote_file(file_path)
        else:
            file_content = _load_local_file(file_path)
        
        # Get file info
        file_size = len(file_content)
        file_type = _detect_file_type(file_path, file_content)

        if file_type is None:
            logger.info(f"Unsupported file type for {file_path}, using 'unknown'")
            return DocumentAnalysisResponse(
                success=False,
                file_path=file_path,
                error_message="Unsupported file type detected"
            )

        # Convert to base64
        base64_content = _encode_to_base64(file_content)
        
        # Prepare the prompt for document analysis
        if custom_prompt:
            analysis_prompt = custom_prompt
        else:
            analysis_prompt = """
            Please analyze this document and provide:
            1. A comprehensive summary of the content
            2. A description of any images, charts, diagrams, or visual elements
            3. Key insights, main points, or important information extracted
            4. The overall structure and organization of the document
            
            Format your response as a structured analysis with clear sections.
            """
        
        # Prepare message with document
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": analysis_prompt
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:application/{file_type};base64,{base64_content}"
                        }
                    }
                ]
            }
        ]
        
        # Get model instance
        model_instance = get_model(model)
        
        # Make the completion call
        response = completion(
            model=model_instance if isinstance(model_instance, str) else str(model_instance),
            messages=messages
        )
        
        # Extract response content
        analysis_text = response.choices[0].message.content
        
        # Parse the analysis (simple parsing - could be enhanced with structured output)
        content_summary = analysis_text
        imagery_summary = "Analysis includes visual content description" if "image" in analysis_text.lower() or "visual" in analysis_text.lower() else "No visual content detected"
        key_insights = [insight.strip() for insight in analysis_text.split('\n') if insight.strip() and ('•' in insight or '-' in insight or insight.startswith(('1.', '2.', '3.')))]
        
        return DocumentAnalysisResponse(
            success=True,
            file_path=file_path,
            file_type=file_type,
            file_size=file_size,
            content_summary=content_summary,
            imagery_summary=imagery_summary,
            key_insights=key_insights if key_insights else ["Analysis completed successfully"]
        )
        
    except Exception as e:
        logger.error(f"Document analysis failed for {file_path}: {str(e)}")
        return DocumentAnalysisResponse(
            success=False,
            file_path=file_path,
            error_message=str(e)
        )


def analyze_document_batch(
    file_paths: list[str],
    model: Union[str, Any] = DEFAULT_MODEL,
    custom_prompt: Optional[str] = None
) -> list[DocumentAnalysisResponse]:
    """
    Analyze multiple documents in batch.
    
    Args:
        file_paths: List of file paths or URLs
        model: Model to use for analysis
        custom_prompt: Optional custom prompt for analysis
        
    Returns:
        List of DocumentAnalysisResponse objects
    """
    results = []
    for file_path in file_paths:
        result = analyze_document(file_path, model, custom_prompt)
        results.append(result)
    
    return results


def get_document_info(file_path: str) -> Dict[str, Any]:
    """
    Get basic information about a document without full analysis.
    
    Args:
        file_path: Path to local file or URL to remote file
        
    Returns:
        Dictionary with basic file information
    """
    try:
        # Determine if file is local or remote
        parsed_url = urlparse(file_path)
        is_remote = parsed_url.scheme in ['http', 'https']
        
        # Load file content
        if is_remote:
            file_content = _download_remote_file(file_path)
        else:
            file_content = _load_local_file(file_path)
        
        file_size = len(file_content)
        file_type = _detect_file_type(file_path, file_content)
        
        return {
            "success": True,
            "file_path": file_path,
            "file_type": file_type,
            "file_size": file_size,
            "is_remote": is_remote
        }
        
    except Exception as e:
        return {
            "success": False,
            "file_path": file_path,
            "error_message": str(e)
        }
