"""Tool wrappers for file writing functions."""

from google.genai import types
from google.adk.tools import FunctionTool, ToolContext
from google.adk.models import LlmRequest
from typing_extensions import override


from engineering_iq.shared.tools.file_tool.write_functions import write_file_safe, regex_replace_in_file


class SmartFileWriteTool(FunctionTool):
    """Safe file writer with overwrite protection"""
    
    def __init__(self):
        super().__init__(write_file_safe)
    


    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file to write"
                    ),
                    'content': types.Schema(
                        type=types.Type.STRING,
                        description="Content to write"
                    ),
                    'overwrite': types.Schema(
                        type=types.Type.BOOLEAN,
                        description="Whether to overwrite existing files (default: False)"
                    )
                },
                required=["file_path", "content"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Write File (Safe)
You have a write_file_safe tool that protects against accidental overwrites.
"""])

class RegexReplaceTool(FunctionTool):
    """Regex find and replace in files with safety features"""
    
    def __init__(self):
        super().__init__(regex_replace_in_file)
    


    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file to modify"
                    ),
                    'search_pattern': types.Schema(
                        type=types.Type.STRING,
                        description="Regex pattern to search for"
                    ),
                    'replacement': types.Schema(
                        type=types.Type.STRING,
                        description="Replacement string (can use group references like \\1, \\2)"
                    ),
                    'flags': types.Schema(
                        type=types.Type.STRING,
                        description="Regex flags as string: 'i' (case-insensitive), 'm' (multiline), 's' (dotall), 'x' (verbose)"
                    ),
                    'backup': types.Schema(
                        type=types.Type.BOOLEAN,
                        description="Whether to create a backup file before modification (default: True)"
                    )
                },
                required=["file_path", "search_pattern", "replacement"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""You have a regex_replace_in_file tool for performing powerful find and replace operations using regular expressions.
#### TOOL: Regex Replace File Tool
- This tool allows you to search for patterns in files and replace them with specified strings, with safety features to prevent accidental data loss.
- The tool automatically creates backups (.bak files) unless backup=False
- Use group references (\\1, \\2) in replacement strings to reference captured groups
- Available flags: 'i' (ignore case), 'm' (multiline), 's' (dotall), 'x' (verbose)
"""])

# Create tool instances
smart_file_write_tool = SmartFileWriteTool()
regex_replace_tool = RegexReplaceTool()

# Collection of write tools
write_tools = [
    smart_file_write_tool,
    regex_replace_tool
]
