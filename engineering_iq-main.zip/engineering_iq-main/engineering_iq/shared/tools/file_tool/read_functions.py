"""File reading functions with memory management and safety features."""

from __future__ import annotations
import os
import math
import glob
import re
from typing import List, Optional
import tiktoken

from google.adk.tools import ToolContext
from pydantic import BaseModel, Field

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings

logger = get_logger(__name__)
settings = app_settings

# Global tokenizer cache
_TOKENIZERS = {}

class FileResponse(BaseModel):
    content: str = Field(description="File content or result message")
    token_count: Optional[int] = Field(default=None, description="Token count of content")
    truncated: bool = Field(default=False, description="Whether content was truncated")
    file_path: str = Field(description="Path to the file")

class ListResponse(BaseModel):
    files: List[str] = Field(description="List of file paths")
    total_count: int = Field(description="Total number of files found")

def _get_tokenizer(model_name: str):
    """Get a tokenizer for the specified model."""
    if not model_name:
        model_name = settings.default_model

    if model_name in _TOKENIZERS:
        return _TOKENIZERS[model_name]
    
    try:
        tokenizer = tiktoken.encoding_for_model(model_name)
        logger.debug(f"Using tiktoken with {model_name} encoding")
    except Exception:
        tokenizer = tiktoken.get_encoding("cl100k_base")
        logger.debug(f"Model {model_name} not found in tiktoken, using cl100k_base encoding")
    
    _TOKENIZERS[model_name] = tokenizer
    return tokenizer

def count_tokens(text: str, model_name: str = None) -> int:
    """Count the number of tokens in the given text."""
    if not model_name:
        model_name = settings.default_model
        
    tokenizer = _get_tokenizer(model_name)
    
    if tokenizer:
        tokens = tokenizer.encode(text)
        return len(tokens)
    else:
        # Approximate token count (4 chars per token)
        return math.ceil(len(text) / 4)

async def smart_read_file(
    tool_context: ToolContext,
    file_path: str, 
    max_tokens: int = app_settings.default_tool_max_tokens,
    start_position: int = 0
) -> FileResponse:
    """
    Read a file with automatic memory management. 
    Will truncate content if it exceeds max_tokens to prevent memory issues.
    
    Args:
        file_path: Path to the file to read
        max_tokens: Maximum tokens to read
        start_position: Token position to start reading from (default: 0)
        tool_context: Tool context
        
    Returns:
        FileResponse with content, token count, and truncation status
    """
    logger.debug(f"Smart reading file: {file_path}, max_tokens: {max_tokens}")
    
    if not os.path.exists(file_path):
        return FileResponse(
            content=f"File not found: {file_path}",
            file_path=file_path,
            token_count=0
        )
    
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        total_tokens = count_tokens(content)
        
        if total_tokens <= max_tokens:
            # File is small enough, return full content
            return FileResponse(
                content=content,
                token_count=total_tokens,
                truncated=False,
                file_path=file_path
            )
        
        # File is too large, need to truncate
        tokenizer = _get_tokenizer(settings.default_model)
        
        if tokenizer:
            tokens = tokenizer.encode(content)
            if start_position >= len(tokens):
                return FileResponse(
                    content=f"Start position {start_position} exceeds file length ({len(tokens)} tokens)",
                    file_path=file_path,
                    token_count=0
                )
            
            end_position = min(start_position + max_tokens, len(tokens))
            selected_tokens = tokens[start_position:end_position]
            truncated_content = tokenizer.decode(selected_tokens)
            
            return FileResponse(
                content=truncated_content,
                token_count=len(selected_tokens),
                truncated=True,
                file_path=file_path
            )
        else:
            # Fallback to character-based truncation
            approx_chars_per_token = 4
            start_char = start_position * approx_chars_per_token
            max_chars = max_tokens * approx_chars_per_token
            
            if start_char >= len(content):
                return FileResponse(
                    content=f"Start position exceeds file length",
                    file_path=file_path,
                    token_count=0
                )
            
            end_char = min(start_char + max_chars, len(content))
            truncated_content = content[start_char:end_char]
            
            return FileResponse(
                content=truncated_content,
                token_count=count_tokens(truncated_content),
                truncated=True,
                file_path=file_path
            )
            
    except Exception as e:
        return FileResponse(
            content=f"Error reading file {file_path}: {str(e)}",
            file_path=file_path,
            token_count=0
        )

async def smart_list_files(
    tool_context: ToolContext,
    directory_path: str,
    pattern: str = "*",
    recursive: bool = False,
    max_results: int = 100
) -> ListResponse:
    """
    List files in a directory with result limits to prevent memory overload.
    
    Args:
        directory_path: Path to the directory
        pattern: Glob pattern to match files (default: "*")
        recursive: Whether to search recursively (default: False)
        max_results: Maximum number of results to return (default: 100)
        tool_context: Tool context
        
    Returns:
        ListResponse with files list and total count
    """
    logger.debug(f"Smart listing files in: {directory_path}, pattern: {pattern}")
    
    if not os.path.exists(directory_path):
        return ListResponse(files=[], total_count=0)
    
    if not os.path.isdir(directory_path):
        return ListResponse(files=[], total_count=0)
    
    search_pattern = os.path.join(directory_path, "**", pattern) if recursive else os.path.join(directory_path, pattern)
    all_files = glob.glob(search_pattern, recursive=recursive)
    
    # Filter to only files (not directories)
    file_paths = [os.path.relpath(f, directory_path) for f in all_files if os.path.isfile(f)]
    
    # Limit results to prevent memory issues
    limited_files = file_paths[:max_results]
    
    return ListResponse(
        files=limited_files,
        total_count=len(file_paths)
    )
