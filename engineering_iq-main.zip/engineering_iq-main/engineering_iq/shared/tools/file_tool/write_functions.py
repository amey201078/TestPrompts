"""File writing and modification functions with safety features."""

from __future__ import annotations
import os
import re

from google.adk.tools import ToolContext
from pydantic import BaseModel, Field

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.tools.file_tool.read_functions import count_tokens

logger = get_logger(__name__)

class WriteResponse(BaseModel):
    status: str = Field(description="success or error")
    message: str = Field(description="Result message")
    file_path: str = Field(description="Path to the file")

async def write_file_safe(
    tool_context: ToolContext,
    file_path: str,
    content: str,
    overwrite: bool = False
) -> WriteResponse:
    """
    Write content to a file with safety checks.
    
    Args:
        file_path: Path to the file to write
        content: Content to write
        overwrite: Whether to overwrite existing files (default: False)
        tool_context: Tool context
        
    Returns:
        WriteResponse with status and message
    """
    logger.debug(f"Safe writing to file: {file_path}, overwrite: {overwrite}")
    
    if os.path.exists(file_path) and not overwrite:
        return WriteResponse(
            status="error",
            message="File exists and overwrite is False",
            file_path=file_path
        )
    
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(content)
        
        return WriteResponse(
            status="success",
            message="File written successfully",
            file_path=file_path
        )
    except Exception as e:
        logger.error(f"Error writing file {file_path}: {str(e)}")
        return WriteResponse(
            status="error",
            message=str(e),
            file_path=file_path
        )

async def regex_replace_in_file(
    tool_context: ToolContext,
    file_path: str,
    search_pattern: str,
    replacement: str,
    flags: str = "",
    backup: bool = True
) -> WriteResponse:
    """
    Perform regex find and replace operations in a file with safety checks.
    
    Args:
        file_path: Path to the file to modify
        search_pattern: Regex pattern to search for
        replacement: Replacement string (can use group references like \1, \2)
        flags: Regex flags as string (e.g., "i" for case-insensitive, "m" for multiline)
        backup: Whether to create a backup file before modification (default: True)
        tool_context: Tool context
        
    Returns:
        WriteResponse with status, message, and replacement count
    """
    logger.debug(f"Regex replace in file: {file_path}, pattern: {search_pattern}")
    
    if not os.path.exists(file_path):
        return WriteResponse(
            status="error",
            message=f"File not found: {file_path}",
            file_path=file_path
        )
    
    try:
        # Parse regex flags
        regex_flags = 0
        if "i" in flags.lower():
            regex_flags |= re.IGNORECASE
        if "m" in flags.lower():
            regex_flags |= re.MULTILINE
        if "s" in flags.lower():
            regex_flags |= re.DOTALL
        if "x" in flags.lower():
            regex_flags |= re.VERBOSE
        
        # Compile regex pattern
        try:
            pattern = re.compile(search_pattern, regex_flags)
        except re.error as e:
            return WriteResponse(
                status="error",
                message=f"Invalid regex pattern: {str(e)}",
                file_path=file_path
            )
        
        # Read file content
        with open(file_path, 'r', encoding='utf-8') as file:
            original_content = file.read()
        
        # Check file size for memory safety
        file_tokens = count_tokens(original_content)
        if file_tokens > 50000:  # Large file warning
            logger.warning(f"Large file being processed: {file_tokens} tokens")
        
        # Create backup if requested
        if backup:
            backup_path = f"{file_path}.bak"
            with open(backup_path, 'w', encoding='utf-8') as backup_file:
                backup_file.write(original_content)
            logger.debug(f"Backup created: {backup_path}")
        
        # Perform replacement
        new_content, replacement_count = pattern.subn(replacement, original_content)
        
        if replacement_count == 0:
            return WriteResponse(
                status="success",
                message=f"No matches found for pattern '{search_pattern}'",
                file_path=file_path
            )
        
        # Write modified content back to file
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(new_content)
        
        success_message = f"Successfully replaced {replacement_count} occurrence(s) of pattern '{search_pattern}'"
        if backup:
            success_message += f". Backup saved as {file_path}.bak"
        
        return WriteResponse(
            status="success",
            message=success_message,
            file_path=file_path
        )
        
    except IOError as e:
        return WriteResponse(
            status="error",
            message=f"Error processing file {file_path}: {str(e)}",
            file_path=file_path
        )
    except Exception as e:
        return WriteResponse(
            status="error",
            message=f"Unexpected error: {str(e)}",
            file_path=file_path
        )
