"""Tool wrappers for file reading functions."""

from google.genai import types
from google.adk.tools import FunctionTool
from typing_extensions import override

from engineering_iq.shared.tools.file_tool.read_functions import smart_read_file, smart_list_files
from engineering_iq.shared.tools.file_tool.search_functions import search_in_files, exploratory_search # Import exploratory_search
class SmartFileReadTool(FunctionTool):
    """Smart file reader with automatic memory management"""
    
    def __init__(self):
        super().__init__(smart_read_file)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file to read"
                    ),
                    'max_tokens': types.Schema(
                        type=types.Type.INTEGER,
                        description="Maximum tokens to read (default: app_settings.default_tool_max_tokens)"
                    ),
                    'start_position': types.Schema(
                        type=types.Type.INTEGER,
                        description="Token position to start reading from (default: 0)"
                    )
                },
                required=["file_path"]
            ),
        )

#     @override
#     async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
#         await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
#         llm_request.append_instructions(["""
# You have a smart_read_file tool that automatically manages memory by limiting token usage.
# You should never read entire file unless absolutely necessary.
# You have other tools for listing, writing, searching, and regex replacement - try to use them before reading large files or groups of files.
# """])

class SmartFileListTool(FunctionTool):
    """Smart file lister with result limits"""
    
    def __init__(self):
        super().__init__(smart_list_files)
    


    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'directory_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the directory"
                    ),
                    'pattern': types.Schema(
                        type=types.Type.STRING,
                        description="Glob pattern to match files (default: '*')"
                    ),
                    'recursive': types.Schema(
                        type=types.Type.BOOLEAN,
                        description="Whether to search recursively (default: False)"
                    ),
                    'max_results': types.Schema(
                        type=types.Type.INTEGER,
                        description="Maximum number of results to return (default: 100)"
                    )
                },
                required=["directory_path"]
            ),
        )

#     @override
#     async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
#         await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
#         llm_request.append_instructions(["""
# You have a smart_list_files tool that limits results to prevent memory overload.
# """])

class SmartFileSearchTool(FunctionTool):
    """Smart text search across files with limits"""
    
    def __init__(self):
        super().__init__(search_in_files)
    


    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'directory_path': types.Schema(
                        type=types.Type.STRING,
                        description="Directory to search in"
                    ),
                    'search_term': types.Schema(
                        type=types.Type.STRING,
                        description="Text to search for"
                    ),
                    'file_pattern': types.Schema(
                        type=types.Type.STRING,
                        description="File pattern to match (default: '*.py')"
                    ),
                    'max_matches': types.Schema(
                        type=types.Type.INTEGER,
                        description="Maximum matches to return (default: 50)"
                    )
                },
                required=["directory_path", "search_term"]
            ),
        )

#     @override
#     async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
#         await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
#         llm_request.append_instructions(["""
# You have a search_in_files tool for finding content across multiple files efficiently.
# """])

class ExploratorySearchTool(FunctionTool):
    """Performs a keyword-based search returning diverse, context-rich snippets from files."""

    def __init__(self):
        super().__init__(exploratory_search)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'directory_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the directory to search within."
                    ),
                    'keywords': types.Schema(
                        type=types.Type.ARRAY,
                        items=types.Schema(type=types.Type.STRING),
                        description="A list of literal keywords to search for."
                    ),
                    'file_pattern': types.Schema(
                        type=types.Type.STRING,
                        description="Glob pattern for files to search. Defaults to '*' (all files)."
                    ),
                    'min_matches': types.Schema(
                        type=types.Type.INTEGER,
                        description="Minimum keyword matches for a file to be considered. Defaults to 3."
                    ),
                    'before_chars': types.Schema(
                        type=types.Type.INTEGER,
                        description="Characters before/after match for chunks. Defaults to 50."
                    ),
                    'after_chars': types.Schema(
                        type=types.Type.INTEGER,
                        description="Characters after a match for chunks. Defaults to 50."
                    ),
                    'max_chunks': types.Schema(
                        type=types.Type.INTEGER,
                        description="Maximum number of unique result chunks to return. Defaults to 1000."
                    ),
                    'max_files_to_scan': types.Schema(
                        type=types.Type.INTEGER,
                        description="Max files for the underlying chunk scoring to scan. Defaults to 200."
                    )
                },
                required=["directory_path", "keywords"]
            ),
        )

# Create tool instances
smart_file_read_tool = SmartFileReadTool()
smart_file_list_tool = SmartFileListTool()
smart_file_search_tool = SmartFileSearchTool()
exploratory_search_tool = ExploratorySearchTool()

# Collection of read tools
read_tools = [
    smart_file_read_tool,
    smart_file_list_tool,
    smart_file_search_tool,
    exploratory_search_tool # Add the new tool
]
