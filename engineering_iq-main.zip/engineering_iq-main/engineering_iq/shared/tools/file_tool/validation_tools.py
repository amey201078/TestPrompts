"""Tool wrappers for file validation functions."""

from google.genai import types
from google.adk.tools import FunctionTool
from typing_extensions import override

from engineering_iq.shared.tools.file_tool.validation_functions import validate_file_exists, validate_multiple_files

class FileValidationTool(FunctionTool):
    """Tool for validating file existence and properties"""
    
    def __init__(self):
        super().__init__(validate_file_exists)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the file to validate"
                    ),
                    'check_readable': types.Schema(
                        type=types.Type.BOOLEAN,
                        description="Whether to check if file is readable (default: True)"
                    ),
                    'check_writable': types.Schema(
                        type=types.Type.BOOLEAN,
                        description="Whether to check if file is writable (default: False)"
                    )
                },
                required=["file_path"]
            ),
        )

class MultipleFileValidationTool(FunctionTool):
    """Tool for validating multiple files for existence and properties"""
    
    def __init__(self):
        super().__init__(validate_multiple_files)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_paths': types.Schema(
                        type=types.Type.ARRAY,
                        items=types.Schema(type=types.Type.STRING),
                        description="List of file paths to validate"
                    ),
                    'check_readable': types.Schema(
                        type=types.Type.BOOLEAN,
                        description="Whether to check if files are readable (default: True)"
                    ),
                    'check_writable': types.Schema(
                        type=types.Type.BOOLEAN,
                        description="Whether to check if files are writable (default: False)"
                    )
                },
                required=["file_paths"]
            ),
        )

# Create tool instances
file_validation_tool = FileValidationTool()
multiple_file_validation_tool = MultipleFileValidationTool()

# Collection of validation tools
validation_tools = [
    file_validation_tool,
    multiple_file_validation_tool
]
