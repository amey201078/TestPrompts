"""File validation functions for checking file existence and properties."""

from __future__ import annotations
import os
from typing import Optional
from pydantic import BaseModel, Field
from google.adk.tools import ToolContext
from engineering_iq.shared.core.logger import get_logger

logger = get_logger(__name__)

class FileValidationResponse(BaseModel):
    """Response model for file validation operations."""
    file_path: str = Field(description="Path to the file being validated")
    exists: bool = Field(description="Whether the file exists")
    is_file: bool = Field(default=False, description="Whether the path points to a file (not directory)")
    is_directory: bool = Field(default=False, description="Whether the path points to a directory")
    size_bytes: Optional[int] = Field(default=None, description="File size in bytes if it exists")
    readable: bool = Field(default=False, description="Whether the file is readable")
    writable: bool = Field(default=False, description="Whether the file is writable")
    message: str = Field(description="Validation result message")

async def validate_file_exists(
    tool_context: ToolContext,
    file_path: str,
    check_readable: bool = True,
    check_writable: bool = False
) -> FileValidationResponse:
    """
    Validate that a file exists and optionally check its properties.
    
    Args:
        tool_context: Tool context
        file_path: Path to the file to validate
        check_readable: Whether to check if file is readable (default: True)
        check_writable: Whether to check if file is writable (default: False)
        
    Returns:
        FileValidationResponse with validation results
    """
    logger.debug(f"Validating file existence: {file_path}")
    
    # Initialize response with basic info
    response = FileValidationResponse(
        file_path=file_path,
        exists=False,
        message=""
    )
    
    try:
        # Check if path exists
        if not os.path.exists(file_path):
            response.message = f"File does not exist: {file_path}"
            return response
            
        response.exists = True
        
        # Check if it's a file or directory
        response.is_file = os.path.isfile(file_path)
        response.is_directory = os.path.isdir(file_path)
        
        if response.is_file:
            # Get file size
            try:
                response.size_bytes = os.path.getsize(file_path)
            except OSError as e:
                logger.warning(f"Could not get size for {file_path}: {e}")
                
            # Check permissions if requested
            if check_readable:
                response.readable = os.access(file_path, os.R_OK)
                
            if check_writable:
                response.writable = os.access(file_path, os.W_OK)
                
            # Build success message
            parts = [f"File exists: {file_path}"]
            if response.size_bytes is not None:
                parts.append(f"Size: {response.size_bytes} bytes")
            if check_readable:
                parts.append(f"Readable: {response.readable}")
            if check_writable:
                parts.append(f"Writable: {response.writable}")
                
            response.message = " | ".join(parts)
            
        elif response.is_directory:
            response.message = f"Path exists but is a directory, not a file: {file_path}"
        else:
            response.message = f"Path exists but is neither a file nor directory: {file_path}"
            
    except Exception as e:
        logger.error(f"Error validating file {file_path}: {e}")
        response.message = f"Error validating file {file_path}: {str(e)}"
        
    return response

async def validate_multiple_files(
    tool_context: ToolContext,
    file_paths: list[str],
    check_readable: bool = True,
    check_writable: bool = False
) -> list[FileValidationResponse]:
    """
    Validate multiple files for existence and properties.
    
    Args:
        tool_context: Tool context
        file_paths: List of file paths to validate
        check_readable: Whether to check if files are readable (default: True)
        check_writable: Whether to check if files are writable (default: False)
        
    Returns:
        List of FileValidationResponse objects
    """
    logger.debug(f"Validating {len(file_paths)} files")
    
    results = []
    for file_path in file_paths:
        result = await validate_file_exists(
            tool_context=tool_context,
            file_path=file_path,
            check_readable=check_readable,
            check_writable=check_writable
        )
        results.append(result)
        
    return results
