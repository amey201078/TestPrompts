import os
import random
import re
import regex

from pydantic import BaseModel
from google.adk.tools import ToolContext # Import ToolContext

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.tools.file_tool.read_functions import smart_list_files

logger = get_logger(__name__)

class SearchResult(BaseModel):
    """
    Represents a single search result item, typically a contextual chunk from a file.
    
    Attributes:
        metadata (dict): A dictionary containing metadata about the search result,
                         expected to include at least a 'path' to the source file.
        chunk (str): The contextual snippet of text that contains the search match.
        score (float): A score indicating the relevance or strength of the match.
    """
    metadata: dict
    chunk: str
    score: float

def format_result_item(item: SearchResult) -> str:
    """Format a single result item for display."""
    return f"**{item.metadata.get('path', 'Unknown Path')}**: {item.chunk} (Score: {item.score})"

def highlight_keywords(text: str, keywords: list[str]) -> str:
    """Highlight keywords in the given text."""
    return re.sub(
        r'({})'.format('|'.join(map(re.escape, keywords))),
        r'**\1**',
        text,
        flags=re.IGNORECASE
    )

async def scored_chunks(
    tool_context: ToolContext,
    directory_path: str,
    keywords: list[str],
    file_pattern: str = "*",
    min_matches: int = 3,
    before_chars: int = 50,
    after_chars: int = 50,
    max_files_to_scan: int = 200
) -> list[dict]:
    """
    Searches for literal keywords within the content of files in a directory.

    This function lists files in `directory_path` matching `file_pattern`.
    For each file, it reads the content and searches for occurrences of the
    provided `keywords` (treated as literal strings). If matches are found,
    it extracts contextual snippets (chunks) of `before_chars` and `after_chars`
    around each match.

    Results are scored based on the total number of keyword matches in a file's content.
    Files are included in the output if they meet the `min_matches` threshold.

    Args:
        tool_context (ToolContext): The ADK tool context, used by `smart_list_files`.
        directory_path (str): The path to the directory to search within.
        keywords (list[str]): A list of literal keywords to search for.
        file_pattern (str, optional): A glob pattern to filter files to be searched.
            Defaults to "*" (all files).
        min_matches (int, optional): Minimum number of keyword matches in a file's
            content for it to be included. Defaults to 3.
        before_chars (int, optional): Characters to include before a keyword match
            in the extracted chunk. Defaults to 50.
        after_chars (int, optional): Characters to include after a keyword match
            in the extracted chunk. Defaults to 50.
        max_files_to_scan (int, optional): Maximum number of files to list and scan.
            Defaults to 200.

    Returns:
        list[dict]: A list of dictionaries, sorted by score (descending). Each dict
            represents a file that met `min_matches` and contains:
            - 'metadata' (dict): Contains the 'path' (str) of the file.
            - 'matches': A list of dicts, each with 'chunk' (str) and 'match' (str).
            - 'score' (int): Total keyword matches in the file.
    """
    pattern = re.compile(r"\b(" + "|".join(re.escape(keyword) for keyword in keywords) + r")\b", re.IGNORECASE)
    results = []

    if not os.path.exists(directory_path):
        logger.error(f"Directory not found for scored_chunks: {directory_path}")
        return []

    list_response = await smart_list_files(tool_context, directory_path, file_pattern, True, max_files_to_scan)

    for relative_file_path in list_response.files:
        full_file_path = os.path.join(directory_path, relative_file_path)
        try:
            with open(full_file_path, 'r', encoding='utf-8', errors='ignore') as file:
                file_content = file.read()
        except Exception as e:
            logger.error(f"Error reading file {full_file_path} in scored_chunks: {e}")
            continue

        unique_chunks_for_file = set()
        file_matches = []
        
        if file_content:
            for match in pattern.finditer(file_content):
                start = max(0, match.start() - before_chars)
                end = min(len(file_content), match.end() + after_chars)
                chunk = file_content[start:end]
                if chunk not in unique_chunks_for_file:
                    unique_chunks_for_file.add(chunk)
                    file_matches.append({"chunk": chunk, "match": match.group()})

        if file_matches and len(file_matches) >= min_matches:
            results.append({
                "metadata": {"path": relative_file_path},
                "matches": file_matches,
                "score": len(file_matches),
            })

    return sorted(results, key=lambda x: x["score"], reverse=True)

async def exploratory_search(
    tool_context: ToolContext,
    keywords: list[str],
    directory_path: str,
    file_pattern: str = "*",
    min_matches: int = 3,
    before_chars: int = 50,
    after_chars: int = 50,
    max_chunks: int = 1000,
    max_files_to_scan: int = 200
) -> list:
    """
    Performs a keyword-based search directly on file contents within a directory
    and returns a diverse set of formatted result strings.

    This function uses the refactored `scored_chunks` (which now reads files directly)
    to find and score occurrences of `keywords` within files matching `file_pattern`
    in the `directory_path`.

    It then selects a diverse subset of these scored file results: a portion of the
    highest-scoring files, a portion of the lowest-scoring files (that still met
    `min_matches`), and a random sample from the remaining files. This helps to
    provide a broader perspective than just top-N results.

    The final output is a list of formatted strings, each representing a unique,
    highlighted contextual chunk from the content of the selected files.

    Args:
        tool_context (ToolContext): The ADK tool context, passed to `scored_chunks`.
        keywords (list[str]): A list of literal keywords to search for.
        directory_path (str): The path to the directory to search within.
        file_pattern (str, optional): Glob pattern for files to search in `scored_chunks`.
            Defaults to "*".
        min_matches (int, optional): Minimum keyword matches for a file to be considered
            by `scored_chunks`. Defaults to 3.
        before_chars (int, optional): Characters before/after match for chunks in
            `scored_chunks`. Defaults to 50.
        after_chars (int, optional): Characters after a match for chunks in
            `scored_chunks`. Defaults to 50.
        max_chunks (int, optional): The maximum number of unique result chunks to return.
            Defaults to 1000.
        max_files_to_scan (int, optional): Max files for `scored_chunks` to scan.
            Defaults to 200.


    Returns:
        list[str]: A list of formatted strings, where each string represents a search
            result item (chunk with highlighted keywords, source file path, and score),
            selected to ensure diversity. Returns an empty list if no initial matches
            are found by `scored_chunks`.
    """

    results = await scored_chunks(
        tool_context=tool_context,
        directory_path=directory_path,
        keywords=keywords,
        file_pattern=file_pattern,
        min_matches=min_matches,
        before_chars=before_chars,
        after_chars=after_chars,
        max_files_to_scan=max_files_to_scan
    )

    if not results:
        return []

    # Determine how many chunks to pick from each category
    high_score_count = max_chunks * 2 // 4  # 2/4 of total
    low_score_count = max_chunks // 4       # 1/4 of total
    random_count = max_chunks // 4         # 1/4 of total

    # Split results into high, low, and random groups
    high_scoring = results[:high_score_count]
    low_scoring = results[-low_score_count:]
    remaining_results = results[high_score_count:-low_score_count]
    random_selection = random.sample(remaining_results, min(random_count, len(remaining_results)))

    # Combine and shuffle the selected results
    selected_results = high_scoring + low_scoring + random_selection
    random.shuffle(selected_results)

    # Build the response with deduplication
    seen_chunks = set()
    response = []
    for result in selected_results:
        metadata_obj = result.get("metadata", {})
        for match in result.get("matches", []):
            chunk = match.get("chunk", "No Match Found")
            path_val = metadata_obj.get("path") if isinstance(metadata_obj, dict) else getattr(metadata_obj, "path", "Unknown Path")
            if (path_val, chunk) not in seen_chunks: 
                seen_chunks.add((path_val, chunk)) 
                highlighted_chunk = highlight_keywords(chunk, keywords)
                search_result_data = {
                    "metadata": metadata_obj,
                    "chunk": highlighted_chunk,
                    "score": result["score"]
                }
                response.append(
                    format_result_item(SearchResult(**search_result_data))
                )

            # Stop when max_chunks is reached
            if len(response) >= max_chunks:
                break

        if len(response) >= max_chunks:
            break
            
    return response

async def search_in_files(
    tool_context: ToolContext,
    directory_path: str,
    search_term: str,
    file_pattern: str = "*.py",
    max_matches: int = 50,
    context_lines_before: int = 2,
    context_lines_after: int = 2,
    regex_timeout: float = 1.0 # Timeout in seconds for regex operations
) -> list[dict]:
    """
    Searches for a regex pattern within the content of files in a specified directory.

    This function lists files in `directory_path` matching `file_pattern` (recursively).
    For each file, it reads the content and searches each line for the `search_term`
    (treated as a regular expression).

    To enhance safety against ReDoS attacks from potentially untrusted `search_term`
    patterns, this function uses the third-party `regex` module, which supports
    timeouts for pattern compilation and matching.

    If matches are found, it returns a list of dictionaries, each containing the
    file path, line number, the matched line, and a contextual snippet consisting
    of the matched line plus a configurable number of lines before and after it.

    Args:
        tool_context (ToolContext): The ADK tool context, used by `smart_list_files`.
        directory_path (str): The path to the directory to search within.
        search_term (str): The regular expression pattern to search for.
        file_pattern (str, optional): A glob pattern to filter files to be searched
            (e.g., "*.py", "data/*.txt"). Defaults to "*.py".
        max_matches (int, optional): The maximum number of individual matches to return
            across all files. Defaults to 50.
        context_lines_before (int, optional): Number of lines to include before the
            matching line in the context snippet. Defaults to 2.
        context_lines_after (int, optional): Number of lines to include after the
            matching line in the context snippet. Defaults to 2.
        regex_timeout (float, optional): Timeout in seconds for regex compilation and
            per-line search operations. Defaults to 1.0.

    Returns:
        list[dict]: A list of match information. Each dictionary contains:
            - 'file_path' (str): Relative path of the file containing the match.
            - 'line_number' (int): The line number (1-indexed) of the match.
            - 'matched_line' (str): The full content of the line where the match occurred.
            - 'context_snippet' (str): A multi-line string showing the matched line
              (prefixed with ">> ") and the specified number of surrounding context lines,
              each prefixed with its line number.
            Returns an empty list if no matches are found, the directory doesn't exist,
            or if the regex pattern is invalid or times out during compilation.
    """
    logger.debug(f"Searching for '{search_term}' in {directory_path}")
    
    if not os.path.exists(directory_path):
        logger.error(f"Directory not found: {directory_path}")
        return []
    
    try:
        # Compile the regex pattern without timeout (timeout is applied per search operation)
        search_pattern = regex.compile(search_term, regex.IGNORECASE)
    except regex.error as e:
        logger.error(f"Invalid regex pattern '{search_term}': {e}")
        return []
    
    # Get files to search
    list_response = await smart_list_files(tool_context, directory_path, file_pattern, True, 200)
    
    matches_found = []
    total_matches = 0
    
    for relative_file_path in list_response.files:
        if total_matches >= max_matches:
            break
            
        file_path = os.path.join(directory_path, relative_file_path)
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
                lines = file.readlines()
            
            for line_idx, line_content in enumerate(lines):
                if total_matches >= max_matches:
                    break
                
                try:
                    # Apply timeout to the search operation using regex module's timeout feature
                    match_result = search_pattern.search(line_content, timeout=regex_timeout)
                    if match_result:
                        actual_line_number = line_idx + 1
                        
                        # Extract context
                        start_context_idx = max(0, line_idx - context_lines_before)
                        end_context_idx = min(len(lines), line_idx + context_lines_after + 1)
                        context_lines = lines[start_context_idx:end_context_idx]
                        
                        context_snippet_lines = []
                        for i, ctx_line in enumerate(context_lines):
                            current_line_num_in_snippet = start_context_idx + i + 1
                            prefix = ">> " if current_line_num_in_snippet == actual_line_number else "   "
                            context_snippet_lines.append(f"{prefix}{current_line_num_in_snippet:4}: {ctx_line.rstrip()}")
                        
                        matches_found.append({
                            "file_path": relative_file_path,
                            "line_number": actual_line_number,
                            "matched_line": line_content.strip(),
                            "context_snippet": "\n".join(context_snippet_lines)
                        })
                        total_matches += 1
                except regex.error as e:
                    # Handle both timeout and other regex errors
                    if "timeout" in str(e).lower():
                        logger.warning(f"Regex search timed out on a line in {file_path} for pattern '{search_term}': {e}")
                    else:
                        logger.warning(f"Regex error during search in {file_path} for pattern '{search_term}': {e}")
                    continue

            
        except Exception as e:
            logger.error(f"Error reading file {file_path}: {str(e)}")
            continue
    
    if not matches_found:
        logger.info(f"No matches found for '{search_term}' in {directory_path} with pattern {file_pattern}")
        return []

    logger.info(f"Found {total_matches} matches for '{search_term}'. Returning up to {max_matches} matches.")
    return matches_found
