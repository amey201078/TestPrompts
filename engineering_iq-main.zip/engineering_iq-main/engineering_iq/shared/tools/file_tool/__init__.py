"""
File Tool Package - Memory-safe file operations with automatic token management.

This package provides a comprehensive set of tools for file operations including:
- Smart file reading with automatic memory management
- Safe file writing with overwrite protection
- File listing with result limits
- Text search across files
- Regex find and replace operations
- File existence validation with property checking

All tools include safety features, memory management, and usage guidance for LLM agents.
"""

# Import all functions for direct access
from .read_functions import (
    smart_read_file,
    smart_list_files, 
    count_tokens,
    FileResponse,
    ListResponse
)

from .search_functions import (
    search_in_files,
    exploratory_search,
)

from .write_functions import (
    write_file_safe,
    regex_replace_in_file,
    WriteResponse
)

from .validation_functions import (
    validate_file_exists,
    validate_multiple_files,
    FileValidationResponse
)

# Import all tool instances
from .read_tools import (
    SmartFileReadTool,
    SmartFileListTool,
    SmartFileSearchTool,
    ExploratorySearchTool,
    smart_file_read_tool,
    smart_file_list_tool,
    smart_file_search_tool,
    exploratory_search_tool,
    read_tools
)

from .write_tools import (
    SmartFileWriteTool,
    RegexReplaceTool,
    smart_file_write_tool,
    regex_replace_tool,
    write_tools
)

from .validation_tools import (
    FileValidationTool,
    MultipleFileValidationTool,
    file_validation_tool,
    multiple_file_validation_tool,
    validation_tools
)

all_read_tools = [
    smart_file_list_tool,
    smart_file_read_tool,
    smart_file_search_tool,
    exploratory_search_tool,
]

# Export all public interfaces
__all__ = [
    # Functions
    'smart_read_file',
    'smart_list_files',
    'search_in_files',
    "exploratory_search",
    'write_file_safe',
    'regex_replace_in_file',
    'validate_file_exists',
    'validate_multiple_files',
    'count_tokens',
    
    # Response models
    'FileResponse',
    'ListResponse', 
    'WriteResponse',
    'FileValidationResponse',
    
    # Tool classes
    'SmartFileReadTool',
    'SmartFileListTool',
    'SmartFileSearchTool',
    "ExploratorySearchTool",
    'SmartFileWriteTool',
    'RegexReplaceTool',
    'FileValidationTool',
    'MultipleFileValidationTool',
    
    # Tool instances
    'smart_file_read_tool',
    'smart_file_list_tool',
    'smart_file_search_tool',
    'smart_file_write_tool',
    'exploratory_search_tool',
    'regex_replace_tool',
    'file_validation_tool',
    'multiple_file_validation_tool',
    
    # Tool collections
    'read_tools',
    'write_tools',
    'validation_tools',
]
