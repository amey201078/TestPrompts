"""Language Server Interface for managing LSP connections and operations."""

import os
import re
from typing import Optional, List, Dict, Any, Union

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings
from engineering_iq.shared.tools.lsp_tool.core_functions import _process_symbol_tuple, HAS_MULTILSPY

logger = get_logger(__name__)
settings = app_settings

if HAS_MULTILSPY:
    try:
        from multilspy.multilspy_config import MultilspyConfig
        from multilspy import SyncLanguageServer
        from multilspy.multilspy_logger import MultilspyLogger
    except ImportError:
        HAS_MULTILSPY = False

class LanguageServerInterface:
    """
    A wrapper around Multilspy to provide direct access to language server
    functionality with on-the-fly configuration, using Loguru for logging.
    """
    # Cache of language server instances, keyed by language_id+project_root
    _instances: Dict[str, 'LanguageServerInterface'] = {}
    
    @classmethod
    def get_instance(cls, language_id: str, project_root: str) -> 'LanguageServerInterface':
        """
        Get a cached instance of LanguageServerInterface or create a new one.
        
        Args:
            language_id: The language identifier (e.g., 'python', 'java', 'rust')
            project_root: The absolute path to the root directory of the project
            
        Returns:
            A LanguageServerInterface instance
        """
        cache_key = f"{language_id}:{project_root}"
        if cache_key not in cls._instances:
            logger.debug(f"Creating new LanguageServerInterface instance for {cache_key}")
            cls._instances[cache_key] = cls(language_id, project_root, _use_cache=True)
        else:
            logger.debug(f"Reusing cached LanguageServerInterface for {cache_key}")
            
        return cls._instances[cache_key]
    
    @classmethod
    def clear_cache(cls, language_id: str = None, project_root: str = None):
        """
        Clear the cache of language server instances. If language_id and/or project_root
        are specified, only matching instances will be cleared.
        
        Args:
            language_id: Optional language ID to filter instances to clear
            project_root: Optional project root to filter instances to clear
        """
        if language_id is None and project_root is None:
            # Clear all instances
            for key, instance in list(cls._instances.items()):
                logger.debug(f"Shutting down cached instance: {key}")
                instance.shutdown()
            cls._instances.clear()
        else:
            # Clear specific instances
            to_remove = []
            for key, instance in cls._instances.items():
                matches = True
                if language_id and not key.startswith(f"{language_id}:"):
                    matches = False
                if project_root and not key.endswith(f":{project_root}"):
                    matches = False
                
                if matches:
                    logger.debug(f"Shutting down cached instance: {key}")
                    instance.shutdown()
                    to_remove.append(key)
            
            for key in to_remove:
                del cls._instances[key]
    
    def __init__(self, language_id: str, project_root: str, _use_cache: bool = False):
        """
        Initializes the LanguageServerInterface.

        Args:
            language_id: The language identifier (e.g., 'python', 'java', 'rust').
                         Make sure the corresponding language server is installed.
            project_root: The absolute path to the root directory of the project.
        """
        if not HAS_MULTILSPY:
            raise ImportError("Multilspy is not installed. Please install it to use this tool.")
            
        logger.info(f"Initializing LanguageServerInterface for language '{language_id}' at '{project_root}'")
        if not os.path.isdir(project_root):
             logger.error(f"Project root directory does not exist: {project_root}")
             raise ValueError(f"Project root directory does not exist: {project_root}")
        
        if not os.path.isabs(project_root):
            logger.warning(f"Project root is not an absolute path: {project_root}, converting to absolute path.")
            project_root = os.path.abspath(project_root)

        self.project_root = project_root
        self.language_id = language_id
        self.multilspy_config: MultilspyConfig = None
        self.lsp_server: SyncLanguageServer = None

        try:
            # 1. Create MultilspyConfig on the fly
            logger.debug("Creating MultilspyConfig...")
            self.multilspy_config = MultilspyConfig(
                code_language=self.language_id,
                trace_lsp_communication=settings.trace_lsp_communication,
                # gitignore_file_content=self._load_gitignore(),
            )
            logger.debug(f"MultilspyConfig created: {self.multilspy_config}")

            # 2. Initialize Multilspy with the config
            # Still pass multilspy_logger; loguru will intercept its messages
            logger.debug("Initializing Multilspy...")
            self._start_language_server()
            logger.debug("Multilspy instance created.")
            logger.success("Language Server initialized successfully.")

        except Exception:
            logger.exception("Failed to initialize LanguageServerInterface")
            self.shutdown() # Call shutdown method for consistency
            raise # Re-raise the exception after cleanup attempt

    def _load_gitignore(self):
        """
        Loads the .gitignore file from the project root if it exists.
        """
        gitignore_path = os.path.join(self.project_root, ".gitignore")
        if os.path.exists(gitignore_path):
            with open(gitignore_path, "r") as f:
                return f.read()
        return None
    
    def _start_language_server(self) -> None:
        """
        Starts the language server.
        """
        logger.debug("Starting language server...")
        self.lsp_server = SyncLanguageServer.create(
            config=self.multilspy_config,
            logger=MultilspyLogger(),
            repository_root_path=self.project_root,
            add_gitignore_content_to_config=True,
        )
        logger.debug("Language server started successfully.")
        self.lsp_server.start()
        if not self.lsp_server.is_running():
            raise RuntimeError(f"Failed to start the language server for {self.multilspy_config}")
    
    
    def get_symbols_overview(self, relative_path: str) -> Dict[str, List[Dict[str, Any]]]:
        """
        Gets an overview of the given file or directory.
        For each analyzed file, we list the top-level symbols in the file (name, kind, line).
        Use this tool to get a high-level understanding of the code symbols.
        Calling this is often a good idea before more targeted reading, searching or editing operations on the code symbols.

        Args:
            relative_path: the relative path to the file or directory to get the overview of
            
        Returns:
            a JSON object mapping relative paths of all contained files to info about top-level symbols in the file
        """
        path_to_symbol_infos = self.lsp_server.request_overview(relative_path)
        result = {}
        for file_path, symbols in path_to_symbol_infos.items():
            result[file_path] = []
            for symbol_tuple in symbols:
                # Process the symbol safely
                symbol_info = {}
                try:
                    symbol_info = _process_symbol_tuple(symbol_tuple)
                except Exception as e:
                    logger.warning(f"Error processing symbol: {e}")
                    continue
                
                result[file_path].append(symbol_info)
        return result

    @classmethod
    def find_symbol_static(cls, symbol_name: str, language_id: str = "python", project_root: str = None):
        """
        Static method to find symbol definitions and references using a cached LSP instance.
        
        Args:
            symbol_name: The name of the symbol to find
            language_id: The language identifier (default: "python")
            project_root: The absolute path to the project root (default: current working directory)
            
        Returns:
            List of locations where the symbol is defined or referenced
        """
        if project_root is None:
            project_root = os.getcwd()
            
        # Get a cached instance
        instance = cls.get_instance(language_id, project_root)
        return instance.find_symbol(symbol_name)
    
    def find_symbol(self, symbol_name: str):
        """
        Finds definitions or references of a symbol.
        
        Args:
            symbol_name: The name of the symbol to find
        
        Returns:
            List of locations where the symbol is defined or referenced
        """
        logger.debug(f"Attempting to find symbol: '{symbol_name}'")
        try:
            result = self.lsp_server.request_workspace_symbol(symbol_name)
            logger.debug(f"Symbol search for '{symbol_name}' completed. Found {len(result) if result else 0} locations.")
            return result
        except Exception:
            logger.exception(f"Error finding symbol '{symbol_name}'")
            return None

    def _lsp_search_wrapper(self, **kwargs):
        """Internal wrapper to handle LSP search calls with proper parameters."""
        # Add dummy column param if multilspy expects it but it's not in kwargs
        # kwargs.setdefault('column', 0)
        return self.lsp_server.search_files_for_pattern(**kwargs)
    
    @classmethod
    def search_files_static(cls, 
                            pattern: Union[re.Pattern, str],
                            context_lines_before: int = 0,
                            context_lines_after: int = 0,
                            paths_include_glob: Optional[str] = None,
                            paths_exclude_glob: Optional[str] = None,
                            language_id: str = "python",
                            project_root: str = None) -> List[Any]:
        """
        Static method to search files for a pattern using a cached LSP instance.
        
        Args:
            pattern: Regular expression pattern to search for
            context_lines_before: Number of lines of context to include before each match
            context_lines_after: Number of lines of context to include after each match
            paths_include_glob: Glob pattern to filter which files to include in the search
            paths_exclude_glob: Glob pattern to filter which files to exclude from the search
            language_id: The language identifier (default: "python")
            project_root: The absolute path to the project root (default: current working directory)
            
        Returns:
            List of search results with context
        """
        if project_root is None:
            project_root = os.getcwd()
            
        # Get a cached instance
        instance = cls.get_instance(language_id, project_root)
        return instance.search_files_for_pattern(
            pattern, 
            context_lines_before, 
            context_lines_after, 
            paths_include_glob, 
            paths_exclude_glob
        )
    
    def search_files_for_pattern(
        self,
        pattern: Union[re.Pattern, str],
        context_lines_before: int = 0,
        context_lines_after: int = 0,
        paths_include_glob: Optional[str] = None,
        paths_exclude_glob: Optional[str] = None,
    ) -> List[Any]:
        """
        Search for a pattern across all files analyzed by the Language Server.

        Args:
            pattern: Regular expression pattern to search for, either as a compiled Pattern or string
            context_lines_before: Number of lines of context to include before each match
            context_lines_after: Number of lines of context to include after each match
            paths_include_glob: Glob pattern to filter which files to include in the search
            paths_exclude_glob: Glob pattern to filter which files to exclude from the search. Takes precedence over paths_include_glob.
        
        Returns:
            List of search results with context
        """
        logger.debug(f"Attempting search: pattern='{pattern}'")
        try:
            # Use wrapper to avoid pylint error with column parameter
            results = self._lsp_search_wrapper(
                pattern=pattern,
                context_lines_before=context_lines_before,
                context_lines_after=context_lines_after,
                paths_include_glob=paths_include_glob,
                paths_exclude_glob=paths_exclude_glob,
            )
            
            logger.debug(f"Pattern search for '{pattern}' completed. Found {len(results) if results else 0} locations.")
            return results
        except Exception:
            logger.exception(f"Error searching for pattern '{pattern}'")
            return []

    def shutdown(self):
        """
        Shuts down the language server connection.
        """
        logger.info("Shutting down Language Server client...")
        try:
            if self.lsp_server:
                self.lsp_server.stop()
                logger.success("Language Server client shut down successfully.")
        except Exception:
                logger.exception("Error during LSP client shutdown")
        finally:
                self.lsp_server = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
         # Loguru automatically handles exception logging if an exception occurred within the 'with' block
        if exc_type:
             logger.error(f"Exiting context due to error: {exc_type.__name__}")
        else:
             logger.debug("Exiting context manager cleanly.")
        self.shutdown()
