"""Tool wrappers for LSP core functions."""

from google.genai import types
from google.adk.tools import FunctionTool, ToolContext
from google.adk.models import LlmRequest
from typing_extensions import override

from .core_functions import get_symbols_overview, find_symbol, lsp_search_files
from engineering_iq.shared.core.models.app_settings import app_settings

class LSPSymbolsOverviewTool(FunctionTool):
    """LSP tool for getting symbol overview of files/directories"""
    
    def __init__(self):
        super().__init__(get_symbols_overview)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'relative_path': types.Schema(
                        type=types.Type.STRING,
                        description="The relative path to get symbols for"
                    ),
                    'language_id': types.Schema(
                        type=types.Type.STRING,
                        description="The language identifier (e.g. 'python', 'javascript', 'java')"
                    ),
                    'project_root': types.Schema(
                        type=types.Type.STRING,
                        description="The absolute path to the project root"
                    )
                },
                required=["relative_path", "language_id", "project_root"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Symbols Overview (Language Server Protocol)
- You have an LSP symbols overview tool that provides a high-level understanding of code symbols.
- Use this to get an overview of classes, functions, and other symbols in files or directories.
- This is often a good first step before more targeted reading, searching, or editing operations.
"""])

class LSPFindSymbolTool(FunctionTool):
    """LSP tool for finding symbol definitions and references"""
    
    def __init__(self):
        super().__init__(find_symbol)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'symbol_name': types.Schema(
                        type=types.Type.STRING,
                        description="The name of the symbol to find"
                    ),
                    'language_id': types.Schema(
                        type=types.Type.STRING,
                        description="The language identifier (e.g. 'python', 'javascript', 'java')"
                    ),
                    'project_root': types.Schema(
                        type=types.Type.STRING,
                        description="The absolute path to the project root"
                    )
                },
                required=["symbol_name", "language_id", "project_root"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Find Symbol (Language Server Protocol)
- You have an LSP symbol finder tool that locates definitions and references of symbols in the codebase.
- Use this to find where symbols (functions, classes, variables) are defined or used.
"""])

class LSPSearchFilesTool(FunctionTool):
    """LSP tool for searching patterns across files with context"""
    
    def __init__(self):
        super().__init__(lsp_search_files)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'pattern': types.Schema(
                        type=types.Type.STRING,
                        description="Text pattern to search for"
                    ),
                    'language_id': types.Schema(
                        type=types.Type.STRING,
                        description="The language identifier (python, javascript, java, etc.)"
                    ),
                    'project_root': types.Schema(
                        type=types.Type.STRING,
                        description="The absolute path to the project root"
                    ),
                    'is_regex': types.Schema(
                        type=types.Type.BOOLEAN,
                        description="Whether the pattern is a regular expression (default: False)"
                    ),
                    'context_lines_before': types.Schema(
                        type=types.Type.INTEGER,
                        description="Number of lines of context before each match (default: 0)"
                    ),
                    'context_lines_after': types.Schema(
                        type=types.Type.INTEGER,
                        description="Number of lines of context after each match (default: 0)"
                    ),
                    'paths_include_glob': types.Schema(
                        type=types.Type.STRING,
                        description="Glob pattern to filter which files to include in search"
                    ),
                    'paths_exclude_glob': types.Schema(
                        type=types.Type.STRING,
                        description="Glob pattern to filter which files to exclude from search"
                    )
                },
                required=["pattern", "language_id", "project_root", "is_regex"]
            ),
        )

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: Search Files (Language Server Protocol)
- You have an LSP search tool for finding patterns across files with context.
- This provides more advanced search capabilities than simple text search, with context lines and language-aware filtering.
- Use this for comprehensive codebase searches when you need to find specific patterns or implementations.
"""])

# Create tool instances
lsp_symbols_overview_tool = LSPSymbolsOverviewTool()
lsp_find_symbol_tool = LSPFindSymbolTool()
lsp_search_files_tool = LSPSearchFilesTool()

if app_settings.enable_lsp_tools:
    all_lsp_tools = [
        lsp_search_files_tool,
        lsp_symbols_overview_tool,
        lsp_find_symbol_tool
    ]
else:
    all_lsp_tools = []
