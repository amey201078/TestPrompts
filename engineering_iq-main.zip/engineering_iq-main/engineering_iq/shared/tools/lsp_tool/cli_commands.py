"""CLI commands for LSP tool functionality."""

import os
import json
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from engineering_iq.shared.tools.lsp_tool.core_functions import get_symbols_overview, find_symbol, lsp_search_files
from engineering_iq.shared.tools.lsp_tool.language_server import LanguageServerInterface

console = Console()
app = typer.Typer(help="Language Server Protocol CLI tool for code analysis")

@app.command("clear-cache")
def clear_cache_command(
    language: Optional[str] = typer.Option(None, "--language", "-l", help="Language ID to filter cache clearing"),
    project_root: Optional[str] = typer.Option(None, "--project-root", "-p", help="Project root to filter cache clearing")
):
    """
    Clear the LSP server instance cache. 
    
    Use this command to free resources or when you want to restart the language server.
    You can optionally specify language ID and/or project root to selectively clear the cache.
    """
    try:
        with console.status("Clearing LSP server cache...", spinner="dots"):
            before_count = len(LanguageServerInterface._instances)
            LanguageServerInterface.clear_cache(language, project_root)
            after_count = len(LanguageServerInterface._instances)
            
        cleared_count = before_count - after_count
        if cleared_count > 0:
            console.print(f"[green]Successfully cleared {cleared_count} cached LSP server instances.[/green]")
        else:
            console.print("[yellow]No matching LSP server instances found in cache.[/yellow]")
            
    except Exception as e:
        console.print(f"[bold red]Error clearing cache:[/bold red] {str(e)}")
        sys.exit(1)

@app.command("symbols")
def symbols_command(
    path: str = typer.Argument(..., help="Path to the file or directory to analyze"),
    language: str = typer.Option("python", "--language", "-l", help="Programming language of the code"),
    project_root: str = typer.Option(os.getcwd(), "--project-root", "-p", help="Root directory of the project"),
    output_format: str = typer.Option("table", "--format", "-f", help="Output format: table or json"),
    no_cache: bool = typer.Option(False, "--no-cache", help="Don't use cached LSP server instance")
):
    """
    Get an overview of symbols (classes, functions, etc.) in a file or directory.
    """
    try:
        with console.status(f"Analyzing symbols in {path}...", spinner="dots"):
            if no_cache:
                # Use a fresh instance
                ls = LanguageServerInterface(language, project_root)
                result = ls.get_symbols_overview(path)
                ls.shutdown()
            else:
                # Use the cached function
                result = get_symbols_overview(path, language, project_root)
        
        if output_format.lower() == "json":
            print(json.dumps(result, indent=2))
            return
        
        # Table output
        for file_path, symbols in result.items():
            if not symbols:
                continue
                
            console.print(f"\n[bold blue]{file_path}[/bold blue]")
            table = Table(show_header=True, header_style="bold")
            table.add_column("Symbol")
            table.add_column("Kind")
            table.add_column("Line")
            table.add_column("Column")
            
            for symbol in symbols:
                table.add_row(
                    str(symbol["name"]),
                    str(symbol["symbol_kind"]),
                    str(symbol["line"]),
                    str(symbol["column"])
                )
            
            console.print(table)
            
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        sys.exit(1)

@app.command("find")
def find_symbol_command(
    symbol: str = typer.Argument(..., help="Name of the symbol to find"),
    language: str = typer.Option("python", "--language", "-l", help="Programming language of the code"),
    project_root: str = typer.Option(os.getcwd(), "--project-root", "-p", help="Root directory of the project"),
    output_format: str = typer.Option("table", "--format", "-f", help="Output format: table or json"),
    no_cache: bool = typer.Option(False, "--no-cache", help="Don't use cached LSP server instance")
):
    """
    Find definitions and references of a symbol in the codebase.
    """

    try:
        # Make sure project_root is absolute
        if not os.path.isabs(project_root):
            project_root = os.path.abspath(project_root)

        with console.status(f"Searching for symbol '{symbol}'...", spinner="dots"):
            if no_cache:
                # Use a fresh instance
                ls = LanguageServerInterface(language, project_root)
                results = ls.find_symbol(symbol)
                ls.shutdown()
            else:
                # Use the cached function
                results = find_symbol(symbol, language, project_root)

        if not results:
            console.print(f"[yellow]No results found for symbol: {symbol}[/yellow]")
            return

        if output_format.lower() == "json":
            json_results = []
            for record in results:
                loc = record["location"]
                json_results.append({
                    "uri": loc["uri"],
                    "range": {
                        "start": {
                            "line": loc["range"]["start"]["line"],
                            "character": loc["range"]["start"]["character"]
                        },
                        "end": {
                            "line": loc["range"]["end"]["line"],
                            "character": loc["range"]["end"]["character"]
                        }
                    }
                })
            console.print(json.dumps(json_results, indent=2))
            return

        # Table output
        table = Table(show_header=True, header_style="bold")
        table.add_column("File")
        table.add_column("Line")
        table.add_column("Character")

        for record in results:
            loc = record["location"]
            
            file_uri = loc["uri"]
            if file_uri.startswith("file://"):
                file_uri = file_uri[7:]

            table.add_row(
                file_uri,
                str(loc["range"]["start"]["line"] + 1),
                str(loc["range"]["start"]["character"])
            )

        console.print(f"[bold green]Found {len(results)} results for '{symbol}':[/bold green]")
        console.print(table)

    except Exception:
        console.print(f"[bold red]An error occurred:[/bold red]")
        console.print_exception(show_locals=True)

@app.command("search")
def search_command(
    pattern: str = typer.Argument(..., help="Pattern to search for"),
    language: str = typer.Option("python", "--language", "-l", help="Programming language of the code"),
    project_root: str = typer.Option(os.getcwd(), "--project-root", "-p", help="Root directory of the project"),
    include_glob: Optional[str] = typer.Option(None, "--include", "-i", help="Glob pattern for files to include"),
    exclude_glob: Optional[str] = typer.Option(None, "--exclude", "-e", help="Glob pattern for files to exclude"),
    before_context: int = typer.Option(2, "--before", "-B", help="Lines of context before match"),
    after_context: int = typer.Option(2, "--after", "-A", help="Lines of context after match"),
    output_format: str = typer.Option("text", "--format", "-f", help="Output format: text or json"),
    no_cache: bool = typer.Option(False, "--no-cache", help="Don't use cached LSP server instance")
):
    """
    Search for a pattern in the codebase.
    """
    try:
        with console.status(f"Searching for pattern '{pattern}'...", spinner="dots"):
            if no_cache:
                # Use a fresh instance
                ls = LanguageServerInterface(language, project_root)
                results = ls.search_files_for_pattern(
                    pattern=pattern,
                    context_lines_before=before_context,
                    context_lines_after=after_context,
                    paths_include_glob=include_glob,
                    paths_exclude_glob=exclude_glob
                )
                ls.shutdown()
            else:
                # Use the cached function
                results = lsp_search_files(
                    pattern=pattern,
                    context_lines_before=before_context,
                    context_lines_after=after_context,
                    paths_include_glob=include_glob,
                    paths_exclude_glob=exclude_glob,
                    language_id=language,
                    project_root=project_root,
                    is_regex=False
                )
        
        if not results:
            console.print(f"[yellow]No results found for pattern: {pattern}[/yellow]")
            return
            
        # Process the already serialized results for display
        simplified_results = []
        
        for result in results:
            try:
                # If result is already a dictionary from our serialization
                if isinstance(result, dict):
                    # Extract file path, with fallbacks
                    file_path = result.get("file_path", None)
                    if file_path is None and "location" in result:
                        uri = result.get("location", {}).get("uri", "")
                        file_path = uri.replace("file://", "") if uri.startswith("file://") else uri
                    if not file_path:
                        # Try to extract from string representation as last resort
                        str_result = str(result)
                        if " in " in str_result:
                            file_path = str_result.split(" in ")[1].split(" at ")[0]
                        else:
                            file_path = "Unknown file"
                    
                    # Extract matches with different possible formats
                    matches = []
                    if "matches" in result:
                        matches = result["matches"]
                    elif "matched_lines" in result:
                        matches = result["matched_lines"]
                    elif hasattr(result, 'matches'):
                        # Direct object access if somehow we got a raw object
                        for match in result.matches:
                            if hasattr(match, 'line') and hasattr(match, 'content'):
                                matches.append({
                                    "line": match.line,
                                    "content": str(match.content)
                                })
                    
                    if not matches:
                        # If no matches found, create a default representation
                        matches = [{"line": "unknown", "content": str(result)}]
                    
                    simplified_results.append({
                        "file": file_path,
                        "matches": matches
                    })
                else:
                    # Fallback for any results that didn't get properly serialized
                    simplified_results.append({
                        "file": "Unknown file",
                        "matches": [{"line": "unknown", "content": str(result)}]
                    })
            except Exception as e:
                simplified_results.append({
                    "file": "Error processing result",
                    "matches": [{"line": "error", "content": f"Error: {str(e)}"}]
                })
        
        if output_format.lower() == "json":
            print(json.dumps(simplified_results, indent=2))
            return
        
        # Text output with highlighting
        console.print(f"[bold green]Found {len(simplified_results)} results for '{pattern}':[/bold green]\n")
        
        for i, result in enumerate(simplified_results):
            console.print(f"[bold blue]{result['file']}[/bold blue]")
            for match in result['matches']:
                line_num = match['line'] if match['line'] != "unknown" else "?"
                console.print(f"  [cyan]Line {line_num}:[/cyan] {match['content']}")
            
            if i < len(simplified_results) - 1:
                console.print()  # Empty line between results
            
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        sys.exit(1)

@app.callback()
def main():
    """
    LSP Tool - Language Server Protocol CLI tool for code analysis.
    
    This tool provides commands to analyze and search through code
    using the Language Server Protocol functionality.
    """
    pass  # This function will be called before any command

if __name__ == "__main__":
    app()
