"""
LSP Tool Package - Language Server Protocol integration for code analysis.

This package provides comprehensive LSP functionality including:
- Symbol analysis and search
- Code search across files with context
- Language server interface management
- CLI commands for interactive use
- Caching for performance optimization

All functions include proper error handling and serialization for AI agent use.
"""

# Import core functions
from .core_functions import (
    get_symbols_overview,
    find_symbol,
    lsp_search_files,
    clear_lsp_cache,
    safe_serialize,
    _process_symbol_tuple,
    HAS_MULTILSPY,
    UNKNOWN_SYMBOL
)

# Import language server interface
from .language_server import LanguageServerInterface

# Import CLI app for backward compatibility
from .cli_commands import app

# Import tool instances
from .lsp_tools import (
    LSPSymbolsOverviewTool,
    LSPFindSymbolTool,
    LSPSearchFilesTool,
    lsp_symbols_overview_tool,
    lsp_find_symbol_tool,
    lsp_search_files_tool,
    all_lsp_tools
)

# Export all public interfaces
__all__ = [
    # Core functions
    'get_symbols_overview',
    'find_symbol', 
    'lsp_search_files',
    'clear_lsp_cache',
    'safe_serialize',
    '_process_symbol_tuple',
    
    # Constants
    'HAS_MULTILSPY',
    'UNKNOWN_SYMBOL',
    
    # Classes
    'LanguageServerInterface',
    
    # Tool classes
    'LSPSymbolsOverviewTool',
    'LSPFindSymbolTool', 
    'LSPSearchFilesTool',
    
    # Tool instances
    'lsp_symbols_overview_tool',
    'lsp_find_symbol_tool',
    'lsp_search_files_tool',
    
    # CLI
    'app',
    
    # Tool collection (backward compatibility)
    'all_lsp_tools'
]
