"""Core LSP functions and utilities for language server operations."""

import os
import re
import sys
import inspect
from typing import Optional, List, Dict, Any, Union

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings

HAS_MULTILSPY = True
logger = get_logger(__name__)

try:
    from multilspy.multilspy_types import SymbolKind
    # Use Unknown as a fallback for symbol kinds
    UNKNOWN_SYMBOL = getattr(SymbolKind, "File", 1)  # Use File or 1 as a safe default
except ImportError as e:
    logger.error("Multilspy is not installed. Please install it to use this tool.")
    HAS_MULTILSPY = False
    UNKNOWN_SYMBOL = 1

settings = app_settings

def safe_serialize(obj: Any) -> Any:
    """
    Safely serialize any object by handling complex types that aren't JSON serializable.
    
    Args:
        obj: The object to serialize
        
    Returns:
        A JSON serializable representation of the object
    """
    # Handle None
    if obj is None:
        return None
        
    # Handle primitive types that are already serializable
    if isinstance(obj, (str, int, float, bool)):
        return obj
        
    # Handle lists and tuples
    if isinstance(obj, (list, tuple)):
        return [safe_serialize(item) for item in obj]
        
    # Handle dictionaries
    if isinstance(obj, dict):
        return {str(k): safe_serialize(v) for k, v in obj.items()}
        
    # Check if the object has a to_display_string method or property
    if hasattr(obj, 'to_display_string'):
        # Check if it's a method that needs to be called
        if inspect.ismethod(obj.to_display_string) or inspect.isfunction(obj.to_display_string):
            try:
                return obj.to_display_string()
            except Exception as e:
                logger.warning(f"Error calling to_display_string method: {e}")
                return str(obj)
        else:
            # It's a property/attribute
            return str(obj.to_display_string)
            
    # Check if object has a to_dict or as_dict method
    for method_name in ('to_dict', 'as_dict'):
        if hasattr(obj, method_name):
            method = getattr(obj, method_name)
            if callable(method):
                try:
                    return safe_serialize(method())
                except Exception as e:
                    logger.warning(f"Error calling {method_name} method: {e}")
    
    # For all other objects, try to convert to a dictionary
    if hasattr(obj, '__dict__'):
        try:
            return safe_serialize(obj.__dict__)
        except Exception as e:
            logger.warning(f"Error serializing __dict__: {e}")
    
    # Last resort: convert to string
    try:
        return str(obj)
    except Exception as e:
        logger.warning(f"Error converting object to string: {e}")
        return f"<Unserializable object of type {type(obj).__name__}>"

def _process_symbol_tuple(symbol_tuple: tuple) -> Dict[str, Union[int, str, Any]]:
    """
    Process a symbol tuple safely and convert it to a dictionary.
    Handles tuples of various lengths by providing defaults.
    
    Args:
        symbol_tuple: A tuple containing symbol information
        
    Returns:
        Dictionary with standardized symbol information
    """
    # Default values
    name = "Unknown"
    symbol_type = UNKNOWN_SYMBOL
    line = 0
    column = 0
    
    # Extract values safely
    try:
        if len(symbol_tuple) > 0:
            name = symbol_tuple[0]
        if len(symbol_tuple) > 1:
            symbol_type = symbol_tuple[1]
        if len(symbol_tuple) > 2:
            line = symbol_tuple[2]
        if len(symbol_tuple) > 3:
            column = symbol_tuple[3]
    except Exception as e:
        logger.warning(f"Error extracting data from symbol tuple: {e}")
        
    # Create and return the info dictionary
    return {"name": name, "symbol_kind": symbol_type, "line": line, "column": column}

def get_symbols_overview(relative_path: str, language_id: str, project_root: str) -> Union[str, Dict[str, List[Dict[str, Any]]]]:
    """
    Get an overview of symbols (classes, functions, etc.) in a file or directory.
    
    Args:
        relative_path: The relative path to get symbols for
        language_id: The language identifier
        project_root: The absolute path to the project root (default: current working directory)
        
    Returns:
        Dictionary mapping file paths to symbol information
    """
    if not HAS_MULTILSPY:
        return "Multilspy is not installed. Please install it to use this tool."

    if project_root is None:
        return "Project root is not specified."
        
    # Get a cached instance
    try:
        from engineering_iq.shared.tools.lsp_tool.language_server import LanguageServerInterface
        instance = LanguageServerInterface.get_instance(language_id, project_root)
        results = instance.get_symbols_overview(relative_path)
        # Safely serialize the results
        return safe_serialize(results)
    except Exception as e:
        logger.error(f"Error getting symbols overview: {e}")
        return f"Error: {str(e)}"

def find_symbol(symbol_name: str, language_id: str, project_root: str) -> Union[List[str]]:
    """
    Find definitions and references of a symbol in the codebase.
    
    Args:
        symbol_name: The name of the symbol to find
        language_id: The language identifier (default: "python")
        project_root: The absolute path to the project root (default: current working directory)
        
    Returns:
        List of locations where the symbol is defined or referenced
    """
    if not HAS_MULTILSPY:
        return "Multilspy is not installed. Please install it to use this tool."

    if not project_root:
        return "Project root is not specified."
    
    # Make project_root absolute if it's not already
    if not os.path.isabs(project_root):
        project_root = os.path.abspath(project_root)

    try:
        from .language_server import LanguageServerInterface
        instance = LanguageServerInterface.get_instance(language_id, project_root)
        results = instance.find_symbol(symbol_name)
        # Use safe_serialize to handle complex result types
        serialized_results = []
        for result in results:
            try:
                serialized_results.append(safe_serialize(result))
            except Exception as e:
                logger.error(f"Error serializing symbol result: {e}")
                serialized_results.append(str(result))
        return serialized_results
    except Exception as e:
        logger.error(f"Error finding symbol: {e}")
        return f"Error: {str(e)}"

def lsp_search_files(
    pattern: str,
    language_id: str,
    project_root: str,
    is_regex: bool,
    context_lines_before: int = 0,
    context_lines_after: int = 0,
    paths_include_glob: Optional[str] = None,
    paths_exclude_glob: Optional[str] = None,
) -> Union[str, List[str]]:
    """
    Search for a pattern across files in a codebase.
    
    Args:
        pattern: Text to search for        
        project_root: The absolute path to the project root (default: current working directory)
        language_id: The language identifier (default: "")
            CSHARP = "csharp"
            PYTHON = "python"
            RUST = "rust"
            JAVA = "java"
            KOTLIN = "kotlin"
            TYPESCRIPT = "typescript"
            JAVASCRIPT = "javascript"
            GO = "go"
            RUBY = "ruby"
            DART = "dart"
            CPP = "cpp"
        is_regex: Whether the pattern is a regular expression
        context_lines_before: Number of lines of context to include before each match
        context_lines_after: Number of lines of context to include after each match
        paths_include_glob: Glob pattern to filter which files to include in the search
        paths_exclude_glob: Glob pattern to filter which files to exclude from the search
        
    Returns:
        List of search results with context
        Represents a collection of consecutive lines found through some criterion in a text file or a string. 
        May include lines before, after, and matched.
        [
            {
                "matched_lines": [
                    {
                        "line": 1,
                        "content": "Matched line content"
                    },
                    {
                        "line": 2,
                        "content": "Another matched line content"
                    }
                ],
                "lines_before_matched": [
                    {
                        "line": 0,
                        "content": "Line before match"
                    }
                ],
                "lines_after_matched": [
                    {
                        "line": 3,
                        "content": "Line after match"
                    }
                ],
                "file_path": "path/to/file.py"
            }
        ]
        or returns an error message if the search fails.
    """
    if not HAS_MULTILSPY:
        return "Multilspy is not installed. Please install it to use this tool."

    if not project_root:
        return "Project root is not specified."

    if is_regex:
        pattern = re.compile(pattern)

    try:
        from .language_server import LanguageServerInterface
        instance = LanguageServerInterface.get_instance(language_id, project_root)
        results = instance.search_files_for_pattern(
            pattern,
            context_lines_before,
            context_lines_after,
            paths_include_glob, 
            paths_exclude_glob
        )
        logger.info("Converting search results to strings...")
        # Use safe_serialize to handle complex result types
        serialized_results = []
        for result in results:
            try:
                serialized_results.append(safe_serialize(result))
            except Exception as e:
                logger.error(f"Error serializing search result: {e}")
                serialized_results.append(str(result))
        return serialized_results
    except Exception as e:
        logger.error(f"Error searching files: {e}")
        return f"Error: {str(e)}"

def clear_lsp_cache(language_id: str = None, project_root: str = ""):
    """
    Clear the cache of language server instances.
    
    Args:
        language_id: Optional language ID to filter instances to clear
        project_root: Optional project root to filter instances to clear
    """
    if project_root and language_id:
        logger.info(f"Clearing cache for language '{language_id}' at '{project_root}'")
        from .language_server import LanguageServerInterface
        LanguageServerInterface.clear_cache(language_id, project_root)
    else:
        logger.error("Project root and language ID must be specified to clear cache.")
