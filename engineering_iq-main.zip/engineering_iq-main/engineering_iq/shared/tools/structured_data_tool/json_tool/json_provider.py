from typing import Any, Dict, Union, Optional, List
import engineering_iq.shared.tools.structured_data_tool.json_tool.read_functions as read_functions
import engineering_iq.shared.tools.structured_data_tool.json_tool.write_functions as write_functions
from engineering_iq.shared.tools.structured_data_tool.structured_data_provider import StructuredDataProvider

class JsonProvider(StructuredDataProvider):
    """JSON data provider."""
    
    def fetch_structured_data(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None,
             limit: Optional[int] = None, offset: int = 0, summary_only: bool = False) -> Union[str, Dict[str, Any]]:
        """Read JSON data from file with batching support.
        
        Args:
            file_path: Path to the JSON file
            encoding: File encoding (default: utf-8)
            container: Optional JSON path or key to focus on (currently not used, for future extension)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)
            summary_only: If True, return only summary info without actual data
        """
        if summary_only:
            return read_functions.get_json_structure(file_path, encoding)
        return read_functions.read_json(file_path, encoding, limit=limit, offset=offset)
    
    def write_structured_data(self, file_path: str, data: Any, encoding: str = "utf-8", container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Write data to JSON file.
        
        Args:
            file_path: Path to the JSON file
            data: Data to write
            encoding: File encoding (default: utf-8)
            container: Optional JSON path or key to focus on (currently not used, for future extension)
        """
        return write_functions.write_json(file_path, data, encoding)
    
    def query_structured_data(self, file_path: str, query_expression: str, encoding: str = "utf-8", container: Optional[str] = None,
              limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
        """Query JSON data using JSONPath with batching support.
        
        Args:
            file_path: Path to the JSON file
            query_expression: JSONPath query expression
            encoding: File encoding (default: utf-8)
            container: Optional JSON path or key to focus query on (currently not used, for future extension)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)
        """
        return read_functions.query_json_path(file_path, query_expression, encoding, limit=limit, offset=offset)    

    def get_structure(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Get JSON structure.
        
        Args:
            file_path: Path to the JSON file
            encoding: File encoding (default: utf-8)
            container: Optional JSON path or key to focus on (currently not used, for future extension)
        """
        return read_functions.get_json_structure(file_path, encoding)

    def get_stats_from_structured(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Get JSON statistics.
        
        Args:
            file_path: Path to the JSON file
            encoding: File encoding (default: utf-8)
            container: Optional JSON path or key to focus on (currently not used, for future extension)
        """
        return read_functions.get_json_stats(file_path, encoding=encoding)

    def list_containers(self, file_path: str, encoding: str = "utf-8") -> Union[str, List[str]]:
        """List all available containers in the JSON data source.
        
        Args:
            file_path: Path to the JSON file
            encoding: File encoding (default: utf-8)
            
        Returns:
            List of top-level keys in JSON or error message (JSON files don't have traditional containers)
        """
        return read_functions.list_json_keys(file_path, encoding)

    def get_container_column(self, file_path: str, column_name: str, encoding: str = "utf-8", 
                            container: Optional[str] = None, limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
        """Retrieve a specific field from JSON data.
        
        Args:
            file_path: Path to the JSON file
            column_name: Name of the field/key to retrieve
            encoding: File encoding (default: utf-8)
            container: Optional JSON path context (currently not used)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)

        Returns:
            Data from the specified field with statistics and sample values
        """
        return read_functions.get_json_field(file_path, column_name, encoding, limit=limit, offset=offset)

    def compare_structured_data(self, file_path1: str, file_path2: str, encoding: str = "utf-8",
                    container1: Optional[str] = None, container2: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Compare two JSON data sources and identify differences.
        
        Args:
            file_path1: Path to first JSON file
            file_path2: Path to second JSON file
            encoding: File encoding (default: utf-8)
            container1: Container in first file (currently not used)
            container2: Container in second file (currently not used)
            
        Returns:
            Comparison report showing differences in structure, content, statistics
        """
        return read_functions.compare_json_data(file_path1, file_path2, encoding)

    def detect_relationships(self, file_path: str, encoding: str = "utf-8", 
                           container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Detect relationships and correlations in JSON data.
        
        Args:
            file_path: Path to the JSON file
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (currently not used)
            
        Returns:
            Analysis of relationships and patterns in the JSON structure
        """
        return read_functions.detect_json_relationships(file_path, encoding)
