"""JSON reading and analysis functions simplified with jmespath and pandas."""

import os
import json
from typing import Dict, Union, Any, List, Optional

import jmespath
import pandas as pd

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings

settings = app_settings
logger = get_logger(__name__)

def read_json(file_path: str, encoding: str = "utf-8", limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
    """
    Read a JSON file and return its content as a dictionary with batching support.

    Args:
        file_path: Path to the JSON file
        encoding: File encoding (default: "utf-8")
        limit: Maximum number of records to return (None for all)
        offset: Number of records to skip (default: 0)

    Returns:
        Dictionary with JSON content or error message if the file doesn't exist or can't be read
    """
    logger.debug(f"Reading JSON file: {file_path}, encoding: {encoding}, limit: {limit}, offset: {offset}")
    if not os.path.exists(file_path):
        logger.error(f"JSON file not found: {file_path}")
        return f"JSON file not found: {file_path}"
    
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            data = json.load(f)
        
        original_data = data
        total_count = None
        
        # Apply batching if data is a list
        if isinstance(data, list):
            total_count = len(data)
            if offset > 0:
                data = data[offset:]
            if limit is not None:
                data = data[:limit]
        
        result = {
            'file_path': file_path,
            'data': data,
            'type': type(original_data).__name__,
            'encoding': encoding,
            'total_count': total_count,
            'returned_count': len(data) if isinstance(data, list) else 1,
            'offset': offset,
            'limit': limit
        }
        
        logger.debug(f"Successfully read JSON file: {file_path}")
        return result
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error in {file_path}: {str(e)}")
        return f"JSON parsing error in {file_path}: {str(e)}"
    except (FileNotFoundError, PermissionError, OSError) as e:
        logger.error(f"Error reading JSON file {file_path}: {str(e)}")
        return f"Error reading JSON file {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error reading JSON file {file_path}: {str(e)}")
        return f"Unexpected error reading JSON file {file_path}: {str(e)}"

def query_json_path(file_path: str, query_expression: str, encoding: str = "utf-8", 
                    limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
    """
    Query a JSON file using JMESPath expressions with batching support.

    Args:
        file_path: Path to the JSON file
        query_expression: JMESPath expression to query (e.g., "store.book[*].title")
        encoding: File encoding (default: "utf-8")
        limit: Maximum number of records to return (None for all)
        offset: Number of records to skip (default: 0)

    Returns:
        Dictionary with query results or error message
    """
    logger.debug(f"Querying JSON file: {file_path}, jmespath: {query_expression}")
    if not os.path.exists(file_path):
        logger.error(f"JSON file not found: {file_path}")
        return f"JSON file not found: {file_path}"
    
    if not query_expression:
        logger.error("JMESPath expression is required")
        return "JMESPath expression is required"
    
    try:
        # Read JSON data
        with open(file_path, 'r', encoding=encoding) as f:
            data = json.load(f)
        
        # Use jmespath for querying
        results = jmespath.search(query_expression, data)
        
        # Convert single result to list for consistent handling
        if not isinstance(results, list):
            results = [results] if results is not None else []
        
        total_results = len(results) if isinstance(results, list) else 1
        
        # Apply batching for list results
        if isinstance(results, list):
            if offset > 0:
                results = results[offset:]
            if limit is not None:
                results = results[:limit]
        
        result = {
            'file_path': file_path,
            'query': query_expression,
            'results': results,
            'total_results': total_results,
            'returned_count': len(results) if isinstance(results, list) else 1,
            'offset': offset,
            'limit': limit,
            'query_engine': 'jmespath'
        }
        
        logger.debug(f"JMESPath query returned {len(results) if isinstance(results, list) else 1} results")
        return result
    except Exception as e:
        logger.error(f"Error querying JSON file {file_path} with JMESPath {query_expression}: {str(e)}")
        return f"Error querying JSON file {file_path} with JMESPath {query_expression}: {str(e)}"

def list_json_keys(file_path: str, encoding: str = "utf-8") -> Union[str, List[str]]:
    """
    List all top-level keys in a JSON file.

    Args:
        file_path: Path to the JSON file
        encoding: File encoding (default: "utf-8")

    Returns:
        List of top-level keys or error message
    """
    logger.debug(f"Listing keys in JSON file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"JSON file not found: {file_path}")
        return f"JSON file not found: {file_path}"
    
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            data = json.load(f)
        
        if isinstance(data, dict):
            keys = list(data.keys())
            logger.debug(f"Found {len(keys)} top-level keys in {file_path}")
            return keys
        elif isinstance(data, list):
            return ["[array_items]"]  # Indicate it's an array
        else:
            return [f"[{type(data).__name__}_value]"]  # Indicate it's a single value
            
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error in {file_path}: {str(e)}")
        return f"JSON parsing error in {file_path}: {str(e)}"
    except (FileNotFoundError, PermissionError, OSError) as e:
        logger.error(f"Error reading JSON file {file_path}: {str(e)}")
        return f"Error reading JSON file {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error reading JSON file {file_path}: {str(e)}")
        return f"Unexpected error reading JSON file {file_path}: {str(e)}"

def get_json_field(file_path: str, field_name: str, encoding: str = "utf-8", 
                   limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
    """
    Retrieve a specific field from JSON data with statistics and sample values.

    Args:
        file_path: Path to the JSON file
        field_name: Name of the field to retrieve
        encoding: File encoding (default: "utf-8")
        limit: Maximum number of records to return (None for all)
        offset: Number of records to skip (default: 0)

    Returns:
        Dictionary with field data, statistics, and sample values
    """
    logger.debug(f"Getting field {field_name} from JSON file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"JSON file not found: {file_path}")
        return f"JSON file not found: {file_path}"
    
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            data = json.load(f)
        
        # Use JMESPath to extract field values
        # Try different JMESPath patterns to find the field
        patterns = [
            f"[*].{field_name}",  # Array of objects
            f"*.{field_name}",    # Object values
            f"{field_name}",      # Direct field
        ]
        
        extracted_values = []
        for pattern in patterns:
            try:
                results = jmespath.search(pattern, data)
                if results:
                    if isinstance(results, list):
                        extracted_values.extend([{'value': v, 'path': pattern} for v in results if v is not None])
                    else:
                        extracted_values.append({'value': results, 'path': pattern})
                    break
            except:
                continue
        

        
        if not extracted_values:
            return f"Field '{field_name}' not found in JSON file"
        
        total_count = len(extracted_values)
        
        # Apply batching
        if offset > 0:
            extracted_values = extracted_values[offset:]
        if limit is not None:
            extracted_values = extracted_values[:limit]
        
        # Extract just the values for statistical analysis
        values_only = [item['value'] for item in extracted_values]
        
        # Calculate statistics using pandas
        if values_only:
            try:
                series = pd.Series(values_only)
                stats = {
                    'total_count': total_count,
                    'returned_count': len(extracted_values),
                    'unique_count': series.nunique(),
                    'null_count': series.isnull().sum(),
                    'non_null_count': series.count(),
                    'offset': offset,
                    'limit': limit
                }
                
                # Add numeric statistics if applicable
                numeric_series = pd.to_numeric(series, errors='coerce')
                if not numeric_series.isnull().all():
                    stats.update({
                        'mean': numeric_series.mean(),
                        'median': numeric_series.median(),
                        'std': numeric_series.std(),
                        'min': numeric_series.min(),
                        'max': numeric_series.max()
                    })
                
                # Type distribution
                type_counts = series.apply(lambda x: type(x).__name__).value_counts().to_dict()
                stats['type_distribution'] = type_counts
                
            except Exception as e:
                logger.error(f"Error calculating pandas statistics: {e}")
                raise
        else:
            # Empty values case
            stats = {
                'total_count': total_count,
                'returned_count': len(extracted_values),
                'unique_count': 0,
                'null_count': 0,
                'non_null_count': 0,
                'offset': offset,
                'limit': limit,
                'type_distribution': {}
            }
        
        result = {
            'file_path': file_path,
            'field_name': field_name,
            'values': extracted_values,
            'statistics': stats,
            'sample_values': values_only[:10]  # First 10 values as samples
        }
        
        logger.debug(f"Retrieved field {field_name} with {len(extracted_values)} values")
        return result
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error in {file_path}: {str(e)}")
        return f"JSON parsing error in {file_path}: {str(e)}"
    except (FileNotFoundError, PermissionError, OSError) as e:
        logger.error(f"Error reading JSON file {file_path}: {str(e)}")
        return f"Error reading JSON file {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error reading JSON file {file_path}: {str(e)}")
        return f"Unexpected error reading JSON file {file_path}: {str(e)}"

def compare_json_data(file_path1: str, file_path2: str, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Compare two JSON files and identify differences.

    Args:
        file_path1: Path to the first JSON file
        file_path2: Path to the second JSON file
        encoding: File encoding (default: "utf-8")

    Returns:
        Dictionary with comparison results or error message
    """
    logger.debug(f"Comparing JSON files: {file_path1} vs {file_path2}")
    
    # Check if both files exist
    if not os.path.exists(file_path1):
        logger.error(f"First JSON file not found: {file_path1}")
        return f"First JSON file not found: {file_path1}"
    
    if not os.path.exists(file_path2):
        logger.error(f"Second JSON file not found: {file_path2}")
        return f"Second JSON file not found: {file_path2}"
    
    try:
        # Read both JSON files
        with open(file_path1, 'r', encoding=encoding) as f:
            data1 = json.load(f)
        
        with open(file_path2, 'r', encoding=encoding) as f:
            data2 = json.load(f)
        
        # Compare the data
        differences = _find_differences(data1, data2, "")
        
        # Get structural info
        structure_comparison = {
            'file1_type': type(data1).__name__,
            'file2_type': type(data2).__name__,
            'types_match': type(data1) == type(data2)
        }
        
        if isinstance(data1, dict) and isinstance(data2, dict):
            structure_comparison.update({
                'file1_keys': list(data1.keys()),
                'file2_keys': list(data2.keys()),
                'common_keys': list(set(data1.keys()) & set(data2.keys())),
                'unique_to_file1': list(set(data1.keys()) - set(data2.keys())),
                'unique_to_file2': list(set(data2.keys()) - set(data1.keys()))
            })
        elif isinstance(data1, list) and isinstance(data2, list):
            structure_comparison.update({
                'file1_length': len(data1),
                'file2_length': len(data2),
                'lengths_match': len(data1) == len(data2)
            })
        
        result = {
            'file1_path': file_path1,
            'file2_path': file_path2,
            'are_equal': len(differences) == 0,
            'differences': differences,
            'difference_count': len(differences),
            'structure_comparison': structure_comparison,
            'summary': {
                'structural_match': structure_comparison['types_match'],
                'content_differences': len(differences)
            }
        }
        
        logger.debug(f"Found {len(differences)} differences between JSON files")
        return result
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error: {str(e)}")
        return f"JSON parsing error: {str(e)}"
    except (FileNotFoundError, PermissionError, OSError) as e:
        logger.error(f"Error comparing JSON files: {str(e)}")
        return f"Error comparing JSON files: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error comparing JSON files: {str(e)}")
        return f"Unexpected error comparing JSON files: {str(e)}"

def detect_json_relationships(file_path: str, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Detect relationships and patterns in JSON data structure.

    Args:
        file_path: Path to the JSON file
        encoding: File encoding (default: "utf-8")

    Returns:
        Analysis of relationships and patterns in the JSON structure
    """
    logger.debug(f"Detecting relationships in JSON file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"JSON file not found: {file_path}")
        return f"JSON file not found: {file_path}"
    
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            data = json.load(f)
        
        relationships = {
            'file_path': file_path,
            'root_type': type(data).__name__,
            'field_analysis': {},
            'array_patterns': [],
            'nesting_patterns': {},
            'potential_relationships': []
        }
        
        # Analyze field relationships
        if isinstance(data, dict):
            relationships['field_analysis'] = _analyze_dict_relationships(data)
        elif isinstance(data, list):
            relationships['array_patterns'] = _analyze_array_patterns(data)
        
        # Analyze nesting patterns
        relationships['nesting_patterns'] = _analyze_nesting_patterns(data)
        
        # Look for potential foreign key relationships
        relationships['potential_relationships'] = _detect_potential_relationships(data)
        
        logger.debug("JSON relationship detection completed")
        return relationships
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error in {file_path}: {str(e)}")
        return f"JSON parsing error in {file_path}: {str(e)}"
    except (FileNotFoundError, PermissionError, OSError) as e:
        logger.error(f"Error reading JSON file {file_path}: {str(e)}")
        return f"Error reading JSON file {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error detecting relationships in JSON file {file_path}: {str(e)}")
        return f"Unexpected error detecting relationships in JSON file {file_path}: {str(e)}"

def get_json_structure(file_path: str, max_depth: int = 10, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """Get the structure/schema of a JSON file."""
    logger.debug(f"Getting structure for JSON file: {file_path}, max_depth: {max_depth}")
    if not os.path.exists(file_path):
        logger.error(f"JSON file not found: {file_path}")
        return f"JSON file not found: {file_path}"
    
    # Ensure max_depth is an integer to avoid type comparison errors
    try:
        max_depth = int(max_depth)
    except (ValueError, TypeError):
        max_depth = 10  # Default fallback
    
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            data = json.load(f)
        
        def analyze_structure(obj, path="root", depth=0):
            """Recursively analyze JSON structure."""
            if depth > max_depth:
                return {"type": "max_depth_reached"}
                
            if isinstance(obj, dict):
                return {
                    "type": "object",
                    "properties": {key: analyze_structure(value, f"{path}.{key}", depth+1) for key, value in obj.items()},
                    "property_count": len(obj)
                }
            elif isinstance(obj, list):
                if not obj:
                    return {"type": "array", "items": "empty", "length": 0}
                
                # Analyze first few items to determine array item structure
                sample_items = obj[:3] if len(obj) > 3 else obj
                item_structures = [analyze_structure(item, f"{path}[{i}]", depth+1) for i, item in enumerate(sample_items)]
                
                # Check if all items have the same structure
                if all(item["type"] == item_structures[0]["type"] for item in item_structures):
                    return {
                        "type": "array",
                        "items": item_structures[0],
                        "length": len(obj),
                        "uniform": True
                    }
                else:
                    return {
                        "type": "array",
                        "items": item_structures,
                        "length": len(obj),
                        "uniform": False
                    }
            else:
                return {
                    "type": type(obj).__name__,
                    "value_preview": str(obj)[:50] + "..." if len(str(obj)) > 50 else str(obj)
                }
        
        structure = analyze_structure(data)
        
        result = {
            'file_path': file_path,
            'root_type': type(data).__name__,
            'structure': structure,
            'encoding': encoding
        }
        
        logger.debug(f"Successfully analyzed JSON structure: {file_path}")
        return result
    except (ValueError, TypeError, AttributeError) as e:
        logger.error(f"Error analyzing JSON structure for {file_path}: {str(e)}")
        return f"Error analyzing JSON structure for {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error analyzing JSON structure for {file_path}: {str(e)}")
        return f"Unexpected error analyzing JSON structure for {file_path}: {str(e)}"

def get_json_stats(file_path: str, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """Get statistics about a JSON file using pandas if available."""
    logger.debug(f"Getting stats for JSON file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"JSON file not found: {file_path}")
        return f"JSON file not found: {file_path}"
    
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            data = json.load(f)
        
        # Extract all values for statistical analysis
        all_values = []
        _extract_all_values(data, all_values)
        
        if all_values:
            try:
                # Create pandas series for analysis
                series = pd.Series(all_values)
                
                stats = {
                    'total_values': len(all_values),
                    'unique_values': series.nunique(),
                    'null_count': series.isnull().sum(),
                    'non_null_count': series.count(),
                    'type_distribution': series.apply(lambda x: type(x).__name__).value_counts().to_dict()
                }
                
                # Add numeric statistics if applicable
                numeric_series = pd.to_numeric(series, errors='coerce')
                numeric_count = numeric_series.count()
                if numeric_count > 0:
                    stats.update({
                        'numeric_count': numeric_count,
                        'mean': numeric_series.mean(),
                        'median': numeric_series.median(),
                        'std': numeric_series.std(),
                        'min': numeric_series.min(),
                        'max': numeric_series.max(),
                        'quantiles': {
                            '25%': numeric_series.quantile(0.25),
                            '50%': numeric_series.quantile(0.50),
                            '75%': numeric_series.quantile(0.75)
                        }
                    })
                
            except Exception as e:
                logger.error(f"Error calculating pandas statistics: {e}")
                raise
        else:
            # Empty values case
            stats = {
                'total_values': 0,
                'unique_values': 0,
                'null_count': 0,
                'non_null_count': 0,
                'type_distribution': {}
            }
        
        # Get file size
        size_bytes = os.path.getsize(file_path)
        
        result = {
            'file_path': file_path,
            'size_bytes': size_bytes,
            'root_type': type(data).__name__,
            'statistics': stats,
            'encoding': encoding
        }
        
        logger.debug(f"JSON stats calculated for {len(all_values)} values")
        return result
    except (ValueError, TypeError, AttributeError) as e:
        logger.error(f"Error getting stats for JSON file {file_path}: {str(e)}")
        return f"Error getting stats for JSON file {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error getting stats for JSON file {file_path}: {str(e)}")
        return f"Unexpected error getting stats for JSON file {file_path}: {str(e)}"

# Helper functions



def _extract_all_values(obj: Any, values_list: List) -> None:
    """Recursively extract all values from JSON data."""
    if isinstance(obj, dict):
        for value in obj.values():
            _extract_all_values(value, values_list)
    elif isinstance(obj, list):
        for item in obj:
            _extract_all_values(item, values_list)
    else:
        values_list.append(obj)





def _find_differences(obj1: Any, obj2: Any, path: str) -> List[Dict[str, Any]]:
    """Find differences between two objects recursively."""
    differences = []
    
    if type(obj1) != type(obj2):
        differences.append({
            'path': path or 'root',
            'type': 'type_mismatch',
            'value1': type(obj1).__name__,
            'value2': type(obj2).__name__
        })
        return differences
    
    if isinstance(obj1, dict):
        all_keys = set(obj1.keys()) | set(obj2.keys())
        
        for key in all_keys:
            current_path = f"{path}.{key}" if path else key
            
            if key not in obj1:
                differences.append({
                    'path': current_path,
                    'type': 'missing_in_first',
                    'value2': obj2[key]
                })
            elif key not in obj2:
                differences.append({
                    'path': current_path,
                    'type': 'missing_in_second',
                    'value1': obj1[key]
                })
            else:
                differences.extend(_find_differences(obj1[key], obj2[key], current_path))
    
    elif isinstance(obj1, list):
        max_len = max(len(obj1), len(obj2))
        
        if len(obj1) != len(obj2):
            differences.append({
                'path': path or 'root',
                'type': 'length_mismatch',
                'value1': len(obj1),
                'value2': len(obj2)
            })
        
        for i in range(max_len):
            current_path = f"{path}[{i}]" if path else f"[{i}]"
            
            if i >= len(obj1):
                differences.append({
                    'path': current_path,
                    'type': 'missing_in_first',
                    'value2': obj2[i]
                })
            elif i >= len(obj2):
                differences.append({
                    'path': current_path,
                    'type': 'missing_in_second',
                    'value1': obj1[i]
                })
            else:
                differences.extend(_find_differences(obj1[i], obj2[i], current_path))
    
    else:
        if obj1 != obj2:
            differences.append({
                'path': path or 'root',
                'type': 'value_mismatch',
                'value1': obj1,
                'value2': obj2
            })
    
    return differences

def _analyze_dict_relationships(data: dict) -> Dict[str, Any]:
    """Analyze relationships in dictionary data."""
    field_analysis = {}
    
    for key, value in data.items():
        analysis = {
            'type': type(value).__name__,
            'unique_values': None,
            'potential_key': False,
            'references_other_fields': []
        }
        
        if isinstance(value, list):
            analysis['array_length'] = len(value)
            if value and isinstance(value[0], dict):
                # Analyze object array
                all_keys = set()
                for item in value:
                    if isinstance(item, dict):
                        all_keys.update(item.keys())
                analysis['common_object_fields'] = list(all_keys)
        elif isinstance(value, dict):
            analysis['nested_fields'] = list(value.keys())
        
        field_analysis[key] = analysis
    
    return field_analysis

def _analyze_array_patterns(data: list) -> List[Dict[str, Any]]:
    """Analyze patterns in array data."""
    if not data:
        return []
    
    patterns = []
    
    # Check if array contains objects
    if isinstance(data[0], dict):
        # Analyze object structure consistency
        all_keys = set()
        for item in data:
            if isinstance(item, dict):
                all_keys.update(item.keys())
        
        pattern = {
            'type': 'object_array',
            'length': len(data),
            'all_fields': list(all_keys),
            'consistent_structure': all(isinstance(item, dict) and set(item.keys()) == all_keys for item in data)
        }
        patterns.append(pattern)
    
    return patterns

def _analyze_nesting_patterns(data: Any, max_depth: int = 5) -> Dict[str, Any]:
    """Analyze nesting patterns in the data."""
    patterns = {
        'max_depth': 0,
        'depth_distribution': {},
        'common_structures': []
    }
    
    def analyze_depth(obj, current_depth=0):
        patterns['max_depth'] = max(patterns['max_depth'], current_depth)
        patterns['depth_distribution'][current_depth] = patterns['depth_distribution'].get(current_depth, 0) + 1
        
        if current_depth < max_depth:
            if isinstance(obj, dict):
                for value in obj.values():
                    analyze_depth(value, current_depth + 1)
            elif isinstance(obj, list):
                for item in obj:
                    analyze_depth(item, current_depth + 1)
    
    analyze_depth(data)
    return patterns

def _detect_potential_relationships(data: Any) -> List[Dict[str, Any]]:
    """Detect potential relationships between data elements."""
    relationships = []
    
    # This is a simplified relationship detection
    # In a real implementation, you might want more sophisticated analysis
    
    if isinstance(data, dict):
        # Look for fields that might reference other fields
        for key, value in data.items():
            if isinstance(value, list):
                relationships.append({
                    'type': 'one_to_many',
                    'parent_field': key,
                    'description': f"Field '{key}' contains an array, suggesting one-to-many relationship"
                })
    
    return relationships
