"""JSON writing and manipulation functions."""

import os
import json
import csv
from typing import Dict, Union, Any, List
from pathlib import Path

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings
from engineering_iq.shared.tools.structured_data_tool.json_tool.read_functions import read_json


settings = app_settings
logger = get_logger(__name__)

def write_json(file_path: str, data: Any, overwrite: bool = False, indent: int = 2, 
               encoding: str = "utf-8", ensure_ascii: bool = False) -> Dict[str, Union[str, bool]]:
    """
    Write data to a JSON file.

    Args:
        file_path: Path to the JSON file to write
        data: Data to write to the JSON file
        overwrite: If True, overwrite the file if it exists (default: False)
        indent: JSON indentation level (default: 2, set to 0 for compact)
        encoding: File encoding (default: "utf-8")
        ensure_ascii: If True, escape non-ASCII characters (default: False)

    Returns:
        A dictionary indicating success or failure
    """
    logger.debug(f"Writing JSON file: {file_path}, overwrite: {overwrite}")
    
    if os.path.exists(file_path) and not overwrite:
        logger.warning(f"JSON file {file_path} already exists and overwrite is False.")
        return {'status': 'error', 'message': 'JSON file exists and overwrite is False.', 'file_path': file_path}
    
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        with open(file_path, 'w', encoding=encoding) as f:
            if indent == 0:
                json.dump(data, f, ensure_ascii=ensure_ascii, separators=(',', ':'))
            else:
                json.dump(data, f, indent=indent, ensure_ascii=ensure_ascii, separators=(',', ': '))
        
        logger.info(f"Successfully wrote JSON file: {file_path}")
        return {'status': 'success', 'message': 'JSON file written successfully.', 'file_path': file_path}
    except Exception as e:
        logger.error(f"Error writing JSON file {file_path}: {str(e)}")
        return {'status': 'error', 'message': str(e), 'file_path': file_path}

def merge_json_files(file_paths: List[str], output_path: str, merge_strategy: str = "merge_objects", 
                    encoding: str = "utf-8") -> Dict[str, Union[str, bool]]:
    """
    Merge multiple JSON files into one.

    Args:
        file_paths: List of paths to JSON files to merge
        output_path: Path where the merged JSON file should be saved
        merge_strategy: Strategy for merging ("merge_objects", "combine_arrays", "separate_files")
        encoding: File encoding (default: "utf-8")

    Returns:
        A dictionary indicating success or failure
    """
    logger.debug(f"Merging JSON files: {file_paths} -> {output_path}, strategy: {merge_strategy}")
    
    if not file_paths:
        return {'status': 'error', 'message': 'No input files provided'}
    
    try:
        merged_data = None
        
        for file_path in file_paths:
            if not os.path.exists(file_path):
                logger.warning(f"Skipping non-existent file: {file_path}")
                continue
            
            json_data = read_json(file_path, encoding)
            if isinstance(json_data, str):  # Error occurred
                logger.warning(f"Skipping file with error: {file_path}")
                continue
            
            data = json_data['data']
            
            if merged_data is None:
                merged_data = data
            else:
                if merge_strategy == "merge_objects" and isinstance(merged_data, dict) and isinstance(data, dict):
                    merged_data.update(data)
                elif merge_strategy == "combine_arrays" and isinstance(merged_data, list) and isinstance(data, list):
                    merged_data.extend(data)
                elif merge_strategy == "separate_files":
                    if not isinstance(merged_data, dict):
                        merged_data = {'file_0': merged_data}
                    file_key = f"file_{len(merged_data)}"
                    merged_data[file_key] = data
                else:
                    # Default: combine as separate entries
                    if not isinstance(merged_data, dict):
                        merged_data = {'merged_data': [merged_data]}
                    if 'merged_data' not in merged_data:
                        merged_data = {'merged_data': [merged_data]}
                    merged_data['merged_data'].append(data)
        
        if merged_data is None:
            return {'status': 'error', 'message': 'No valid JSON files found to merge'}
        
        # Write merged data
        result = write_json(output_path, merged_data, overwrite=True, encoding=encoding)
        if result['status'] == 'success':
            result['message'] = 'JSON files merged successfully.'
            result['files_merged'] = len(file_paths)
        
        return result
    except Exception as e:
        logger.error(f"Error merging JSON files: {str(e)}")
        return {'status': 'error', 'message': str(e)}

def flatten_json(file_path: str, output_path: str = "", separator: str = ".", 
                encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Flatten a nested JSON structure.

    Args:
        file_path: Path to the JSON file
        output_path: Path to save flattened JSON (optional, returns data if empty)
        separator: Separator for nested keys (default: ".")
        encoding: File encoding (default: "utf-8")

    Returns:
        Dictionary with flattened data or error message
    """
    logger.debug(f"Flattening JSON file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"JSON file not found: {file_path}")
        return f"JSON file not found: {file_path}"
    
    try:
        json_data = read_json(file_path, encoding)
        if isinstance(json_data, str):  # Error occurred
            return json_data
        
        data = json_data['data']
        flattened = _flatten_dict(data, separator)
        
        result = {
            'file_path': file_path,
            'flattened_data': flattened,
            'original_keys': _count_keys(data),
            'flattened_keys': len(flattened) if isinstance(flattened, dict) else 1
        }
        
        if output_path:
            write_result = write_json(output_path, flattened, overwrite=True, encoding=encoding)
            result['output_file'] = output_path
            result['write_status'] = write_result['status']
        
        logger.debug(f"Flattened JSON with {result['flattened_keys']} keys")
        return result
    except Exception as e:
        logger.error(f"Error flattening JSON file {file_path}: {str(e)}")
        return f"Error flattening JSON file {file_path}: {str(e)}"

def _flatten_dict(data: Any, separator: str = ".", prefix: str = "") -> Dict[str, Any]:
    """Recursively flatten a nested dictionary."""
    if isinstance(data, dict):
        result = {}
        for key, value in data.items():
            new_key = f"{prefix}{separator}{key}" if prefix else key
            if isinstance(value, (dict, list)):
                result.update(_flatten_dict(value, separator, new_key))
            else:
                result[new_key] = value
        return result
    elif isinstance(data, list):
        result = {}
        for i, item in enumerate(data):
            new_key = f"{prefix}{separator}{i}" if prefix else str(i)
            if isinstance(item, (dict, list)):
                result.update(_flatten_dict(item, separator, new_key))
            else:
                result[new_key] = item
        return result
    else:
        return {prefix: data} if prefix else data

def _count_keys(data: Any) -> int:
    """Count the total number of keys in a nested structure."""
    if isinstance(data, dict):
        return len(data) + sum(_count_keys(value) for value in data.values())
    elif isinstance(data, list):
        return sum(_count_keys(item) for item in data)
    else:
        return 0

def convert_json_to_csv(json_path: str, csv_path: str, encoding: str = "utf-8", 
                       flatten_nested: bool = True) -> Dict[str, Union[str, bool]]:
    """
    Convert a JSON file to CSV format.

    Args:
        json_path: Path to the JSON file
        csv_path: Path where the CSV file should be saved
        encoding: File encoding (default: "utf-8")
        flatten_nested: Whether to flatten nested objects (default: True)

    Returns:
        A dictionary indicating success or failure
    """
    logger.debug(f"Converting JSON file to CSV: {json_path} -> {csv_path}")
    if not os.path.exists(json_path):
        logger.error(f"JSON file not found: {json_path}")
        return {'status': 'error', 'message': f'JSON file not found: {json_path}'}
    
    try:
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        json_data = read_json(json_path, encoding)
        if isinstance(json_data, str):  # Error occurred
            return {'status': 'error', 'message': json_data}
        
        data = json_data['data']
        
        # Handle different data structures
        if isinstance(data, list):
            # Array of objects - perfect for CSV
            rows = data
        elif isinstance(data, dict):
            # Single object or object with arrays
            if all(isinstance(v, list) for v in data.values()):
                # Object with arrays - transpose
                max_len = max(len(v) for v in data.values())
                rows = []
                for i in range(max_len):
                    row = {}
                    for key, values in data.items():
                        row[key] = values[i] if i < len(values) else None
                    rows.append(row)
            else:
                # Single object - convert to single row
                rows = [data]
        else:
            return {'status': 'error', 'message': 'JSON data is not suitable for CSV conversion'}
        
        # Flatten nested objects if requested
        if flatten_nested:
            flattened_rows = []
            for row in rows:
                if isinstance(row, dict):
                    flattened_rows.append(_flatten_dict(row))
                else:
                    flattened_rows.append({'value': row})
            rows = flattened_rows
        
        # Write to CSV
        if rows:
            fieldnames = set()
            for row in rows:
                if isinstance(row, dict):
                    fieldnames.update(row.keys())
            
            with open(csv_path, 'w', newline='', encoding=encoding) as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=list(fieldnames))
                writer.writeheader()
                for row in rows:
                    if isinstance(row, dict):
                        writer.writerow(row)
                    else:
                        writer.writerow({'value': row})
        
        logger.info(f"Successfully converted JSON file to CSV: {json_path} -> {csv_path}")
        return {'status': 'success', 'message': 'JSON file converted to CSV successfully.', 'csv_path': csv_path}
    except Exception as e:
        logger.error(f"Error converting JSON file to CSV {json_path}: {str(e)}")
        return {'status': 'error', 'message': str(e)}
