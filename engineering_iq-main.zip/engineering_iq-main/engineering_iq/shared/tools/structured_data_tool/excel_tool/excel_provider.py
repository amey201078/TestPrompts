from typing import Any, Dict, Union, Optional, List
import engineering_iq.shared.tools.structured_data_tool.excel_tool.read_functions as read_functions
import engineering_iq.shared.tools.structured_data_tool.excel_tool.write_functions as write_functions
from engineering_iq.shared.tools.structured_data_tool.structured_data_provider import StructuredDataProvider

class ExcelProvider(StructuredDataProvider):
    """Excel data provider."""

    def fetch_structured_data(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None,
             limit: Optional[int] = None, offset: int = 0, summary_only: bool = False) -> Union[str, Dict[str, Any]]:
        """Read Excel data from file with batching support.
        
        Args:
            file_path: Path to the Excel file
            encoding: File encoding (default: utf-8)
            container: Sheet name to read from (if None, reads all sheets or default sheet)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)
            summary_only: If True, return only summary info without actual data
        """
        if summary_only:
            return read_functions.get_excel_summary(file_path, encoding=encoding, sheet_name=container)
        return read_functions.read_excel(file_path, encoding=encoding, sheet_name=container, limit=limit, offset=offset)
    
    def write_structured_data(self, file_path: str, data: Any, encoding: str = "utf-8", container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Write data to Excel file.
        
        Args:
            file_path: Path to the Excel file
            data: Data to write
            encoding: File encoding (default: utf-8)
            container: Sheet name to write to (if None, uses default sheet name)
        """
        return write_functions.write_excel(file_path, data, encoding=encoding, sheet_name=container)
    
    def query_structured_data(self, file_path: str, query_expression: str, encoding: str = "utf-8", container: Optional[str] = None,
              limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
        """Query Excel data with batching support.
        
        Args:
            file_path: Path to the Excel file
            query_expression: Query expression
            encoding: File encoding (default: utf-8)
            container: Sheet name to query (if None, queries default sheet)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)
        """
        return read_functions.query_excel(file_path, query_expression, encoding=encoding, sheet_name=container, limit=limit, offset=offset)    

    def get_structure(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Get Excel structure/summary.
        
        Args:
            file_path: Path to the Excel file
            encoding: File encoding (default: utf-8)
            container: Sheet name to analyze (if None, analyzes all sheets)
        """
        return read_functions.get_excel_summary(file_path, encoding=encoding, sheet_name=container)

    def get_stats_from_structured(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Get Excel statistics.
        
        Args:
            file_path: Path to the Excel file
            encoding: File encoding (default: utf-8)
            container: Sheet name to analyze (if None, analyzes all sheets)
        """
        return read_functions.get_excel_stats(file_path, encoding=encoding, sheet_name=container)

    def list_containers(self, file_path: str, encoding: str = "utf-8") -> Union[str, List[str]]:
        """List all sheets in the Excel file.
        
        Args:
            file_path: Path to the Excel file
            encoding: File encoding (default: utf-8)
            
        Returns:
            List of sheet names or error message
        """
        return read_functions.list_sheets(file_path)

    def get_container_column(self, file_path: str, column_name: str, encoding: str = "utf-8", 
                            container: Optional[str] = None, limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
        """Retrieve a specific column from an Excel sheet.
        
        Args:
            file_path: Path to the Excel file
            column_name: Name of the column to retrieve
            encoding: File encoding (default: utf-8)
            container: Sheet name (if None, uses first sheet)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)

        Returns:
            Data from the specified column with statistics and sample values
        """
        return read_functions.get_excel_column(file_path, column_name, encoding=encoding, sheet_name=container, limit=limit, offset=offset)

    def compare_structured_data(self, file_path1: str, file_path2: str, encoding: str = "utf-8",
                    container1: Optional[str] = None, container2: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Compare two Excel data sources and identify differences.
        
        Args:
            file_path1: Path to first Excel file
            file_path2: Path to second Excel file
            encoding: File encoding (default: utf-8)
            container1: Sheet name in first file
            container2: Sheet name in second file
            
        Returns:
            Comparison report showing differences in structure, content, statistics
        """
        return read_functions.compare_excel_data(file_path1, file_path2, encoding=encoding, sheet_name1=container1, sheet_name2=container2)

    def detect_relationships(self, file_path: str, encoding: str = "utf-8", 
                           container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Detect relationships and correlations between Excel columns.
        
        Args:
            file_path: Path to the Excel file
            encoding: File encoding (default: utf-8)
            container: Sheet name (if None, uses first sheet)
            
        Returns:
            Analysis of correlations, dependencies, and potential relationships between columns
        """
        return read_functions.detect_excel_relationships(file_path, encoding=encoding, sheet_name=container)
