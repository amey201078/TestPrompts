"""Excel reading functions for data access and analysis."""

import os
import pandas as pd
from typing import List, Dict, Union, Optional, Any
import json
import numpy as np

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings

settings = app_settings
logger = get_logger(__name__)

def read_excel(file_path: str, encoding: str = "utf-8", sheet_name: Optional[str] = None, 
               limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
    """
    Read an Excel file and return its content as a dictionary with batching support.

    Args:
        file_path: Path to the Excel file
        sheet_name: Name of the sheet to read (default: None, reads all sheets or first sheet)
        limit: Maximum number of records to return (None for all)
        offset: Number of records to skip (default: 0)

    Returns:
        Dictionary with sheet data or error message if the file doesn't exist or can't be read
    """
    logger.debug(f"Reading Excel file: {file_path}, sheet: {sheet_name}, limit: {limit}, offset: {offset}")
    if not os.path.exists(file_path):
        logger.error(f"Excel file not found: {file_path}")
        return f"Excel file not found: {file_path}"
    
    try:
        if sheet_name:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # Apply batching
            if offset > 0:
                df = df.iloc[offset:]
            if limit is not None:
                df = df.head(limit)
                
            result = {
                'sheet_name': sheet_name,
                'data': json.loads(df.to_json(orient='records')),
                'columns': df.columns.tolist(),
                'shape': df.shape,
                'total_rows': len(pd.read_excel(file_path, sheet_name=sheet_name)),
                'offset': offset,
                'limit': limit
            }
        else:
            # Read all sheets
            excel_data = pd.read_excel(file_path, sheet_name=None)
            result = {}
            for sheet, df in excel_data.items():
                # Apply batching to each sheet
                original_len = len(df)
                if offset > 0:
                    df = df.iloc[offset:]
                if limit is not None:
                    df = df.head(limit)
                    
                result[sheet] = {
                    'data': json.loads(df.to_json(orient='records')),
                    'columns': df.columns.tolist(),
                    'shape': df.shape,
                    'total_rows': original_len,
                    'offset': offset,
                    'limit': limit
                }
        
        logger.debug(f"Successfully read Excel file: {file_path}")
        return result
    except Exception as e:
        logger.error(f"Error reading Excel file {file_path}: {str(e)}")
        return f"Error reading Excel file {file_path}: {str(e)}"

def list_sheets(file_path: str) -> Union[str, List[str]]:
    """
    List all sheets in an Excel file.

    Args:
        file_path: Path to the Excel file

    Returns:
        List of sheet names or error message if the file doesn't exist or can't be read
    """
    logger.debug(f"Listing sheets in Excel file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"Excel file not found: {file_path}")
        return f"Excel file not found: {file_path}"
    
    try:
        excel_data = pd.read_excel(file_path, sheet_name=None)
        sheets = list(excel_data.keys())
        logger.debug(f"Found {len(sheets)} sheets in {file_path}")
        return sheets
    except Exception as e:
        logger.error(f"Error listing sheets in Excel file {file_path}: {str(e)}")
        return f"Error listing sheets in Excel file {file_path}: {str(e)}"

def query_excel(file_path: str, query: str, encoding: str = "utf-8", sheet_name: Optional[str] = None,
                limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
    """
    Query an Excel file using pandas query syntax with batching support.

    Args:
        file_path: Path to the Excel file
        query: Pandas query string (e.g., "Column1 > 100 and Column2 == 'Value'")
        sheet_name: Name of the sheet to query (default: None, uses the first sheet)
        limit: Maximum number of records to return (None for all)
        offset: Number of records to skip (default: 0)

    Returns:
        Dictionary with query results or error message
    """
    logger.debug(f"Querying Excel file: {file_path}, sheet: {sheet_name}, query: {query}")
    if not os.path.exists(file_path):
        logger.error(f"Excel file not found: {file_path}")
        return f"Excel file not found: {file_path}"
    
    if not query:
        logger.error("Query string is required")
        return "Query string is required"
    
    try:
        if sheet_name:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
        else:
            # Use the first sheet if none specified
            df = pd.read_excel(file_path)
            sheet_name = "first_sheet"
        
        # Apply the query
        result_df = df.query(query)
        total_results = len(result_df)
        
        # Apply batching
        if offset > 0:
            result_df = result_df.iloc[offset:]
        if limit is not None:
            result_df = result_df.head(limit)
        
        result = {
            'sheet_name': sheet_name,
            'query': query,
            'data': json.loads(result_df.to_json(orient='records')),
            'columns': result_df.columns.tolist(),
            'shape': result_df.shape,
            'total_results': total_results,
            'returned_count': len(result_df),
            'offset': offset,
            'limit': limit
        }
        
        logger.debug(f"Query returned {len(result_df)} rows (total: {total_results})")
        return result
    except Exception as e:
        logger.error(f"Error querying Excel file {file_path}: {str(e)}")
        return f"Error querying Excel file {file_path}: {str(e)}"

def get_excel_summary(file_path: str, encoding: str = "utf-8", sheet_name: Optional[str] = None) -> Union[str, Dict[str, Any]]:
    """
    Get a summary of an Excel file including all sheets, their dimensions, and column names.

    Args:
        file_path: Path to the Excel file
        sheet_name: If specified, get summary for specific sheet only

    Returns:
        Dictionary with Excel file summary or error message
    """
    logger.debug(f"Getting summary for Excel file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"Excel file not found: {file_path}")
        return f"Excel file not found: {file_path}"
    
    try:
        if sheet_name:
            # Get summary for specific sheet
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            summary = {
                'file_path': file_path,
                'sheet_name': sheet_name,
                'rows': df.shape[0],
                'columns': df.shape[1],
                'column_names': df.columns.tolist(),
                'data_types': {col: str(dtype) for col, dtype in df.dtypes.items()}
            }
        else:
            # Get summary for all sheets
            excel_data = pd.read_excel(file_path, sheet_name=None)
            summary = {
                'file_path': file_path,
                'sheet_count': len(excel_data),
                'sheets': {}
            }
            
            for sheet_name, df in excel_data.items():
                summary['sheets'][sheet_name] = {
                    'rows': df.shape[0],
                    'columns': df.shape[1],
                    'column_names': df.columns.tolist(),
                    'data_types': {col: str(dtype) for col, dtype in df.dtypes.items()}
                }
        
        logger.debug(f"Generated summary for Excel file")
        return summary
    except Exception as e:
        logger.error(f"Error generating summary for Excel file {file_path}: {str(e)}")
        return f"Error generating summary for Excel file {file_path}: {str(e)}"

def get_excel_stats(file_path: str, encoding: str = "utf-8", sheet_name: Optional[str] = None) -> Union[str, Dict[str, Any]]:
    """
    Get statistics about an Excel file including sheet count, total rows, and data types.

    Args:
        file_path: Path to the Excel file
        sheet_name: If specified, get stats for specific sheet only

    Returns:
        Dictionary with Excel file statistics or error message
    """
    logger.debug(f"Getting stats for Excel file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"Excel file not found: {file_path}")
        return f"Excel file not found: {file_path}"
    
    try:
        if sheet_name:
            # Get stats for specific sheet
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            stats = {
                'file_path': file_path,
                'sheet_name': sheet_name,
                'rows': df.shape[0],
                'columns': df.shape[1],
                'data_types': df.dtypes.value_counts().to_dict(),
                'null_counts': df.isnull().sum().to_dict()
            }
        else:
            # Get stats for all sheets
            excel_data = pd.read_excel(file_path, sheet_name=None)
            
            # Calculate total rows across all sheets
            total_rows = sum(df.shape[0] for df in excel_data.values())
            total_columns = sum(df.shape[1] for df in excel_data.values())
            
            # Get file size in bytes
            size_bytes = os.path.getsize(file_path)
            
            stats = {
                'file_path': file_path,
                'size_bytes': size_bytes,
                'sheet_count': len(excel_data),
                'total_rows': total_rows,
                'total_columns': total_columns,
                'sheets': {sheet: {'rows': df.shape[0], 'columns': df.shape[1]} for sheet, df in excel_data.items()}
            }
        
        logger.debug(f"Excel stats: {stats}")
        return stats
    except Exception as e:
        logger.error(f"Error getting stats for Excel file {file_path}: {str(e)}")
        return f"Error getting stats for Excel file {file_path}: {str(e)}"

def get_excel_column(file_path: str, column_name: str, encoding: str = "utf-8", 
                     sheet_name: Optional[str] = None, limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
    """
    Retrieve a specific column from an Excel sheet with statistics and sample values.

    Args:
        file_path: Path to the Excel file
        column_name: Name of the column to retrieve
        encoding: File encoding (default: utf-8)
        sheet_name: Sheet name (if None, uses first sheet)
        limit: Maximum number of records to return (None for all)
        offset: Number of records to skip (default: 0)

    Returns:
        Dictionary with column data, statistics, and sample values
    """
    logger.debug(f"Getting column {column_name} from Excel file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"Excel file not found: {file_path}")
        return f"Excel file not found: {file_path}"
    
    try:
        if sheet_name:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
        else:
            df = pd.read_excel(file_path)
            sheet_name = "first_sheet"
        
        if column_name not in df.columns:
            return f"Column '{column_name}' not found in sheet '{sheet_name}'. Available columns: {list(df.columns)}"
        
        column_data = df[column_name]
        total_count = len(column_data)
        
        # Apply batching
        if offset > 0:
            column_data = column_data.iloc[offset:]
        if limit is not None:
            column_data = column_data.head(limit)
        
        # Calculate statistics
        stats = {
            'data_type': str(column_data.dtype),
            'total_count': total_count,
            'returned_count': len(column_data),
            'null_count': column_data.isnull().sum(),
            'unique_count': column_data.nunique(),
            'offset': offset,
            'limit': limit
        }
        
        if column_data.dtype in ['int64', 'float64', 'int32', 'float32']:
            stats.update({
                'mean': column_data.mean(),
                'median': column_data.median(),
                'std': column_data.std(),
                'min': column_data.min(),
                'max': column_data.max()
            })
        
        result = {
            'file_path': file_path,
            'sheet_name': sheet_name,
            'column_name': column_name,
            'values': column_data.dropna().tolist(),
            'statistics': stats,
            'sample_values': column_data.dropna().head(10).tolist()
        }
        
        logger.debug(f"Retrieved column {column_name} with {len(column_data)} values")
        return result
    except Exception as e:
        logger.error(f"Error getting column from Excel file {file_path}: {str(e)}")
        return f"Error getting column from Excel file {file_path}: {str(e)}"

def compare_excel_data(file_path1: str, file_path2: str, encoding: str = "utf-8",
                       sheet_name1: Optional[str] = None, sheet_name2: Optional[str] = None) -> Union[str, Dict[str, Any]]:
    """
    Compare two Excel data sources and identify differences.

    Args:
        file_path1: Path to first Excel file
        file_path2: Path to second Excel file
        encoding: File encoding (default: utf-8)
        sheet_name1: Sheet name in first file
        sheet_name2: Sheet name in second file

    Returns:
        Comparison report showing differences in structure, content, statistics
    """
    logger.debug(f"Comparing Excel files: {file_path1} vs {file_path2}")
    
    try:
        # Read both files
        if sheet_name1:
            df1 = pd.read_excel(file_path1, sheet_name=sheet_name1)
        else:
            df1 = pd.read_excel(file_path1)
            sheet_name1 = "first_sheet"
            
        if sheet_name2:
            df2 = pd.read_excel(file_path2, sheet_name=sheet_name2)
        else:
            df2 = pd.read_excel(file_path2)
            sheet_name2 = "first_sheet"
        
        # Compare structure
        structure_diff = {
            'file1_shape': df1.shape,
            'file2_shape': df2.shape,
            'file1_columns': df1.columns.tolist(),
            'file2_columns': df2.columns.tolist(),
            'common_columns': list(set(df1.columns) & set(df2.columns)),
            'unique_to_file1': list(set(df1.columns) - set(df2.columns)),
            'unique_to_file2': list(set(df2.columns) - set(df1.columns))
        }
        
        # Compare content for common columns
        content_diff = {}
        for col in structure_diff['common_columns']:
            if df1[col].dtype == df2[col].dtype:
                content_diff[col] = {
                    'identical_values': (df1[col] == df2[col]).sum() if len(df1) == len(df2) else "Different lengths",
                    'file1_unique': df1[col].nunique(),
                    'file2_unique': df2[col].nunique()
                }
        
        result = {
            'file1': file_path1,
            'file2': file_path2,
            'sheet1': sheet_name1,
            'sheet2': sheet_name2,
            'structure_differences': structure_diff,
            'content_differences': content_diff,
            'summary': {
                'structural_match': df1.shape == df2.shape and set(df1.columns) == set(df2.columns),
                'column_count_diff': len(df1.columns) - len(df2.columns),
                'row_count_diff': len(df1) - len(df2)
            }
        }
        
        logger.debug("Excel comparison completed")
        return result
    except Exception as e:
        logger.error(f"Error comparing Excel files: {str(e)}")
        return f"Error comparing Excel files: {str(e)}"

def detect_excel_relationships(file_path: str, encoding: str = "utf-8", 
                              sheet_name: Optional[str] = None) -> Union[str, Dict[str, Any]]:
    """
    Detect relationships and correlations between Excel columns.

    Args:
        file_path: Path to the Excel file
        encoding: File encoding (default: utf-8)
        sheet_name: Sheet name (if None, uses first sheet)

    Returns:
        Analysis of correlations, dependencies, and potential relationships between columns
    """
    logger.debug(f"Detecting relationships in Excel file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"Excel file not found: {file_path}")
        return f"Excel file not found: {file_path}"
    
    try:
        if sheet_name:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
        else:
            df = pd.read_excel(file_path)
            sheet_name = "first_sheet"
        
        # Get numeric columns for correlation analysis
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        relationships = {
            'file_path': file_path,
            'sheet_name': sheet_name,
            'total_columns': len(df.columns),
            'numeric_columns': numeric_cols,
            'correlations': {},
            'potential_keys': [],
            'column_relationships': {}
        }
        
        # Calculate correlations for numeric columns
        if len(numeric_cols) > 1:
            corr_matrix = df[numeric_cols].corr()
            # Convert to dict and remove self-correlations
            correlations = {}
            for col1 in numeric_cols:
                for col2 in numeric_cols:
                    if col1 != col2:
                        corr_val = corr_matrix.loc[col1, col2]
                        if not pd.isna(corr_val) and abs(corr_val) > 0.1:  # Only significant correlations
                            key = f"{col1}_vs_{col2}"
                            correlations[key] = {
                                'correlation': corr_val,
                                'strength': 'strong' if abs(corr_val) > 0.7 else 'moderate' if abs(corr_val) > 0.3 else 'weak'
                            }
            relationships['correlations'] = correlations
        
        # Detect potential primary keys (unique columns)
        for col in df.columns:
            if df[col].nunique() == len(df) and df[col].notna().all():
                relationships['potential_keys'].append(col)
        
        # Analyze column relationships
        for col in df.columns:
            relationships['column_relationships'][col] = {
                'unique_values': df[col].nunique(),
                'null_percentage': (df[col].isnull().sum() / len(df)) * 100,
                'data_type': str(df[col].dtype),
                'potential_foreign_key': df[col].nunique() < len(df) * 0.8  # Heuristic
            }
        
        logger.debug("Relationship detection completed")
        return relationships
    except Exception as e:
        logger.error(f"Error detecting relationships in Excel file {file_path}: {str(e)}")
        return f"Error detecting relationships in Excel file {file_path}: {str(e)}"

def filter_excel(file_path: str, filter_key: str, filter_value: str, sheet_name: str = "") -> Union[str, Dict[str, Any]]:
    """
    Filter Excel data based on a single column value.

    Args:
        file_path: Path to the Excel file
        filter_key: Column name to filter by
        filter_value: Value to match in the column
        sheet_name: Name of the sheet to filter (default: empty string, uses the first sheet)

    Returns:
        Dictionary with filtered data or error message
    """
    logger.debug(f"Filtering Excel file: {file_path}, sheet: {sheet_name}, key: {filter_key}, value: {filter_value}")
    if not os.path.exists(file_path):
        logger.error(f"Excel file not found: {file_path}")
        return f"Excel file not found: {file_path}"
    
    if not filter_key:
        logger.error("Filter key is required")
        return "Filter key is required"
    
    try:
        if sheet_name:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
        else:
            # Use the first sheet if none specified
            df = pd.read_excel(file_path)
            sheet_name = "first_sheet"
        
        # Apply filter
        filtered_df = df.copy()
        if filter_key in filtered_df.columns:
            filtered_df = filtered_df[filtered_df[filter_key] == filter_value]
        else:
            return f"Column '{filter_key}' not found in sheet '{sheet_name}'"
        
        result = {
            'sheet_name': sheet_name,
            'filter_key': filter_key,
            'filter_value': filter_value,
            'data': json.loads(filtered_df.to_json(orient='records')),
            'columns': filtered_df.columns.tolist(),
            'shape': filtered_df.shape,
            'row_count': len(filtered_df)
        }
        
        logger.debug(f"Filter returned {len(filtered_df)} rows")
        return result
    except Exception as e:
        logger.error(f"Error filtering Excel file {file_path}: {str(e)}")
        return f"Error filtering Excel file {file_path}: {str(e)}"
