"""Excel writing and conversion functions."""

import os
import pandas as pd
from typing import Dict, Union, Any, Optional

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings

settings = app_settings
logger = get_logger(__name__)

def write_excel(file_path: str, data: Any, encoding: str = "utf-8", sheet_name: Optional[str] = None, overwrite: bool = False) -> Dict[str, Union[str, bool]]:
    """
    Write data to an Excel file. By default, it does not overwrite if the file exists.

    Args:
        file_path: Path to the Excel file to write
        data: Dictionary or list of dictionaries to write to the Excel file
        encoding: File encoding (currently not used for Excel, maintained for interface compatibility)
        sheet_name: Name of the sheet to write to (default: "Sheet1" if None)
        overwrite: If True, overwrite the file if it exists (default: False)

    Returns:
        A dictionary indicating success or failure.
    """
    # Use default sheet name if none provided
    if sheet_name is None:
        sheet_name = "Sheet1"
        
    logger.debug(f"Attempting to write to Excel file: {file_path}, sheet: {sheet_name}, overwrite: {overwrite}")
    if os.path.exists(file_path) and not overwrite:
        logger.warning(f"Excel file {file_path} already exists and overwrite is False.")
        return {'status': 'error', 'message': 'Excel file exists and overwrite is False.', 'file_path': file_path}
    
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)  # Ensure directory exists
        
        # Convert data to DataFrame
        if isinstance(data, list):
            df = pd.DataFrame(data)
        elif isinstance(data, dict) and 'data' in data:
            # Handle case where data is in {'data': [...]} format
            df = pd.DataFrame(data['data'])
        else:
            df = pd.DataFrame([data])
        
        # Write to Excel
        with pd.ExcelWriter(file_path, engine='openpyxl', mode='w') as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
        
        logger.info(f"Successfully wrote to Excel file: {file_path}, sheet: {sheet_name}")
        return {'status': 'success', 'message': 'Excel file written successfully.', 'file_path': file_path}
    except Exception as e:
        logger.error(f"Error writing to Excel file {file_path}: {str(e)}")
        return {'status': 'error', 'message': str(e), 'file_path': file_path}

def append_to_excel(file_path: str, data: Dict[str, Any], sheet_name: str = "Sheet1") -> Dict[str, Union[str, bool]]:
    """
    Append data to an existing Excel file. Creates the file if it doesn't exist.

    Args:
        file_path: Path to the Excel file
        data: Dictionary or list of dictionaries to append to the Excel file
        sheet_name: Name of the sheet to append to (default: "Sheet1")

    Returns:
        A dictionary indicating success or failure.
    """
    logger.debug(f"Attempting to append to Excel file: {file_path}, sheet: {sheet_name}")
    
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)  # Ensure directory exists
        
        # Convert data to DataFrame
        if isinstance(data, list):
            new_df = pd.DataFrame(data)
        elif isinstance(data, dict) and 'data' in data:
            new_df = pd.DataFrame(data['data'])
        else:
            new_df = pd.DataFrame([data])
        
        # Check if file exists
        if os.path.exists(file_path):
            # Read existing data
            try:
                existing_df = pd.read_excel(file_path, sheet_name=sheet_name)
                # Combine existing and new data
                combined_df = pd.concat([existing_df, new_df], ignore_index=True)
            except Exception:
                # Sheet doesn't exist or other error, just use new data
                combined_df = new_df
                
            # Write back to file with all sheets
            with pd.ExcelWriter(file_path, engine='openpyxl', mode='a' if sheet_name not in pd.ExcelFile(file_path).sheet_names else 'w') as writer:
                combined_df.to_excel(writer, sheet_name=sheet_name, index=False)
        else:
            # Create new file
            with pd.ExcelWriter(file_path, engine='openpyxl', mode='w') as writer:
                new_df.to_excel(writer, sheet_name=sheet_name, index=False)
        
        logger.info(f"Successfully appended to Excel file: {file_path}, sheet: {sheet_name}")
        return {'status': 'success', 'message': 'Data appended to Excel file successfully.', 'file_path': file_path}
    except Exception as e:
        logger.error(f"Error appending to Excel file {file_path}: {str(e)}")
        return {'status': 'error', 'message': str(e), 'file_path': file_path}

def convert_excel_to_csv(excel_path: str, csv_path: str, sheet_name: str = "") -> Dict[str, Union[str, bool]]:
    """
    Convert an Excel file to CSV format.

    Args:
        excel_path: Path to the Excel file
        csv_path: Path where the CSV file should be saved
        sheet_name: Name of the sheet to convert (default: empty string, converts the first sheet)

    Returns:
        A dictionary indicating success or failure.
    """
    logger.debug(f"Converting Excel file to CSV: {excel_path} -> {csv_path}, sheet: {sheet_name}")
    if not os.path.exists(excel_path):
        logger.error(f"Excel file not found: {excel_path}")
        return {'status': 'error', 'message': f'Excel file not found: {excel_path}'}
    
    try:
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)  # Ensure directory exists
        
        if sheet_name:
            df = pd.read_excel(excel_path, sheet_name=sheet_name)
            df.to_csv(csv_path, index=False)
        else:
            # Use the first sheet if none specified
            df = pd.read_excel(excel_path)
            df.to_csv(csv_path, index=False)
        
        logger.info(f"Successfully converted Excel file to CSV: {excel_path} -> {csv_path}")
        return {'status': 'success', 'message': 'Excel file converted to CSV successfully.', 'csv_path': csv_path}
    except Exception as e:
        logger.error(f"Error converting Excel file to CSV {excel_path}: {str(e)}")
        return {'status': 'error', 'message': str(e)}
