"""XML analysis functions for statistics, comparisons, and relationship detection."""

import os
import xml.etree.ElementTree as ET
from typing import Dict, Union, Optional, Any

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings
from .core_functions import _element_to_dict

settings = app_settings
logger = get_logger(__name__)

def get_xml_stats(file_path: str, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Get statistics about an XML file including element counts and structure depth.

    Args:
        file_path: Path to the XML file
        encoding: XML file encoding (default: "utf-8")

    Returns:
        Dictionary with XML file statistics or error message
    """
    logger.debug(f"Getting stats for XML file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    try:
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            root = ET.fromstring(content)
        else:
            tree = ET.parse(file_path)
            root = tree.getroot()
        
        # Count elements by tag
        tag_counts = {}
        total_elements = 0
        max_depth = 0
        
        def count_elements(elem, depth=0):
            nonlocal total_elements, max_depth
            total_elements += 1
            max_depth = max(max_depth, depth)
            
            tag_counts[elem.tag] = tag_counts.get(elem.tag, 0) + 1
            
            for child in elem:
                count_elements(child, depth + 1)
        
        count_elements(root)
        
        # Get file size
        size_bytes = os.path.getsize(file_path)
        
        stats = {
            'file_path': file_path,
            'size_bytes': size_bytes,
            'root_tag': root.tag,
            'total_elements': total_elements,
            'max_depth': max_depth,
            'unique_tags': len(tag_counts),
            'tag_counts': tag_counts,
            'encoding': encoding
        }
        
        logger.debug(f"XML stats: total_elements={total_elements}, max_depth={max_depth}")
        return stats
    except Exception as e:
        logger.error(f"Error getting stats for XML file {file_path}: {str(e)}")
        return f"Error getting stats for XML file {file_path}: {str(e)}"

def compare_xml_data(file_path1: str, file_path2: str, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Compare two XML files and identify differences.

    Args:
        file_path1: Path to the first XML file
        file_path2: Path to the second XML file
        encoding: XML file encoding (default: "utf-8")

    Returns:
        Dictionary with comparison results or error message
    """
    logger.debug(f"Comparing XML files: {file_path1} vs {file_path2}")
    
    # Check if both files exist
    if not os.path.exists(file_path1):
        logger.error(f"First XML file not found: {file_path1}")
        return f"First XML file not found: {file_path1}"
    
    if not os.path.exists(file_path2):
        logger.error(f"Second XML file not found: {file_path2}")
        return f"Second XML file not found: {file_path2}"
    
    try:
        # Read both XML files
        if encoding != "utf-8":
            with open(file_path1, 'r', encoding=encoding) as f:
                content1 = f.read()
            root1 = ET.fromstring(content1)
            
            with open(file_path2, 'r', encoding=encoding) as f:
                content2 = f.read()
            root2 = ET.fromstring(content2)
        else:
            tree1 = ET.parse(file_path1)
            root1 = tree1.getroot()
            
            tree2 = ET.parse(file_path2)
            root2 = tree2.getroot()
        
        # Compare structure
        structure_comparison = {
            'file1_root_tag': root1.tag,
            'file2_root_tag': root2.tag,
            'root_tags_match': root1.tag == root2.tag
        }
        
        # Get element counts for both files
        def get_element_counts(root):
            counts = {}
            for elem in root.iter():
                counts[elem.tag] = counts.get(elem.tag, 0) + 1
            return counts
        
        counts1 = get_element_counts(root1)
        counts2 = get_element_counts(root2)
        
        all_tags = set(counts1.keys()) | set(counts2.keys())
        
        element_comparison = {
            'common_elements': list(set(counts1.keys()) & set(counts2.keys())),
            'unique_to_file1': list(set(counts1.keys()) - set(counts2.keys())),
            'unique_to_file2': list(set(counts2.keys()) - set(counts1.keys())),
            'count_differences': {}
        }
        
        for tag in all_tags:
            count1 = counts1.get(tag, 0)
            count2 = counts2.get(tag, 0)
            if count1 != count2:
                element_comparison['count_differences'][tag] = {
                    'file1_count': count1,
                    'file2_count': count2,
                    'difference': count1 - count2
                }
        
        # Compare content (simplified)
        data1 = _element_to_dict(root1)
        data2 = _element_to_dict(root2)
        content_identical = data1 == data2
        
        result = {
            'file1_path': file_path1,
            'file2_path': file_path2,
            'are_identical': content_identical,
            'structure_comparison': structure_comparison,
            'element_comparison': element_comparison,
            'summary': {
                'structural_match': structure_comparison['root_tags_match'],
                'element_count_differences': len(element_comparison['count_differences']),
                'content_identical': content_identical
            }
        }
        
        logger.debug("XML comparison completed")
        return result
    except ET.ParseError as e:
        logger.error(f"XML parsing error: {str(e)}")
        return f"XML parsing error: {str(e)}"
    except Exception as e:
        logger.error(f"Error comparing XML files: {str(e)}")
        return f"Error comparing XML files: {str(e)}"

def detect_xml_relationships(file_path: str, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Detect relationships and patterns in XML structure.

    Args:
        file_path: Path to the XML file
        encoding: XML file encoding (default: "utf-8")

    Returns:
        Analysis of relationships and patterns in the XML structure
    """
    logger.debug(f"Detecting relationships in XML file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    try:
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            root = ET.fromstring(content)
        else:
            tree = ET.parse(file_path)
            root = tree.getroot()
        
        relationships = {
            'file_path': file_path,
            'root_element': root.tag,
            'element_hierarchy': {},
            'attribute_patterns': {},
            'potential_relationships': [],
            'nesting_patterns': {}
        }
        
        # Analyze element hierarchy
        def analyze_hierarchy(elem, path=""):
            current_path = f"{path}/{elem.tag}" if path else elem.tag
            
            children = {}
            for child in elem:
                child_tag = child.tag
                if child_tag not in children:
                    children[child_tag] = {
                        'count': 0,
                        'has_attributes': False,
                        'has_text': False
                    }
                
                children[child_tag]['count'] += 1
                if child.attrib:
                    children[child_tag]['has_attributes'] = True
                if child.text and child.text.strip():
                    children[child_tag]['has_text'] = True
                
                # Recursively analyze children
                analyze_hierarchy(child, current_path)
            
            if children:
                relationships['element_hierarchy'][current_path] = children
        
        analyze_hierarchy(root)
        
        # Analyze attribute patterns
        attribute_usage = {}
        for elem in root.iter():
            for attr_name in elem.attrib.keys():
                if attr_name not in attribute_usage:
                    attribute_usage[attr_name] = {
                        'elements': set(),
                        'values': set()
                    }
                attribute_usage[attr_name]['elements'].add(elem.tag)
                attribute_usage[attr_name]['values'].add(elem.attrib[attr_name])
        
        # Convert sets to lists for JSON serialization
        for attr_name, info in attribute_usage.items():
            relationships['attribute_patterns'][attr_name] = {
                'used_in_elements': list(info['elements']),
                'unique_values': len(info['values']),
                'sample_values': list(info['values'])[:10]  # First 10 values
            }
        
        # Detect potential ID/reference relationships
        id_attributes = ['id', 'ID', 'ref', 'reference', 'key']
        for attr_name in id_attributes:
            if attr_name in attribute_usage:
                relationships['potential_relationships'].append({
                    'type': 'id_reference',
                    'attribute': attr_name,
                    'description': f"Attribute '{attr_name}' may be used for ID/reference relationships",
                    'elements_using': relationships['attribute_patterns'][attr_name]['used_in_elements']
                })
        
        # Analyze nesting patterns
        def analyze_nesting(elem, depth=0):
            relationships['nesting_patterns'][depth] = relationships['nesting_patterns'].get(depth, 0) + 1
            for child in elem:
                analyze_nesting(child, depth + 1)
        
        analyze_nesting(root)
        
        logger.debug("XML relationship detection completed")
        return relationships
    except ET.ParseError as e:
        logger.error(f"XML parsing error in {file_path}: {str(e)}")
        return f"XML parsing error in {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Error detecting relationships in XML file {file_path}: {str(e)}")
        return f"Error detecting relationships in XML file {file_path}: {str(e)}"
