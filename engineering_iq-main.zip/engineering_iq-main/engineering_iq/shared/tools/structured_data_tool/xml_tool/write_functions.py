"""XML writing and conversion functions."""

import os
import json
import xml.etree.ElementTree as ET
from typing import Dict, Union, Any

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings
from engineering_iq.shared.tools.structured_data_tool.xml_tool.core_functions import read_xml

settings = app_settings
logger = get_logger(__name__)

def write_xml(file_path: str, data: Dict[str, Any], root_tag: str = "root", overwrite: bool = False, encoding: str = "utf-8") -> Dict[str, Union[str, bool]]:
    """
    Write data to an XML file.

    Args:
        file_path: Path to the XML file to write
        data: Dictionary to convert to XML structure
        root_tag: Name of the root element (default: "root")
        overwrite: If True, overwrite the file if it exists (default: False)
        encoding: XML file encoding (default: "utf-8")

    Returns:
        A dictionary indicating success or failure
    """
    logger.debug(f"Writing XML file: {file_path}, root_tag: {root_tag}, overwrite: {overwrite}")
    
    if os.path.exists(file_path) and not overwrite:
        logger.warning(f"XML file {file_path} already exists and overwrite is False.")
        return {'status': 'error', 'message': 'XML file exists and overwrite is False.', 'file_path': file_path}
    
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # Create root element
        root = ET.Element(root_tag)
        
        # Convert dictionary to XML elements
        _dict_to_xml(data, root)
        
        # Create tree and write to file
        tree = ET.ElementTree(root)
        ET.indent(tree, space="  ", level=0)  # Pretty formatting
        tree.write(file_path, encoding=encoding, xml_declaration=True)
        
        logger.info(f"Successfully wrote XML file: {file_path}")
        return {'status': 'success', 'message': 'XML file written successfully.', 'file_path': file_path}
    except Exception as e:
        logger.error(f"Error writing XML file {file_path}: {str(e)}")
        return {'status': 'error', 'message': str(e), 'file_path': file_path}

def _dict_to_xml(data: Any, parent: ET.Element):
    """Convert a dictionary to XML elements."""
    if isinstance(data, dict):
        for key, value in data.items():
            if key.startswith('@'):
                # Handle special keys
                if key == '@attributes' and isinstance(value, dict):
                    for attr_key, attr_value in value.items():
                        parent.set(attr_key, str(attr_value))
                elif key == '@text':
                    parent.text = str(value)
            else:
                if isinstance(value, list):
                    # Multiple elements with same tag
                    for item in value:
                        child = ET.SubElement(parent, key)
                        _dict_to_xml(item, child)
                else:
                    child = ET.SubElement(parent, key)
                    _dict_to_xml(value, child)
    else:
        # Simple value
        parent.text = str(data)

def convert_xml_to_json(xml_path: str, json_path: str, encoding: str = "utf-8") -> Dict[str, Union[str, bool]]:
    """
    Convert an XML file to JSON format.

    Args:
        xml_path: Path to the XML file
        json_path: Path where the JSON file should be saved
        encoding: XML file encoding (default: "utf-8")

    Returns:
        A dictionary indicating success or failure
    """
    logger.debug(f"Converting XML file to JSON: {xml_path} -> {json_path}")
    if not os.path.exists(xml_path):
        logger.error(f"XML file not found: {xml_path}")
        return {'status': 'error', 'message': f'XML file not found: {xml_path}'}
    
    try:
        os.makedirs(os.path.dirname(json_path), exist_ok=True)
        
        # Read XML file
        xml_data = read_xml(xml_path, encoding)
        if isinstance(xml_data, str):  # Error occurred
            return {'status': 'error', 'message': xml_data}
        
        # Write to JSON
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(xml_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Successfully converted XML file to JSON: {xml_path} -> {json_path}")
        return {'status': 'success', 'message': 'XML file converted to JSON successfully.', 'json_path': json_path}
    except Exception as e:
        logger.error(f"Error converting XML file to JSON {xml_path}: {str(e)}")
        return {'status': 'error', 'message': str(e)}
