"""XML query, search, and filtering functions."""

import os
import xml.etree.ElementTree as ET
from typing import Dict, Union, Optional, Any, List

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings
from .core_functions import _element_to_dict

settings = app_settings
logger = get_logger(__name__)

# Try to import lxml for advanced XPath support
try:
    from lxml import etree as lxml_etree
    LXML_AVAILABLE = True
except ImportError:
    LXML_AVAILABLE = False
    logger.warning("lxml not available. Advanced XPath functionality will be limited.")

def query_xml_xpath(file_path: str, xpath_expression: str, encoding: str = "utf-8", 
                    limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
    """
    Query an XML file using XPath expressions with batching support.

    Args:
        file_path: Path to the XML file
        xpath_expression: XPath expression to query
        encoding: XML file encoding (default: "utf-8")
        limit: Maximum number of results to return (None for all)
        offset: Number of results to skip (default: 0)

    Returns:
        Dictionary with query results or error message
    """
    logger.debug(f"Querying XML file: {file_path}, xpath: {xpath_expression}, limit: {limit}, offset: {offset}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    if not xpath_expression:
        logger.error("XPath expression is required")
        return "XPath expression is required"
    
    try:
        if LXML_AVAILABLE:
            # Use lxml for advanced XPath support
            if encoding != "utf-8":
                parser = lxml_etree.XMLParser(encoding=encoding)
                tree = lxml_etree.parse(file_path, parser)
            else:
                tree = lxml_etree.parse(file_path)
            
            xpath_result = tree.xpath(xpath_expression)
            
            results = []
            # Handle different types of XPath results
            if isinstance(xpath_result, (list, tuple)):
                # Multiple elements or nodes
                for elem in xpath_result:
                    if hasattr(elem, 'tag'):  # It's an element
                        results.append({
                            'tag': elem.tag,
                            'attributes': dict(elem.attrib) if elem.attrib else {},
                            'text': elem.text.strip() if elem.text else '',
                            'data': _lxml_element_to_dict(elem)
                        })
                    else:  # It's a text node, attribute, or other value
                        results.append(str(elem))
            else:
                # Single value (count(), sum(), etc.)
                results.append(str(xpath_result))
        else:
            # Fallback to basic ElementTree with limited XPath
            if encoding != "utf-8":
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read()
                root = ET.fromstring(content)
            else:
                tree = ET.parse(file_path)
                root = tree.getroot()
            
            elements = root.findall(xpath_expression)
            results = []
            for elem in elements:
                results.append({
                    'tag': elem.tag,
                    'attributes': elem.attrib,
                    'text': elem.text.strip() if elem.text else '',
                    'data': _element_to_dict(elem)
                })
        
        total_results = len(results)
        
        # Apply batching
        if offset > 0:
            results = results[offset:]
        if limit is not None:
            results = results[:limit]
        
        result = {
            'file_path': file_path,
            'xpath': xpath_expression,
            'results': results,
            'total_results': total_results,
            'returned_count': len(results),
            'offset': offset,
            'limit': limit,
            'xpath_engine': 'lxml' if LXML_AVAILABLE else 'elementtree'
        }
        
        logger.debug(f"XPath query returned {len(results)} results (total: {total_results})")
        return result
    except Exception as e:
        logger.error(f"Error querying XML file {file_path} with XPath {xpath_expression}: {str(e)}")
        return f"Error querying XML file {file_path} with XPath {xpath_expression}: {str(e)}"

def _lxml_element_to_dict(element) -> Dict[str, Any]:
    """Convert an lxml element to a dictionary representation."""
    result = {}
    
    # Add attributes
    if element.attrib:
        result['@attributes'] = dict(element.attrib)
    
    # Add text content
    if element.text and element.text.strip():
        if len(element) == 0:  # No child elements
            return element.text.strip()
        else:
            result['@text'] = element.text.strip()
    
    # Add child elements
    children = {}
    for child in element:
        child_data = _lxml_element_to_dict(child)
        
        if child.tag in children:
            # Convert to list if multiple elements with same tag
            if not isinstance(children[child.tag], list):
                children[child.tag] = [children[child.tag]]
            children[child.tag].append(child_data)
        else:
            children[child.tag] = child_data
    
    result.update(children)
    return result

def list_xml_elements(file_path: str, encoding: str = "utf-8") -> Union[str, List[str]]:
    """
    List all unique element tags in an XML file.

    Args:
        file_path: Path to the XML file
        encoding: XML file encoding (default: "utf-8")

    Returns:
        List of unique element tag names or error message
    """
    logger.debug(f"Listing elements in XML file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    try:
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            root = ET.fromstring(content)
        else:
            tree = ET.parse(file_path)
            root = tree.getroot()
        
        unique_tags = set()
        for elem in root.iter():
            unique_tags.add(elem.tag)
        
        tags = sorted(list(unique_tags))
        logger.debug(f"Found {len(tags)} unique element tags in {file_path}")
        return tags
        
    except ET.ParseError as e:
        logger.error(f"XML parsing error in {file_path}: {str(e)}")
        return f"XML parsing error in {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Error reading XML file {file_path}: {str(e)}")
        return f"Error reading XML file {file_path}: {str(e)}"

def get_xml_element(file_path: str, element_name: str, encoding: str = "utf-8", 
                    limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
    """
    Retrieve all instances of a specific element from XML data with statistics.

    Args:
        file_path: Path to the XML file
        element_name: Name of the element to retrieve
        encoding: XML file encoding (default: "utf-8")
        limit: Maximum number of records to return (None for all)
        offset: Number of records to skip (default: 0)

    Returns:
        Dictionary with element data, statistics, and sample values
    """
    logger.debug(f"Getting element {element_name} from XML file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    try:
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            root = ET.fromstring(content)
        else:
            tree = ET.parse(file_path)
            root = tree.getroot()
        
        # Find all elements with the specified name
        elements = root.findall(f".//{element_name}")
        
        if not elements:
            return f"Element '{element_name}' not found in XML file"
        
        total_count = len(elements)
        
        # Apply batching
        if offset > 0:
            elements = elements[offset:]
        if limit is not None:
            elements = elements[:limit]
        
        # Extract element data
        element_data = []
        text_values = []
        
        for elem in elements:
            elem_info = {
                'tag': elem.tag,
                'attributes': dict(elem.attrib) if elem.attrib else {},
                'text': elem.text.strip() if elem.text else '',
                'data': _element_to_dict(elem)
            }
            element_data.append(elem_info)
            if elem.text and elem.text.strip():
                text_values.append(elem.text.strip())
        
        # Calculate statistics
        stats = {
            'total_count': total_count,
            'returned_count': len(element_data),
            'elements_with_text': len(text_values),
            'unique_text_values': len(set(text_values)) if text_values else 0,
            'offset': offset,
            'limit': limit
        }
        
        # Attribute analysis
        all_attributes = set()
        for elem_info in element_data:
            all_attributes.update(elem_info['attributes'].keys())
        stats['common_attributes'] = list(all_attributes)
        
        result = {
            'file_path': file_path,
            'element_name': element_name,
            'elements': element_data,
            'statistics': stats,
            'sample_text_values': text_values[:10]  # First 10 text values as samples
        }
        
        logger.debug(f"Retrieved {len(element_data)} instances of element {element_name}")
        return result
    except ET.ParseError as e:
        logger.error(f"XML parsing error in {file_path}: {str(e)}")
        return f"XML parsing error in {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Error getting element from XML file {file_path}: {str(e)}")
        return f"Error getting element from XML file {file_path}: {str(e)}"

def find_elements_by_tag(file_path: str, tag_name: str, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Find all elements with a specific tag name in an XML file.

    Args:
        file_path: Path to the XML file
        tag_name: Name of the tag to find
        encoding: XML file encoding (default: "utf-8")

    Returns:
        Dictionary with found elements or error message
    """
    logger.debug(f"Finding elements by tag in XML file: {file_path}, tag: {tag_name}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    try:
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            root = ET.fromstring(content)
        else:
            tree = ET.parse(file_path)
            root = tree.getroot()
        
        elements = root.findall(f".//{tag_name}")
        results = []
        
        for elem in elements:
            results.append({
                'tag': elem.tag,
                'attributes': elem.attrib,
                'text': elem.text.strip() if elem.text else '',
                'data': _element_to_dict(elem),
                'path': _get_element_path(root, elem)
            })
        
        result = {
            'file_path': file_path,
            'tag_name': tag_name,
            'results': results,
            'count': len(results)
        }
        
        logger.debug(f"Found {len(results)} elements with tag '{tag_name}'")
        return result
    except Exception as e:
        logger.error(f"Error finding elements by tag in XML file {file_path}: {str(e)}")
        return f"Error finding elements by tag in XML file {file_path}: {str(e)}"

def _get_element_path(root: ET.Element, target: ET.Element) -> str:
    """Get the XPath-like path to an element."""
    if root == target:
        return f"/{root.tag}"
    
    for elem in root.iter():
        if elem == target:
            path_parts = []
            current = target
            
            # This is a simplified path - a full implementation would need parent tracking
            path_parts.append(current.tag)
            return f"//{'/'.join(reversed(path_parts))}"
    
    return "//unknown"

def filter_xml_by_attribute(file_path: str, attribute_name: str, attribute_value: str, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Filter XML elements based on a single attribute value.

    Args:
        file_path: Path to the XML file
        attribute_name: Name of the attribute to filter by
        attribute_value: Value to match for the attribute
        encoding: XML file encoding (default: "utf-8")

    Returns:
        Dictionary with filtered elements or error message
    """
    logger.debug(f"Filtering XML by attribute: {file_path}, {attribute_name}={attribute_value}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    if not attribute_name:
        logger.error("Attribute name is required")
        return "Attribute name is required"
    
    try:
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            root = ET.fromstring(content)
        else:
            tree = ET.parse(file_path)
            root = tree.getroot()
        
        results = []
        for elem in root.iter():
            if elem.get(attribute_name) == attribute_value:
                results.append({
                    'tag': elem.tag,
                    'attributes': elem.attrib,
                    'text': elem.text.strip() if elem.text else '',
                    'data': _element_to_dict(elem)
                })
        
        result = {
            'file_path': file_path,
            'attribute_name': attribute_name,
            'attribute_value': attribute_value,
            'results': results,
            'count': len(results)
        }
        
        logger.debug(f"Attribute filter returned {len(results)} elements")
        return result
    except Exception as e:
        logger.error(f"Error filtering XML by attribute {file_path}: {str(e)}")
        return f"Error filtering XML by attribute {file_path}: {str(e)}"

def extract_text_content(file_path: str, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Extract all text content from an XML file.

    Args:
        file_path: Path to the XML file
        encoding: XML file encoding (default: "utf-8")

    Returns:
        Dictionary with extracted text or error message
    """
    logger.debug(f"Extracting text content from XML file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    try:
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            root = ET.fromstring(content)
        else:
            tree = ET.parse(file_path)
            root = tree.getroot()
        
        text_content = []
        for elem in root.iter():
            if elem.text and elem.text.strip():
                text_content.append({
                    'tag': elem.tag,
                    'text': elem.text.strip(),
                    'attributes': elem.attrib
                })
        
        result = {
            'file_path': file_path,
            'text_elements': text_content,
            'count': len(text_content),
            'all_text': ' '.join([item['text'] for item in text_content])
        }
        
        logger.debug(f"Extracted text from {len(text_content)} elements")
        return result
    except Exception as e:
        logger.error(f"Error extracting text from XML file {file_path}: {str(e)}")
        return f"Error extracting text from XML file {file_path}: {str(e)}"
