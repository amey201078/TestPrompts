"""Core XML reading and parsing functions."""

import os
import xml.etree.ElementTree as ET
from typing import Dict, Union, Optional, Any

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings

settings = app_settings
logger = get_logger(__name__)

def read_xml(file_path: str, encoding: str = "utf-8", limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
    """
    Read an XML file and return its content as a structured dictionary with batching support.

    Args:
        file_path: Path to the XML file
        encoding: XML file encoding (default: "utf-8")
        limit: Maximum number of child elements to return (None for all)
        offset: Number of child elements to skip (default: 0)

    Returns:
        Dictionary with XML structure or error message if the file doesn't exist or can't be read
    """
    logger.debug(f"Reading XML file: {file_path}, encoding: {encoding}, limit: {limit}, offset: {offset}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    try:
        # Parse the XML file
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            root = ET.fromstring(content)
        else:
            tree = ET.parse(file_path)
            root = tree.getroot()
        
        # Convert to dictionary with potential batching
        data = _element_to_dict_with_batching(root, limit, offset)
        
        result = {
            'root_tag': root.tag,
            'root_attributes': root.attrib,
            'data': data,
            'file_path': file_path,
            'encoding': encoding,
            'limit': limit,
            'offset': offset
        }
        
        logger.debug(f"Successfully read XML file: {file_path}")
        return result
    except ET.ParseError as e:
        logger.error(f"XML parsing error in {file_path}: {str(e)}")
        return f"XML parsing error in {file_path}: {str(e)}"
    except Exception as e:
        logger.error(f"Error reading XML file {file_path}: {str(e)}")
        return f"Error reading XML file {file_path}: {str(e)}"

def _element_to_dict(element: ET.Element) -> Dict[str, Any]:
    """Convert an XML element to a dictionary representation."""
    result = {}
    
    # Add attributes
    if element.attrib:
        result['@attributes'] = element.attrib
    
    # Add text content
    if element.text and element.text.strip():
        if len(element) == 0:  # No child elements
            return element.text.strip()
        else:
            result['@text'] = element.text.strip()
    
    # Add child elements
    children = {}
    for child in element:
        child_data = _element_to_dict(child)
        
        if child.tag in children:
            # Convert to list if multiple elements with same tag
            if not isinstance(children[child.tag], list):
                children[child.tag] = [children[child.tag]]
            children[child.tag].append(child_data)
        else:
            children[child.tag] = child_data
    
    result.update(children)
    return result

def _element_to_dict_with_batching(element: ET.Element, limit: Optional[int] = None, offset: int = 0) -> Dict[str, Any]:
    """Convert an XML element to a dictionary representation with batching support for child elements."""
    result = {}
    
    # Add attributes
    if element.attrib:
        result['@attributes'] = element.attrib
    
    # Add text content
    if element.text and element.text.strip():
        if len(element) == 0:  # No child elements
            return element.text.strip()
        else:
            result['@text'] = element.text.strip()
    
    # Add child elements with batching
    children = {}
    child_list = list(element)
    total_children = len(child_list)
    
    # Apply batching to children
    if offset > 0:
        child_list = child_list[offset:]
    if limit is not None:
        child_list = child_list[:limit]
    
    for child in child_list:
        child_data = _element_to_dict(child)
        
        if child.tag in children:
            # Convert to list if multiple elements with same tag
            if not isinstance(children[child.tag], list):
                children[child.tag] = [children[child.tag]]
            children[child.tag].append(child_data)
        else:
            children[child.tag] = child_data
    
    result.update(children)
    
    # Add batching metadata if applicable
    if limit is not None or offset > 0:
        result['@batching_info'] = {
            'total_children': total_children,
            'returned_children': len(child_list),
            'offset': offset,
            'limit': limit
        }
    
    return result

def get_xml_structure(file_path: str, max_depth: int = 10, encoding: str = "utf-8") -> Union[str, Dict[str, Any]]:
    """
    Get the structure of an XML file including element hierarchy and attributes.

    Args:
        file_path: Path to the XML file
        max_depth: Maximum depth to traverse (default: 10)
        encoding: XML file encoding (default: "utf-8")

    Returns:
        Dictionary with XML structure information or error message
    """
    logger.debug(f"Getting structure for XML file: {file_path}, max_depth: {max_depth}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return f"XML file not found: {file_path}"
    
    try:
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            root = ET.fromstring(content)
        else:
            tree = ET.parse(file_path)
            root = tree.getroot()
        
        structure = _get_element_structure(root, max_depth, 0)
        
        result = {
            'file_path': file_path,
            'root_tag': root.tag,
            'root_attributes': root.attrib,
            'structure': structure,
            'encoding': encoding
        }
        
        logger.debug(f"Generated structure for XML file: {file_path}")
        return result
    except Exception as e:
        logger.error(f"Error getting structure for XML file {file_path}: {str(e)}")
        return f"Error getting structure for XML file {file_path}: {str(e)}"

def _get_element_structure(element: ET.Element, max_depth: int, current_depth: int) -> Dict[str, Any]:
    """Get the structure of an XML element."""
    if current_depth >= max_depth:
        return {'tag': element.tag, 'truncated': True}
    
    structure = {
        'tag': element.tag,
        'attributes': list(element.attrib.keys()) if element.attrib else [],
        'has_text': bool(element.text and element.text.strip()),
        'children': {}
    }
    
    # Count children by tag name
    child_counts = {}
    for child in element:
        child_counts[child.tag] = child_counts.get(child.tag, 0) + 1
    
    # Get structure of unique children
    processed_tags = set()
    for child in element:
        if child.tag not in processed_tags:
            structure['children'][child.tag] = {
                'count': child_counts[child.tag],
                'structure': _get_element_structure(child, max_depth, current_depth + 1)
            }
            processed_tags.add(child.tag)
    
    return structure

def validate_xml(file_path: str, encoding: str = "utf-8") -> Dict[str, Union[str, bool]]:
    """
    Validate an XML file for well-formedness.

    Args:
        file_path: Path to the XML file
        encoding: XML file encoding (default: "utf-8")

    Returns:
        A dictionary indicating validation results
    """
    logger.debug(f"Validating XML file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"XML file not found: {file_path}")
        return {'status': 'error', 'message': f'XML file not found: {file_path}', 'valid': False}
    
    try:
        if encoding != "utf-8":
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            ET.fromstring(content)
        else:
            ET.parse(file_path)
        
        logger.debug(f"XML file is valid: {file_path}")
        return {'status': 'success', 'message': 'XML file is well-formed.', 'valid': True, 'file_path': file_path}
    except ET.ParseError as e:
        logger.error(f"XML validation error in {file_path}: {str(e)}")
        return {'status': 'error', 'message': f'XML parsing error: {str(e)}', 'valid': False, 'file_path': file_path}
    except Exception as e:
        logger.error(f"Error validating XML file {file_path}: {str(e)}")
        return {'status': 'error', 'message': str(e), 'valid': False, 'file_path': file_path}
