"""Tool wrappers for structured data functions."""

from google.genai import types
from google.adk.tools import FunctionTool, ToolContext
from google.adk.models import LlmRequest
from typing_extensions import override
import json

from engineering_iq.shared.tools.structured_data_tool.structured_data_impl import StructuredData, PROVIDER_MAPPINGS

# Create a shared instance
_structured_data = StructuredData()

# Centralized format support information
def _get_format_support_instructions() -> str:
    """Get centralized format support instructions for all tools."""
    json_formats = [ext for ext, provider in PROVIDER_MAPPINGS.items() if provider == 'json']
    xml_formats = [ext for ext, provider in PROVIDER_MAPPINGS.items() if provider == 'xml']
    excel_formats = [ext for ext, provider in PROVIDER_MAPPINGS.items() if provider == 'excel']
    
    return f"""
**COMPREHENSIVE FORMAT SUPPORT:**
- **JSON**: {', '.join(f'.{ext}' for ext in sorted(json_formats))}
- **XML**: {', '.join(f'.{ext}' for ext in sorted(xml_formats))}
- **Excel**: {', '.join(f'.{ext}' for ext in sorted(excel_formats))}
- **Content Detection**: Automatically detects format for unknown extensions

**CONTAINERS BY FORMAT:**
- **JSON**: Use 'container' for top-level keys (e.g., container="users")
- **XML/XML variants**: Use 'container' for namespaces/elements (optional)
- **Excel/Spreadsheets**: Use 'container' for sheet names (e.g., container="Sales_Q4")
"""

class StructuredDataReadTool(FunctionTool):
    """Read structured data from files (JSON, XML, Excel) with batching support"""
    
    def __init__(self):
        super().__init__(_structured_data.fetch_structured_data)

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        format_instructions = _get_format_support_instructions()
        llm_request.append_instructions([f"""
#### TOOL: Fetch Structured Data
You have a fetch_structured_data tool that supports JSON, XML, and Excel files with intelligent features:
{format_instructions}
**BATCHING FOR TOKEN EFFICIENCY:**
- Use 'limit' and 'offset' for large files to prevent token overflow
- Example: limit=10, offset=0 (first 10 records)
- Always start with small limits for unknown file sizes

**BEST PRACTICES:**
1. List containers first: use list_containers() to see available sheets/keys
2. Get structure first: use get_structure() to understand data layout
3. Use batching for large datasets to stay within token limits
4. Specify container (sheet name) for Excel files
"""])

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the structured data file (JSON, XML, Excel)"
                    ),
                    'encoding': types.Schema(
                        type=types.Type.STRING,
                        description="File encoding (default: utf-8)"
                    ),
                    'container': types.Schema(
                        type=types.Type.STRING,
                        description="Optional container identifier (e.g., Excel sheet name)"
                    ),
                    'limit': types.Schema(
                        type=types.Type.INTEGER,
                        description="Maximum number of records to return (None for all)"
                    ),
                    'offset': types.Schema(
                        type=types.Type.INTEGER,
                        description="Number of records to skip (default: 0)"
                    )
                },
                required=["file_path"]
            ),
        )

class StructuredDataWriteTool(FunctionTool):
    """Write data to structured data files (JSON, XML, Excel)"""
    
    def __init__(self):
        super().__init__(_structured_data.write_structured_data)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the structured data file to write"
                    ),
                    'data': types.Schema(
                        type=types.Type.STRING,
                        description="Data to write (as JSON string)"
                    ),
                    'encoding': types.Schema(
                        type=types.Type.STRING,
                        description="File encoding (default: utf-8)"
                    ),
                    'container': types.Schema(
                        type=types.Type.STRING,
                        description="Optional container identifier (e.g., Excel sheet name)"
                    )
                },
                required=["file_path", "data"]
            ),
        )

class StructuredDataQueryTool(FunctionTool):
    """Query structured data using format-specific languages (JSONPath, XPath, Excel ranges)"""
    
    def __init__(self):
        super().__init__(_structured_data.query_structured_data)

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        format_instructions = _get_format_support_instructions()
        llm_request.append_instructions([f"""
#### TOOL: Query Structured Data
You have a query_structured_data tool that supports format-specific query languages:
{format_instructions}
**QUERY LANGUAGES BY FORMAT:**
- **JSON**: Use JSONPath expressions (e.g., "$.users[*].name", "$..email")
- **XML**: Use XPath expressions (e.g., "//customer[@id='123']", ".//name")
- **Excel**: Use range expressions (e.g., "A1:C10", "B:B" for entire column)

**BATCHING & CONTAINERS:**
- Use 'limit' and 'offset' for large result sets
- Use 'container' to specify Excel sheet or JSON top-level key
- Always start with small limits to avoid token overflow

**EXAMPLES:**
- JSON: query_expression="$.products[?(@.price > 100)]"
- XML: query_expression="//order[status='shipped']"
- Excel: query_expression="A1:E100", container="Sales_Data"
"""])

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the structured data file"
                    ),
                    'query_expression': types.Schema(
                        type=types.Type.STRING,
                        description="Query expression (JSONPath for JSON, XPath for XML, range for Excel)"
                    ),
                    'encoding': types.Schema(
                        type=types.Type.STRING,
                        description="File encoding (default: utf-8)"
                    ),
                    'container': types.Schema(
                        type=types.Type.STRING,
                        description="Optional container identifier (e.g., Excel sheet name)"
                    ),
                    'limit': types.Schema(
                        type=types.Type.INTEGER,
                        description="Maximum number of records to return (None for all)"
                    ),
                    'offset': types.Schema(
                        type=types.Type.INTEGER,
                        description="Number of records to skip (default: 0)"
                    )
                },
                required=["file_path", "query_expression"]
            ),
        )

class StructuredDataStructureTool(FunctionTool):
    """Get structure/schema information from structured data files"""
    
    def __init__(self):
        super().__init__(_structured_data.get_structure)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the structured data file"
                    ),
                    'encoding': types.Schema(
                        type=types.Type.STRING,
                        description="File encoding (default: utf-8)"
                    ),
                    'container': types.Schema(
                        type=types.Type.STRING,
                        description="Optional container identifier (e.g., Excel sheet name)"
                    )
                },
                required=["file_path"]
            ),
        )

class StructuredDataStatsTool(FunctionTool):
    """Get statistics about structured data files"""
    
    def __init__(self):
        super().__init__(_structured_data.get_stats_from_structured)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the structured data file"
                    ),
                    'encoding': types.Schema(
                        type=types.Type.STRING,
                        description="File encoding (default: utf-8)"
                    ),
                    'container': types.Schema(
                        type=types.Type.STRING,
                        description="Optional container identifier (e.g., Excel sheet name)"
                    )
                },
                required=["file_path"]
            ),
        )

class StructuredDataListContainersTool(FunctionTool):
    """List available containers in structured data files (Excel sheets, etc.)"""
    
    def __init__(self):
        super().__init__(_structured_data.list_containers)

    @override
    async def process_llm_request(self, *, tool_context: ToolContext, llm_request: LlmRequest) -> None:
        await super().process_llm_request(tool_context=tool_context, llm_request=llm_request)
        llm_request.append_instructions(["""
#### TOOL: List Containers in Structured Data
You have a list_containers tool that shows available containers in structured data files:

**WHAT CONTAINERS ARE:**
- **Excel**: Sheet names (e.g., "Sales_Q4", "Inventory", "Summary")
- **JSON**: Top-level keys (e.g., "users", "products", "orders")
- **XML**: Unique element tags (e.g., "customer", "order", "product")

**WHEN TO USE:**
- Always use this FIRST when working with Excel files to see available sheets
- Use with JSON files that have multiple top-level sections
- Use with XML files to understand the structure

**WORKFLOW:**
1. List containers to see what's available
2. Choose the appropriate container for your task
3. Use other tools with the container parameter
"""])

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the structured data file"
                    ),
                    'encoding': types.Schema(
                        type=types.Type.STRING,
                        description="File encoding (default: utf-8)"
                    )
                },
                required=["file_path"]
            ),
        )

class StructuredDataGetColumnTool(FunctionTool):
    """Get specific column/field data with statistics from structured data"""
    
    def __init__(self):
        super().__init__(_structured_data.get_container_column)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the structured data file"
                    ),
                    'column_name': types.Schema(
                        type=types.Type.STRING,
                        description="Name of the column/field to retrieve"
                    ),
                    'encoding': types.Schema(
                        type=types.Type.STRING,
                        description="File encoding (default: utf-8)"
                    ),
                    'container': types.Schema(
                        type=types.Type.STRING,
                        description="Optional container identifier (e.g., Excel sheet name)"
                    ),
                    'limit': types.Schema(
                        type=types.Type.INTEGER,
                        description="Maximum number of records to return (None for all)"
                    ),
                    'offset': types.Schema(
                        type=types.Type.INTEGER,
                        description="Number of records to skip (default: 0)"
                    )
                },
                required=["file_path", "column_name"]
            ),
        )

class StructuredDataCompareTool(FunctionTool):
    """Compare two structured data files and identify differences"""
    
    def __init__(self):
        super().__init__(_structured_data.compare_structured_data)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path1': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the first structured data file"
                    ),
                    'file_path2': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the second structured data file"
                    ),
                    'encoding': types.Schema(
                        type=types.Type.STRING,
                        description="File encoding (default: utf-8)"
                    ),
                    'container1': types.Schema(
                        type=types.Type.STRING,
                        description="Container in first file (e.g., Excel sheet name)"
                    ),
                    'container2': types.Schema(
                        type=types.Type.STRING,
                        description="Container in second file (e.g., Excel sheet name)"
                    )
                },
                required=["file_path1", "file_path2"]
            ),
        )

class StructuredDataDetectRelationshipsTool(FunctionTool):
    """Detect relationships and correlations in structured data"""
    
    def __init__(self):
        super().__init__(_structured_data.detect_relationships)

    @override
    def _get_declaration(self) -> types.FunctionDeclaration | None:
        return types.FunctionDeclaration(
            name=self.name,
            description=self.description,
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    'file_path': types.Schema(
                        type=types.Type.STRING,
                        description="Path to the structured data file"
                    ),
                    'encoding': types.Schema(
                        type=types.Type.STRING,
                        description="File encoding (default: utf-8)"
                    ),
                    'container': types.Schema(
                        type=types.Type.STRING,
                        description="Optional container identifier (e.g., Excel sheet name)"
                    )
                },
                required=["file_path"]
            ),
        )

# Create tool instances
structured_data_read_tool = StructuredDataReadTool()
structured_data_write_tool = StructuredDataWriteTool()
structured_data_query_tool = StructuredDataQueryTool()
structured_data_structure_tool = StructuredDataStructureTool()
structured_data_stats_tool = StructuredDataStatsTool()
structured_data_list_containers_tool = StructuredDataListContainersTool()
structured_data_get_column_tool = StructuredDataGetColumnTool()
structured_data_compare_tool = StructuredDataCompareTool()
structured_data_detect_relationships_tool = StructuredDataDetectRelationshipsTool()

# Collection of all structured data tools
structured_data_tools = [
    structured_data_read_tool,
    structured_data_write_tool,
    structured_data_query_tool,
    structured_data_structure_tool,
    structured_data_stats_tool,
    structured_data_list_containers_tool,
    structured_data_get_column_tool,
    structured_data_compare_tool,
    structured_data_detect_relationships_tool
]

# Collection by category
read_tools = [
    structured_data_read_tool,
    structured_data_query_tool,
    structured_data_structure_tool,
    structured_data_stats_tool,
    structured_data_list_containers_tool,
    structured_data_get_column_tool
]

write_tools = [
    structured_data_write_tool
]

analysis_tools = [
    structured_data_compare_tool,
    structured_data_detect_relationships_tool
]
