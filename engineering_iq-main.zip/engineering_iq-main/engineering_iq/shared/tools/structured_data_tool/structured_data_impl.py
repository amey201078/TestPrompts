from typing import Any, Optional, List, Dict, Union
from google.adk.tools.base_toolset import BaseToolset
from google.adk.agents.readonly_context import ReadonlyContext

from engineering_iq.shared.tools.structured_data_tool.structured_data_provider import StructuredDataProvider
from engineering_iq.shared.tools.structured_data_tool.json_tool.json_provider import JsonProvider
from engineering_iq.shared.tools.structured_data_tool.xml_tool.xml_provider import XmlProvider
from engineering_iq.shared.tools.structured_data_tool.excel_tool.excel_provider import ExcelProvider

# Provider registry with comprehensive format support
PROVIDER_MAPPINGS = {
    # JSON and JSON-like formats
    'json': 'json',
    'jsonl': 'json',  # JSON Lines
    'ndjson': 'json',  # Newline Delimited JSON
    'geojson': 'json',  # Geographic JSON
    'topojson': 'json',  # Topological JSON
    
    # XML and XML-like formats
    'xml': 'xml',
    'dxl': 'xml',  # IBM DOORS XML export
    'xsd': 'xml',  # XML Schema Definition
    'xsl': 'xml',  # XSL Stylesheets
    'xslt': 'xml',  # XSL Transformations
    'soap': 'xml',  # SOAP messages
    'wsdl': 'xml',  # Web Services Description Language
    'rss': 'xml',  # RSS feeds
    'atom': 'xml',  # Atom feeds
    'svg': 'xml',  # Scalable Vector Graphics
    'kml': 'xml',  # Keyhole Markup Language
    'gpx': 'xml',  # GPS Exchange Format
    'xhtml': 'xml',  # XHTML documents
    'config': 'xml',  # Configuration files (often XML)
    'plist': 'xml',  # Apple Property Lists
    'xaml': 'xml',  # Extensible Application Markup Language
    'resx': 'xml',  # .NET Resource files
    'manifest': 'xml',  # Android manifests, etc.
    'dxl': 'xml',  # IBM DOORS XML export
    'opml': 'xml',  # Outline Processor Markup Language
    'sitemap': 'xml',  # XML sitemaps
    'xbrl': 'xml',  # eXtensible Business Reporting Language
    
    # Excel and spreadsheet formats
    'xlsx': 'excel',
    'xls': 'excel',
    'xlsm': 'excel',  # Excel with macros
    'xlsb': 'excel',  # Excel binary format
    'xltx': 'excel',  # Excel template
    'xltm': 'excel',  # Excel template with macros
}

# Provider instances
_PROVIDERS = {
    'json': JsonProvider(),
    'xml': XmlProvider(),
    'excel': ExcelProvider(),
}

class StructuredData(StructuredDataProvider):
    """
        Structured data toolset for reading, writing, and querying structured data formats:
        - JSON
        - XML
        - Excel (xlsx, xls)
    """

    def fetch_structured_data(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None,
             limit: Optional[int] = None, offset: int = 0) -> str:
        """Read structured data from a file with batching support.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)
        """
        provider = self.get_provider(file_path)
        return provider.fetch_structured_data(file_path, encoding, container, limit, offset)
    
    def write_structured_data(self, file_path: str, data: Any, encoding: str = "utf-8", container: Optional[str] = None) -> str:
        """Write structured data to a file.
        
        Args:
            file_path: Path to the data file
            data: Data to write
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
        """
        provider = self.get_provider(file_path)
        return provider.write_structured_data(file_path, data, encoding, container)
    
    def query_structured_data(self, file_path: str, query_expression: str, encoding: str = "utf-8", container: Optional[str] = None,
              limit: Optional[int] = None, offset: int = 0) -> str:
        """Query structured data using format-specific query language with batching support.
        
        Args:
            file_path: Path to the data file
            query_expression: Query expression in format-specific language
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)
        """
        provider = self.get_provider(file_path)
        return provider.query_structured_data(file_path, query_expression, encoding, container, limit, offset)
    
    def get_structure(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None) -> str:
        """Get structure/schema of the data.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
        """
        provider = self.get_provider(file_path)
        return provider.get_structure(file_path, encoding, container)
    
    def get_stats_from_structured(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None) -> dict:
        """Get statistics about the data.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
        """
        provider = self.get_provider(file_path)
        return provider.get_stats_from_structured(file_path, encoding, container)

    def list_containers(self, file_path: str, encoding: str = "utf-8") -> Union[str, List[str]]:
        """List all available containers in the data source.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            
        Returns:
            List of container names (e.g., Excel sheet names, database table names) or error message
        """
        provider = self.get_provider(file_path)
        return provider.list_containers(file_path, encoding)

    def get_container_column(self, file_path: str, column_name: str, encoding: str = "utf-8", 
                            container: Optional[str] = None, limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
        """Retrieve a specific column from a container in the data source.
        
        Args:
            file_path: Path to the data file
            column_name: Name of the column to analyze
            encoding: File encoding (default: utf-8)
            container: Optional container identifier
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)

        Returns:
            Data from the specified column, including type, statistics, and sample values.
            If the column does not exist, an error message is returned.
        """
        provider = self.get_provider(file_path)
        return provider.get_container_column(file_path, column_name, encoding, container, limit, offset)

    def compare_structured_data(self, file_path1: str, file_path2: str, encoding: str = "utf-8",
                    container1: Optional[str] = None, container2: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Compare two data sources and identify differences.
        
        Args:
            file_path1: Path to first data file
            file_path2: Path to second data file
            encoding: File encoding (default: utf-8)
            container1: Container in first file
            container2: Container in second file
            
        Returns:
            Comparison report showing differences in structure, content, statistics
        """
        provider1 = self.get_provider(file_path1)
        return provider1.compare_structured_data(file_path1, file_path2, encoding, container1, container2)

    def detect_relationships(self, file_path: str, encoding: str = "utf-8", 
                           container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Detect relationships and correlations between columns/fields.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            container: Optional container identifier
            
        Returns:
            Analysis of correlations, dependencies, and potential relationships between fields
        """
        provider = self.get_provider(file_path)
        return provider.detect_relationships(file_path, encoding, container)
    
    def get_provider(self, file_path: str) -> StructuredDataProvider:
        """Get provider for specific data type based on file extension with comprehensive format support."""
        import os
        
        file_extension = os.path.splitext(file_path)[1].lower().lstrip('.')
        
        # Map file extension to provider type
        provider_type = PROVIDER_MAPPINGS.get(file_extension)
        
        if provider_type:
            provider = _PROVIDERS.get(provider_type)
            if provider:
                return provider
        
        # Fallback: Content-based detection for unknown extensions or extensionless files
        if not provider_type:
            provider_type = self._detect_format_by_content(file_path)
            if provider_type:
                provider = _PROVIDERS.get(provider_type)
                if provider:
                    return provider
        
        # If still no provider found, list available formats
        supported_extensions = ', '.join(sorted(PROVIDER_MAPPINGS.keys()))
        supported_types = ', '.join(sorted(_PROVIDERS.keys()))
        raise ValueError(
            f"Unsupported file extension: '.{file_extension}' for file '{file_path}'. "
            f"Supported extensions: {supported_extensions}. "
            f"Supported types: {supported_types}. "
            f"Content-based detection was also attempted."
        )
    
    def _detect_format_by_content(self, file_path: str) -> Optional[str]:
        """Detect file format by examining content for files with unknown extensions."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                # Read first few lines to detect format
                first_lines = [f.readline().strip() for _ in range(5)]
                content_start = ''.join(first_lines)
                
            # JSON detection
            if content_start.startswith(('{', '[')) or any('"' in line and ':' in line for line in first_lines):
                return 'json'
            
            # XML detection (including XML variants)
            if (content_start.startswith('<?xml') or 
                content_start.startswith('<') or 
                any(line.strip().startswith('<') and line.strip().endswith('>') for line in first_lines)):
                return 'xml'
                
        except Exception:
            # If content detection fails, return None
            pass
        
        # Try binary content detection for Excel files
        try:
            with open(file_path, 'rb') as f:
                header = f.read(8)
                
            # Excel file signatures
            if header.startswith(b'PK\x03\x04'):  # XLSX/XLSM (ZIP-based)
                return 'excel'
            elif header.startswith(b'\xd0\xcf\x11\xe0'):  # XLS (OLE2)
                return 'excel'
                
        except Exception:
            pass
            
        return None
