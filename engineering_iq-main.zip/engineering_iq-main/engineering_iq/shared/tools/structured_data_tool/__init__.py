"""Structured Data Tool Package

A comprehensive toolset for reading, writing, and analyzing structured data files:
- JSON files with JSONPath queries
- XML files with XPath queries  
- Excel files (xlsx, xls) with sheet and range support

Features:
- Container support (Excel sheets, JSON keys, XML namespaces)
- Batching for large datasets (limit/offset)
- Advanced analysis (statistics, comparisons, relationship detection)
- Token-efficient operations for AI agents
"""

# Main toolset classes
from .structured_data_tool import (
    StructuredDataTool,
    StructuredDataReadTool,
    StructuredDataWriteTool,
    StructuredDataAnalysisTool
)

# Individual tool instances for fine-grained access
from .structured_data_tools import (
    structured_data_tools,
    read_tools,
    write_tools,
    analysis_tools,
    structured_data_read_tool,
    structured_data_write_tool,
    structured_data_query_tool,
    structured_data_structure_tool,
    structured_data_stats_tool,
    structured_data_list_containers_tool,
    structured_data_get_column_tool,
    structured_data_compare_tool,
    structured_data_detect_relationships_tool
)

# Implementation class for direct usage
from .structured_data_impl import StructuredData

# Provider classes for advanced usage
from .structured_data_provider import StructuredDataProvider
from .json_tool.json_provider import JsonProvider
from .xml_tool.xml_provider import XmlProvider
from .excel_tool.excel_provider import ExcelProvider

__all__ = [
    # Main toolset classes (recommended for agents)
    'StructuredDataTool',
    'StructuredDataReadTool', 
    'StructuredDataWriteTool',
    'StructuredDataAnalysisTool',
    
    # Tool collections
    'structured_data_tools',
    'read_tools',
    'write_tools', 
    'analysis_tools',
    
    # Individual tools
    'structured_data_read_tool',
    'structured_data_write_tool',
    'structured_data_query_tool',
    'structured_data_structure_tool',
    'structured_data_stats_tool',
    'structured_data_list_containers_tool',
    'structured_data_get_column_tool',
    'structured_data_compare_tool',
    'structured_data_detect_relationships_tool',
    
    # Implementation and providers
    'StructuredData',
    'StructuredDataProvider',
    'JsonProvider',
    'XmlProvider', 
    'ExcelProvider'
]
