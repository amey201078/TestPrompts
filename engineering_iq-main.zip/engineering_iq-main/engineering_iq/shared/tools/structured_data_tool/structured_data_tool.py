"""Structured Data Tool - BaseToolset for reading, writing, and analyzing structured data files."""

from typing import Optional
from google.adk.tools.base_toolset import BaseToolset
from google.adk.tools.base_tool import BaseTool
from google.adk.agents.readonly_context import ReadonlyContext

from engineering_iq.shared.tools.structured_data_tool.structured_data_tools import (
    structured_data_tools,
    read_tools,
    write_tools,
    analysis_tools
)

class StructuredDataTool(BaseToolset):
    """
    Structured data toolset for reading, writing, and querying structured data formats:
    - JSON files with JSONPath queries
    - XML files with XPath queries  
    - Excel files (xlsx, xls) with sheet and range support
    
    Features:
    - Container support (Excel sheets, JSON keys, XML namespaces)
    - Batching for large datasets (limit/offset)
    - Advanced analysis (statistics, comparisons, relationship detection)
    - Token-efficient operations for AI agents
    """

    async def get_tools(self, readonly_context: Optional[ReadonlyContext] = None) -> list[BaseTool]:
        """
        Get the structured data tools for reading, writing, and analysis.
        """
        return structured_data_tools
    
    async def close(self) -> None:
        """
        Close the toolset and release resources.
        """

class StructuredDataReadTool(BaseToolset):
    """
    Read-only structured data operations for efficient data access:
    - Reading with batching support
    - Querying with format-specific languages
    - Structure and statistics analysis
    - Container discovery and column analysis
    """

    async def get_tools(self, readonly_context: Optional[ReadonlyContext] = None) -> list[BaseTool]:
        """
        Get the structured data read tools for reading, querying, and analyzing structured data.
        """
        return read_tools
    
    async def close(self) -> None:
        """
        Close the read toolset and release resources.
        """

class StructuredDataWriteTool(BaseToolset):
    """
    Write operations for structured data files:
    - Writing to JSON, XML, and Excel formats
    - Container-specific writes (e.g., specific Excel sheets)
    """

    async def get_tools(self, readonly_context: Optional[ReadonlyContext] = None) -> list[BaseTool]:
        """
        Get the structured data write tools for writing structured data files.
        """
        return write_tools
    
    async def close(self) -> None:
        """
        Close the write toolset and release resources.
        """

class StructuredDataAnalysisTool(BaseToolset):
    """
    Advanced analysis operations for structured data:
    - File comparison and difference detection
    - Relationship and correlation analysis
    """

    async def get_tools(self, readonly_context: Optional[ReadonlyContext] = None) -> list[BaseTool]:
        """
        Get the structured data analysis tools for advanced data analysis operations.
        """
        return analysis_tools
    
    async def close(self) -> None:
        """
        Close the analysis toolset and release resources.
        """
