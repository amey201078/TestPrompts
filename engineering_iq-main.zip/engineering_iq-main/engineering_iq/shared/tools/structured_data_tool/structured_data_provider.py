from abc import ABC, abstractmethod

from typing import Any, Dict, Union, Optional, List

class StructuredDataProvider(ABC):
    """Base interface for structured data providers."""
    
    @abstractmethod
    def fetch_structured_data(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None, 
             limit: Optional[int] = None, offset: int = 0, summary_only: bool = False) -> Union[str, Dict[str, Any]]:
        """Read structured data from file with batching support.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)
            summary_only: If True, return only summary info without actual data
        """
    
    @abstractmethod
    def write_structured_data(self, file_path: str, data: Any, encoding: str = "utf-8", container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Write structured data to file.
        
        Args:
            file_path: Path to the data file
            data: Data to write
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
        """
    
    @abstractmethod
    def query_structured_data(self, file_path: str, query_expression: str, encoding: str = "utf-8", container: Optional[str] = None,
              limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
        """Query structured data using format-specific query language with batching support.
        
        Args:
            file_path: Path to the data file
            query_expression: Query expression in format-specific language
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)
        """
    
    @abstractmethod
    def get_structure(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Get structure/schema of the data.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
        """

    @abstractmethod
    def get_stats_from_structured(self, file_path: str, encoding: str = "utf-8", container: Optional[str] = None) -> Dict[str, Union[str, bool]]:
        """Get statistics about the data.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            container: Optional container identifier (e.g., Excel sheet name, database table name)
        """

    @abstractmethod
    def list_containers(self, file_path: str, encoding: str = "utf-8") -> Union[str, List[str]]:
        """List all available containers in the data source.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            
        Returns:
            List of container names (e.g., Excel sheet names, database table names) or error message
        """

    @abstractmethod
    def get_container_column(self, file_path: str, column_name: str, encoding: str = "utf-8", 
                      container: Optional[str] = None, limit: Optional[int] = None, offset: int = 0) -> Union[str, Dict[str, Any]]:
        """
        
        Retrieve a specific column from a container in the data source.
        
        Args:
            file_path: Path to the data file
            column_name: Name of the column to analyze
            encoding: File encoding (default: utf-8)
            container: Optional container identifier
            limit: Maximum number of records to return (None for all)
            offset: Number of records to skip (default: 0)

        Returns:
            Data from the specified column, including type, statistics, and sample values.
            If the column does not exist, an error message is returned.
        """

    @abstractmethod
    def compare_structured_data(self, file_path1: str, file_path2: str, encoding: str = "utf-8",
                    container1: Optional[str] = None, container2: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Compare two data sources and identify differences.
        
        Args:
            file_path1: Path to first data file
            file_path2: Path to second data file
            encoding: File encoding (default: utf-8)
            container1: Container in first file
            container2: Container in second file
            
        Returns:
            Comparison report showing differences in structure, content, statistics
        """

    @abstractmethod
    def detect_relationships(self, file_path: str, encoding: str = "utf-8", 
                           container: Optional[str] = None) -> Union[str, Dict[str, Any]]:
        """Detect relationships and correlations between columns/fields.
        
        Args:
            file_path: Path to the data file
            encoding: File encoding (default: utf-8)
            container: Optional container identifier
            
        Returns:
            Analysis of correlations, dependencies, and potential relationships between fields
        """
