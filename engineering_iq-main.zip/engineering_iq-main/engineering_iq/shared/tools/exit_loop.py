from google.adk.tools import ToolContext
from engineering_iq.shared.core.logger import get_logger

logger = get_logger(__name__)

def exit_loop(tool_context: ToolContext):
  """Call this function ONLY when the critique indicates no further changes are needed, signaling the iterative process should end."""
  logger.info(f"  [Tool Call] exit_loop triggered by {tool_context.agent_name}")
  tool_context.actions.escalate = True
  return {}