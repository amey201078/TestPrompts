from typing import ClassVar

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent

from engineering_iq.shared.tools.file_tool import read_tools, write_tools

class TaskAdherenceAgentSettings(AgentSettings):
   """Specific settings for the Task Adherence Agent."""
   config_section: ClassVar[str] = "task_adherence_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

DEFAULT_NAME = TaskAdherenceAgentSettings.config_section
DEFAULT_DESCRIPTION = "You are responsible for checking that we are adhering to the task at hand."
DEFAULT_INSTRUCTION = """
You are responsible for checking that we are adhering to the task at hand.
You MUST confirm:
   - The outcome matches the acceptance criteria of the task and is fully complete.
   - The output has been save to the appropriate destination (and you've checked it).
   - The task status has been updated.
   - Mermaid syntax (if included in output) is valid - including core syntax and labels.
Provide your feedback to the user, confirming adherence or missing criteria with your rationale.
**IMPORTANT: You have tools to validate the existence of the output and read it.  DO NOT approve the task if the output is not present.**
"""
class TaskAdherenceAgent(EngineeringIQAgent):
   """Task Adherence Agent that checks if the task is ready for final review."""
   
   settings: TaskAdherenceAgentSettings = TaskAdherenceAgentSettings()

   def __init__(self, **kwargs) -> None:
      """
      Initializes the TaskAdherenceAgent.
      """
      super().__init__(**kwargs)
      self.add_meta(
            AC.AGENT_TYPE_REVIEWER,
      )

   def get_agent_settings(self):
      """
      Get the settings for the agent.
      This method returns an instance of the TaskAdherenceAgentSettings class.
      """
      return self.settings
   
   def _init_tools(self):
      """
      Initialize the tools for the agent.
      This method adds file tools.
      """
      self.add_tools(read_tools + write_tools)
   
   def _get_agent_core_config(self) -> dict:
      settings = self.get_agent_settings()

      resolved_name = self.name or settings.name or DEFAULT_NAME
      resolved_description = settings.description or DEFAULT_DESCRIPTION
      resolved_instruction = settings.instruction or DEFAULT_INSTRUCTION

      return {
         "name": resolved_name,
         "model": settings.model,
         "description": resolved_description,
         "instruction": resolved_instruction,
         "tools": self.tools
      }

# This should be awaited when used - don't call directly
iq_agent = TaskAdherenceAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
