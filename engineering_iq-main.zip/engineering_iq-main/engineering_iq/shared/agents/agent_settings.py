

from typing import Optional, Self

from pydantic import BaseModel, Field, model_validator

from engineering_iq.shared.core.models.app_settings import app_settings
from engineering_iq.shared.core.settings import BaseAnalyzerSettings

class MCPServer(BaseModel):
    """MCP server settings."""
    name: str = Field(
        default=None,
        description="Name of the MCP server. "
    )

    sse_url: str = Field(
        default=None,
        description="SSE URL for the MCP server. "
    )

class AgentSettings(BaseAnalyzerSettings):
    """Specific settings for the agent."""

    mcp_servers: Optional[list[MCPServer]] = Field(
        default=None,
        description="List of MCP servers."
    )

    description: Optional[str] = Field(
        default=None,
        description="Description of the agent.",
    )

    instruction: Optional[str] = Field(
        default=None,
        description="Instruction for the agent.",
    )

    short_name: Optional[str] = Field(
        default=None,
        description="Short name (or id) of the agent.",
    )

    name: Optional[str] = Field(
        default=None,
        description="Name of the agent.",
    )

    prompt_variables: Optional[dict[str, str]] = Field(
        default=None,
        description="Prompt variables for the agent.",
    )

    model: Optional[str] = Field(
        default=app_settings.default_model,
        description="Model to use for the agent.",
    )
    
    model_config = {
        **BaseAnalyzerSettings.model_config,
        "populate_by_name": True,  # Allow population by field name or alias
    }

    global_instruction: Optional[str] = Field(
        default=None,
        description="Global instruction for the agent.",
    )

    @model_validator(mode='after')
    def merged_prompt(self) -> Self:
        """
        Merge the agent's prompt variables with the default parameters.
        """
        if app_settings.default_merge_parameters:
            tmp_settings = app_settings.default_merge_parameters or {}
            tmp_settings.update(self.prompt_variables or {})
            self.prompt_variables = tmp_settings

        return self
