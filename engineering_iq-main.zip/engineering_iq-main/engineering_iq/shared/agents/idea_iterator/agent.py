"""Idea Iterator Agent for iterative requirements clarification and business outcome definition."""

from typing import ClassVar

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.tools.lsp_tool import all_lsp_tools
from engineering_iq.shared.tools.ast_tool import all_ast_tools
from engineering_iq.shared.tools.file_tool import read_tools, write_tools
from engineering_iq.shared.tools.structured_data_tool.structured_data_tool import StructuredDataTool
from engineering_iq.shared.tools.document_tool import DocumentAnalysisTool

class IdeaIteratorAgentSettings(AgentSettings):
    """Specific settings for the Idea Iterator Agent."""
    config_section: ClassVar[str] = "idea_iterator"

    model_config = {
        **AgentSettings.model_config,
        "env_prefix": f"{config_section.upper()}_AGENT_",
    }


class IdeaIteratorAgent(EngineeringIQAgent):
    """Idea Iterator Agent that clarifies requirements and defines business outcomes."""
    
    settings: IdeaIteratorAgentSettings = IdeaIteratorAgentSettings()

    def __init__(self, **kwargs) -> None:
        """
        Initializes the IdeaIteratorAgent.
        """
        super().__init__(**kwargs)
        self.add_meta(
            AC.AGENT_PERSONA_PRODUCT,
        )

    def get_agent_settings(self):
        """Get the settings for the agent."""
        return self.settings
    
    def _init_tools(self):
        """Initialize the tools for the agent."""
        # File tools for reading and writing files
        self.add_tools([
            StructuredDataTool(),
            DocumentAnalysisTool(),
            *read_tools,
            *write_tools,
            *all_lsp_tools,
            *all_ast_tools,
        ])
    
    def _get_agent_core_config(self) -> dict:
        settings = self.get_agent_settings()

        resolved_name = self.name or settings.name
        resolved_description = settings.description
        resolved_instruction = settings.instruction

        return {
            "name": resolved_name,
            "model": settings.model,
            "description": resolved_description,
            "instruction": resolved_instruction,
            "tools": self.tools
        }


# This should be awaited when used - don't call directly
iq_agent = IdeaIteratorAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
