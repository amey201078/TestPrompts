from typing import Any, Dict, Set
from typing import TYPE_CHECKING
import threading
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmRequest
from google.adk.events import Event
from google.adk.models.llm_response import LlmResponse
from google.adk.tools.tool_context import ToolContext
from google.adk.tools.base_tool import BaseTool

from engineering_iq.shared.core.models.app_settings import app_settings
from engineering_iq.shared.tools.file_tool import count_tokens
from engineering_iq.shared.core.logger import get_logger

from engineering_iq.shared.core.extended_model_support import summarize_content_objects

# Use TYPE_CHECKING to avoid circular import
if TYPE_CHECKING:
    from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent

logger = get_logger(__name__)

# Thread-safe session caches - simplified without expiration
_cache_lock = threading.Lock()
SESSION_EVENTS_CACHE: Dict[str, Set[str]] = {}
SESSION_CONTENTS_CACHE: Dict[str, list] = {}

async def custom_before_model_callback_handler(
        agent: "EngineeringIQAgent",
        callback_context: CallbackContext, 
        llm_request: LlmRequest
    ) -> LlmResponse | None:
    """
    Context management callback that follows a simple 4-step process:
    1. Check if current contents exceed token limit - if not, return None
    2. Find new events and check if new + cached contents are under limit - if so, return None  
    3. Summarize new events, add to cache, set llm_request contents to cached contents
    4. Return None on any errors
    """
    try:
        session = callback_context._invocation_context.session
        session_id = session.id
        
        logger.info(f"Processing context for session {session_id}")
        
        # Step 1: Check if current contents exceed token limit
        if llm_request.contents:
            try:
                current_tokens = count_tokens(llm_request.model_dump_json(), llm_request.model)
                logger.info(f"Current request tokens: {current_tokens}, limit: {app_settings.default_max_tokens}")
                
                if current_tokens < app_settings.default_max_tokens:
                    logger.info("Current contents under token limit, no processing needed")
                    return None
            except Exception as e:
                logger.warning(f"Failed to count current tokens: {e}")
        
        # Step 2: Find new events and check combined size
        with _cache_lock:
            # Get cached event IDs for this session
            cached_event_ids: Set[str] = SESSION_EVENTS_CACHE.get(session_id, set())
            cached_contents: list = SESSION_CONTENTS_CACHE.get(session_id, [])
            
            # Find new events
            new_events: list[Event] = []
            for event in session.events:
                if event.id not in cached_event_ids:
                    new_events.append(event)
            
            logger.info(f"Found {len(new_events)} new events for session {session_id}")
            
            if not new_events:
                logger.info("No new events found, using cached contents")
                if cached_contents:
                    llm_request.contents = cached_contents
                return None
        
        # Extract content from new events
        new_event_contents = []
        for event in new_events:
            if event.content and event.content.parts:
                new_event_contents.append(event.content)
        
        if not new_event_contents:
            logger.info("No content found in new events")
            return None
        
        # Check if new events + cached contents are under limit
        combined_contents = cached_contents + new_event_contents
        try:
            request_copy = llm_request.model_copy()
            request_copy.contents = combined_contents
            combined_tokens = count_tokens(request_copy.model_dump_json(), llm_request.model)
            logger.info(f"Combined tokens (cached + new): {combined_tokens}")
            
            if combined_tokens < app_settings.default_max_tokens:
                logger.info("Combined contents under token limit, updating cache and request")
                llm_request.contents = combined_contents
                
                # Update cache
                with _cache_lock:
                    for event in new_events:
                        cached_event_ids.add(event.id)
                    SESSION_EVENTS_CACHE[session_id] = cached_event_ids
                    SESSION_CONTENTS_CACHE[session_id] = combined_contents
                
                return None
        except Exception as e:
            logger.warning(f"Failed to count combined tokens: {e}")
        
        # Step 3: Summarize new events and update cache
        logger.info(f"Token limit exceeded, summarizing {len(new_event_contents)} new content objects")
        
        try:
            summarized_content = await summarize_content_objects(new_event_contents, llm_request.model)
            
            if summarized_content:
                final_contents = cached_contents + [summarized_content]
                llm_request.contents = final_contents
                
                # Update cache
                with _cache_lock:
                    for event in new_events:
                        cached_event_ids.add(event.id)
                    SESSION_EVENTS_CACHE[session_id] = cached_event_ids
                    SESSION_CONTENTS_CACHE[session_id] = final_contents
                
                logger.info(f"Successfully summarized new events and updated cache for session {session_id}")
            else:
                logger.warning("Summarization returned empty content")
        except Exception as e:
            logger.error(f"Summarization failed for session {session_id}: {e}")
        
    except Exception as e:
        logger.error(f"Error in custom_before_model_callback_handler for session {session_id}: {e}")
    
    # Step 4: Always return None
    return None

async def custom_after_model_response_handler(
        agent: "EngineeringIQAgent",
        callback_context: CallbackContext, 
        llm_response: LlmResponse
    ) -> LlmResponse:
    """
    Handles the LLM response: if it's a context size error message, transforms it into a tool call.
    """
    return None

async def custom_before_tool_callback_handler(
        agent: "EngineeringIQAgent",
        tool: BaseTool, 
        args: Dict[str, Any], 
        tool_context: ToolContext
    ) -> ToolContext | None:
    """
    Callback function to be executed before a tool is called.
    """
    return None

async def custom_after_tool_callback_handler(
    agent: "EngineeringIQAgent",
    tool: BaseTool, 
    args: Dict[str, Any], 
    tool_context: ToolContext, 
    tool_response: Any,  # Changed from Dict to Any to handle various response types
) -> Any:  # Changed return type to Any
    """
    Callback function to be executed after a tool is called.
    """
    return None
