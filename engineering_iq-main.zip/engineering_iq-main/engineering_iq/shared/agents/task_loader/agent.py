from typing import ClassVar
from google.adk.agents import Agent, LoopAgent
from google.adk.tools import agent_tool

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.agents.base.generic_agent import GenericAgent
from engineering_iq.shared.agents.jira_helper.agent import JiraAgent
from engineering_iq.shared.agents.final_reviewer.agent import FinalReviewerAgent
from engineering_iq.shared.tools.exit_loop import exit_loop
from engineering_iq.shared.tools.file_tool import read_tools, write_tools
from engineering_iq.shared.tools.structured_data_tool.structured_data_tool import StructuredDataTool
from engineering_iq.shared.tools.document_tool import DocumentAnalysisTool
class TaskLoaderAgentSettings(AgentSettings):
    """Task Loader Agent Settings."""
    config_section: ClassVar[str] = "task_loader"

    model_config = {
        **AgentSettings.model_config,
        "env_prefix": f"{config_section.upper()}_AGENT_",
    }

class TaskLoaderAgent(EngineeringIQAgent):
    """
    Task Loader Agent - Orchestrates loading tasks from files into Jira.
    Uses a loop agent pattern with core loader, Jira agent, and task adherence.
    """

    _settings: TaskLoaderAgentSettings = TaskLoaderAgentSettings()

    def __init__(self, **kwargs) -> None:
        """
        Initializes the TaskLoaderAgent.
        """
        super().__init__(**kwargs)
        self.add_meta(
            AC.AGENT_TYPE_UTILITY,
        )
    
    def get_agent_settings(self):
        """Get the agent settings."""
        return self._settings
    
    def _init_tools(self):
        """Initialize the tools for the agent."""
        self.add_tools([
            StructuredDataTool(),
            DocumentAnalysisTool(),
            *read_tools,
            *write_tools,
        ])

    
    def _get_agent(self) -> Agent:
        """
        Creates the loop agent with sub-agents.
        
        Returns:
            The initialized loop agent.
        """

        jira_tool_agent = JiraAgent(
            memory_service=self.memory_service,
            session_service=self.session_service,
            artifact_service=self.artifact_service,
            exit_stack=self.exit_stack,
        ).get_agent()

        jira_tool = agent_tool.AgentTool(jira_tool_agent)

        # orchestrator
        orchestrator_agent = GenericAgent(
            agent_settings=self.get_agent_settings(),
            tools=self.tools + [exit_loop],
            memory_service=self.memory_service,
            session_service=self.session_service,
            artifact_service=self.artifact_service,
        )

        # Create the Jira helper agent
        jira_agent = self.create_sub_agent(
            JiraAgent,
            additional_tools=self.tools + [exit_loop],
        )

        # team responsible for uploading
        task_loader_loop = LoopAgent(
            name="tlt_loop",
            sub_agents=[
                orchestrator_agent.get_agent(), 
                jira_agent,
            ],
        )

        final_reviewer_agent = self.create_sub_agent(
            FinalReviewerAgent,
            additional_tools=self.tools + [jira_tool, exit_loop],
        )
        
        # runs the team and validates output
        loop_agent = LoopAgent(
            name="tl_loop",
            sub_agents=[
                task_loader_loop,
                final_reviewer_agent,
            ],
        )
        
        return loop_agent
    
    def _get_agent_core_config(self) -> dict:
        # Not used since we override _get_agent
        return {}


# This should be awaited when used - don't call directly
iq_agent = TaskLoaderAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
