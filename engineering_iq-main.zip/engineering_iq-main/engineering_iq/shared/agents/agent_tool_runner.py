import asyncio
import threading
from typing import Optional, TYPE_CHECKING
from fastmcp import Context

from google.adk import Runner
from google.adk.sessions import Session
import google.genai.types as genai_types
from google.adk.events import Event

from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.models.app_settings import app_settings

# Use TYPE_CHECKING to avoid circular import
if TYPE_CHECKING:
    from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent

logger = get_logger(__name__)

# Thread-safe background task management
_background_tasks = set()
_background_tasks_lock = threading.Lock()

async def agent_run_as_tool(
    agent: "EngineeringIQAgent",
    ctx: Context,
    content: genai_types.Content = None,
) -> str:
    """
    Runs the agent as a tool.

    Args:
    agent: The agent to run.
    ctx: The context for the tool execution.
    content: The content to be processed by the agent.

    Returns:
    str: The complete output from the agent execution.
    """

    user_id = ctx.client_id or ctx.request_id + "_user"
    session_id = ctx.request_id + "_session"

    runner = Runner(
        app_name=agent.get_id(),
        agent=agent.get_agent(),
        artifact_service=agent.artifact_service,
        session_service=agent.session_service,
        memory_service=agent.memory_service,
    )

    session = await agent.session_service.get_session(
        session_id=session_id,
        app_name=agent.get_id(),
        user_id=user_id,
    )

    if not session:
        session = await agent.session_service.create_session(
            session_id=session_id,
            app_name=agent.get_id(),
            user_id=user_id,
        )

    attempts = 0
    while attempts < app_settings.agent_retries:
        try:

            if attempts > 0:
                logger.warning(f"Retrying agent {agent.get_id()} due to previous error... Attempt {attempts + 1}")
                content = genai_types.Content(parts=[genai_types.Part(text=f"Please continue, this is your {attempts + 1} attempt")])

            response = await _execute_runner(
                agent=agent,
                session=session,
                runner=runner,
                user_id=user_id,
                ctx=ctx,
                content=content
            )

            return response

        except Exception as e:
            attempts += 1
            logger.error(f"Error running agent {agent.get_id()}: {e}")
            if attempts >= app_settings.agent_retries:
                session.events.append(
                    Event(
                        author="system",
                        error_code="ERR_AGENT_EXECUTION",
                        error_message=f"Agent execution failed after {attempts} attempts: {str(e)}",
                        invocation_id=session.id,
                    )
                )
                raise e

    return "Agent execution failed after multiple attempts."

async def agent_run_as_tool_background(
    agent: "EngineeringIQAgent",
    ctx: Context,
    content: genai_types.Content
) -> dict:
    """
    Starts the agent as a background tool and returns session identifiers immediately.
    
    Args:
        agent: The agent to run.
        ctx: The context for the tool execution.
        content: The content to be processed by the agent.

    Returns:
        dict: Dictionary containing session_id, user_id, and app_name while the agent runs in background.
        
    Raises:
        ValueError: If required context information is missing.
        RuntimeError: If task creation fails.
    """
    try:
        # Extract identifiers with proper fallbacks
        user_id = ctx.client_id or f"{ctx.request_id}_user"
        app_name = agent.get_id()
        
        # Handle session creation/retrieval with safer access
        request_id = getattr(ctx, 'request_context', None)
        if request_id and hasattr(request_id, 'request_id'):
            session_id = f"{request_id.request_id}_session"
        else:
            session_id = f"{ctx.request_id}_session"
        
        logger.info(f"Starting background agent execution for session {session_id}")
        
        # Create the background task with proper error handling
        task = asyncio.create_task(
            _safe_agent_execution(agent, ctx, content),
            name=f"agent_{app_name}_{session_id}"
        )

        # Thread-safe task management
        def cleanup_task(task_ref):
            """Safely remove completed task from background tasks set."""
            with _background_tasks_lock:
                _background_tasks.discard(task_ref)
            logger.debug(f"Cleaned up background task for session {session_id}")

        # Store the task reference to prevent garbage collection
        with _background_tasks_lock:
            _background_tasks.add(task)

        # Remove task from set when it's done to prevent memory leaks
        task.add_done_callback(cleanup_task)

        logger.info(f"Successfully started background agent execution for session {session_id}")

        # Return identifiers immediately
        return {
            "session_id": session_id,
            "user_id": user_id,
            "app_name": app_name,
            "status": "running_background",
            "task_id": id(task),
            "task_name": task.get_name()
        }
        
    except Exception as e:
        logger.error(f"Failed to start background agent execution: {e}")
        session = agent.session_service.get_session(
            session_id=session_id,
            app_name=app_name,
            user_id=user_id
        )
        if session:
            session.events.append(
                Event(
                    author="system",
                    error_code="ERR_AGENT_EXECUTION",
                    error_message=f"Failed to start background agent: {str(e)}",
                    invocation_id=session.id,
                )
            )
        raise RuntimeError(f"Failed to start background agent: {str(e)}") from e


async def _safe_agent_execution(
    agent: "EngineeringIQAgent",
    ctx: Context,
    content: genai_types.Content
) -> Optional[str]:
    """
    Safely executes an agent with comprehensive error handling.
    
    Args:
        agent: The agent to run.
        ctx: The context for the tool execution.
        content: The content to be processed by the agent.
        
    Returns:
        Optional[str]: The result of agent execution or None if failed.
    """
    try:
        result = await agent_run_as_tool(agent, ctx, content)
        logger.info(f"Background agent {agent.get_id()} completed successfully")
        return result
    except Exception as e:
        logger.error(f"Background agent {agent.get_id()} failed: {e}", exc_info=True)
        return None

async def _execute_runner(
    agent: "EngineeringIQAgent",
    session: Session,
    runner: Runner,
    user_id: str,
    ctx: Context,
    content: genai_types.Content = None,
):
    """
    Executes the tool runner for the agent.
    This function is intended to be called by the FastMCP framework.
    """

    all_responses = []
    progress = 0.0

    await ctx.report_progress(progress=progress, message=f"Running agent {agent.get_id()} with content: {content}")

    events_async = runner.run_async(
        session_id=session.id,
        user_id=user_id,
        new_message=content
    )

    progress += 0.1

    await ctx.report_progress(progress=progress, message=f"Agent {agent.get_id()} started running...")

    async for event in events_async:
        
        progress += 0.1
        await ctx.report_progress(progress=progress, message=event.model_dump_json(exclude_none=True, by_alias=True))

        if event.content and event.content.parts:

            text_parts = []
            for part in event.content.parts:
                if part.text:
                    text_parts.append(part.text)
            
            if text_parts:
                response_text = ''.join(text_parts)
                await ctx.report_progress(progress=progress, message=f"Agent {agent.get_id()} produced output: {response_text} from author: {event.author}")
                all_responses.append(response_text)

    # Return the last meaningful response or concatenated responses
    if all_responses:
        return all_responses[-1]  # Return the final response
    else:
        return "Analysis completed but no text response was generated."

def get_background_task_count() -> int:
    """
    Returns the current number of active background tasks.
    
    Returns:
        int: Number of active background tasks.
    """
    with _background_tasks_lock:
        return len(_background_tasks)


def get_background_task_status() -> dict:
    """
    Returns detailed status information about background tasks.
    
    Returns:
        dict: Task status information including active count and task details.
    """
    with _background_tasks_lock:
        active_tasks = []
        completed_tasks = 0
        failed_tasks = 0
        
        for task in list(_background_tasks):
            if task.done():
                if task.exception():
                    failed_tasks += 1
                else:
                    completed_tasks += 1
            else:
                active_tasks.append({
                    "task_id": id(task),
                    "task_name": task.get_name(),
                    "cancelled": task.cancelled()
                })
        
        return {
            "total_active": len(active_tasks),
            "completed": completed_tasks,
            "failed": failed_tasks,
            "active_tasks": active_tasks
        }


async def cleanup_completed_background_tasks() -> int:
    """
    Manually cleanup completed background tasks.
    
    Returns:
        int: Number of tasks cleaned up.
    """
    cleaned_count = 0
    with _background_tasks_lock:
        completed_tasks = [task for task in list(_background_tasks) if task.done()]
        for task in completed_tasks:
            _background_tasks.discard(task)
            cleaned_count += 1
    
    if cleaned_count > 0:
        logger.info(f"Manually cleaned up {cleaned_count} completed background tasks")
    
    return cleaned_count

async def stop_all_tasks() -> int:
    """
    Manually stop all background tasks.
    
    Returns:
        int: Number of tasks stopped.
    """
    stopped_count = 0
    with _background_tasks_lock:
        for task in list(_background_tasks):
            task.cancel()
            stopped_count += 1
    if stopped_count > 0:
        logger.info(f"Manually stopped {stopped_count} background tasks")
    return stopped_count
