from typing import ClassVar, Optional

from pydantic import Field
import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.base.base_analysis_planner_agent import BaseAnalysisPlannerAgent
from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.agents.agent_settings import AgentSettings

logger = get_logger(__name__)

class ProductAnalysisPlannerSettings(AgentSettings):
   """
   Product Analysis Planner Agent Settings
   This class is responsible for setting up the agent settings for the product analysis planner agent.
   It inherits from the AgentSettings class and sets the default model and tools for the agent.
   """
   config_section: ClassVar[str] = "product_analysis_planner_agent"

   additional_report_sections: Optional[list[str]] = Field(
        default=None,
        description="Additional report sections to include in the product analysis report.",
   )

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }


class ProductAnalysisPlannerAgent(BaseAnalysisPlannerAgent):
    """
    Product Analysis Planner Agent
    This agent is responsible for planning an analysis of a particular code base (or codebases)
    with focus on non-technical aspects like user personas, journeys, and functional specifications.
    """
    SETTINGS_CLASS = ProductAnalysisPlannerSettings

    def __init__(self, **kwargs) -> None:
        """
        Initializes the ProductAnalysisPlannerAgent.
        """
        super().__init__(settings_obj=self.SETTINGS_CLASS(), **kwargs)
        self.add_meta(
            AC.AGENT_PERSONA_PRODUCT,
        )

    @property
    def settings(self) -> ProductAnalysisPlannerSettings:
        """
        Returns the agent settings.
        """
        return self._settings

# This should be awaited when used - don't call directly
iq_agent = ProductAnalysisPlannerAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
