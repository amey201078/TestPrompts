from typing import ClassVar
import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.tools.file_tool import read_tools, write_tools

class TeamLeadAgentSettings(AgentSettings):
   """
   Specific settings for the Team Lead Agent.
   This class inherits from AgentSettings and is used to configure the Team Lead Agent.
   """
   config_section: ClassVar[str] = "team_lead"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

DEFAULT_NAME = TeamLeadAgentSettings.config_section
DEFAULT_DESCRIPTION = "The team lead, responsible for picking up tasks from a provided source and handing them off to the team."
DEFAULT_INSTRUCTION = """
You are the team lead.
You are responsible for picking up tasks from a provided source and handing them off to the team.
You will hand off one task at a time.
You will wait for the team to finish the task before picking up the next one.
You will ensure that the team is updating their tasks as they complete them.
The task source will include the location of the repository and a list of tasks to perform.
You MUST ensure all tasks are completed and validate the final output of the last task before handing off the next task.
"""

class TeamLeadAgent(EngineeringIQAgent):
   """
   Team Lead Agent responsible for managing tasks and coordinating with other agents.
   """

   settings: TeamLeadAgentSettings = TeamLeadAgentSettings()

   def __init__(self, **kwargs) -> None:
      """
      Initializes the TeamLeadAgent.
      """
      super().__init__(**kwargs)
      self.add_meta(
            AC.AGENT_TYPE_LEAD,
      )

   def get_agent_settings(self):
      """
      Get the settings for the agent.
      This method returns an instance of the TeamLeadAgentSettings class.
      """
      return self.settings

   def _init_tools(self):
      """Initialize the tools for the agent."""
      self.add_tools(read_tools + write_tools)

   def _get_agent_core_config(self) -> dict:
      settings = self.get_agent_settings()

      resolved_name = self.name or settings.name or DEFAULT_NAME
      resolved_description = settings.description or DEFAULT_DESCRIPTION
      resolved_instruction = self.get_prompt() or DEFAULT_INSTRUCTION

      return {
         "name": resolved_name,
         "model": settings.model,
         "description": resolved_description,
         "instruction": resolved_instruction,
         "tools": self.tools
      }

# This should be awaited when used - don't call directly
iq_agent = TeamLeadAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
