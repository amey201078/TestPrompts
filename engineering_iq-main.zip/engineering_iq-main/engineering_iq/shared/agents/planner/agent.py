from typing import ClassVar

from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.tools.file_tool import read_tools, write_tools

class PlannerAgentSettings(AgentSettings):
   """
   Planner Agent Settings
   This class is responsible for setting up the agent settings for the planner agent.
   It inherits from the AgentSettings class and sets the default model and tools for the agent.
   """
   config_section: ClassVar[str] = "planner_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

class PlannerAgent(EngineeringIQAgent):
    """
    Planner Agent
    This agent is responsible for planning how to achieve an objective based on a set of requirements.
    It breaks down the requirements and creates a comprehensive plan to achieve the objective.
    """

    settings: PlannerAgentSettings = PlannerAgentSettings()

    def get_agent_settings(self):
        """
        Get the agent settings.
        """
        return self.settings
    
    def _init_tools(self):
        """Initialize the tools for the agent."""
        self.add_tools([
            *read_tools,
            *write_tools,
        ])

    def _get_agent_core_config(self) -> dict:
        settings = self.get_agent_settings()

        if "analysis_instructions" not in self.prompt_variables:
            self.prompt_variables.update({"analysis_instructions": "No valid instructions provided"})

        return {
            "name": self.name or settings.name,
            "model": settings.model,
            "description": settings.description,
            "instruction": settings.instruction,
            "tools": self.tools
        }