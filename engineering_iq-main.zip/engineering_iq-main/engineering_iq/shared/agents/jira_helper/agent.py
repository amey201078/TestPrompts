from typing import ClassVar, Optional

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent

class JiraSettings(AgentSettings):
    """Specific settings for the Jira agent."""
    config_section: ClassVar[str] = "jira_agent"

    model_config = {
        **AgentSettings.model_config,
        "env_prefix": f"{config_section.upper()}_AGENT_",
    }

class JiraAgent(EngineeringIQAgent):
    """Jira agent that can help with Jira operations."""

    settings: JiraSettings = JiraSettings()

    def __init__(self, **kwargs) -> None:
        """
        Initializes the JiraAgent.
        """
        super().__init__(**kwargs)
        self.add_meta(
            AC.AGENT_TYPE_UTILITY,
        )

    def get_agent_settings(self):
        """
        Get the settings for the agent.
        This method returns an instance of the JiraSettings class.
        """
        return self.settings
    
    def _init_tools(self):
        """Initialize the tools for the agent."""
        pass # No tools to initialize by default for JiraAgent
    
    def _get_agent_core_config(self) -> dict:
        settings = self.get_agent_settings()

        # JiraAgent's _get_agent didn't use module-level defaults for these,
        # relying on settings or self.name.
        # It also called self.get_agent_settings().model directly for model.
        return {
            "name": self.name or settings.name,
            "model": settings.model, # self.get_agent_settings() is already called as settings
            "description": settings.description,
            "instruction": settings.instruction,
            "tools": self.tools
        }


# This should be awaited when used - don't call directly
iq_agent = JiraAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
