from typing import ClassVar

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent

from engineering_iq.shared.tools.file_tool import read_tools
from engineering_iq.shared.core.models.app_settings import app_settings

class FilesSummarizerAgentSettings(AgentSettings):
   """Specific settings for the Files Summarizer Agent."""
   config_section: ClassVar[str] = "files_summarizer_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

DEFAULT_NAME = FilesSummarizerAgentSettings.config_section
DEFAULT_DESCRIPTION = "You are responsible for summarizing the contents of batches of files."
DEFAULT_INSTRUCTION = f"""
You are responsible for summarizing the contents of batches of files.
   - This could be a list of files provided by the user.
   - This could be a directory provided by the user.
   - The use could provide additional direction on how to filter files or what to summarize.
You will use the smart tools available for you to read files in batches.
You will batch the files so each batch is less than {app_settings.default_max_tokens*.75} tokens.
You will end by combining information from all the batches into a final summary.
You will not be complete until you have summarized all the files provided by the user.
You will use the user's input to guide you in what needs to be summarized from the files.
"""
class FilesSummarizerAgent(EngineeringIQAgent):
   """Files Summarizer Agent that summarizes the contents of batches of files."""

   settings: FilesSummarizerAgentSettings = FilesSummarizerAgentSettings()

   def __init__(self, **kwargs) -> None:
      """
      Initializes the FilesSummarizerAgent.
      """
      super().__init__(**kwargs)
      self.add_meta(
            AC.AGENT_TYPE_UTILITY,
      )

   def get_agent_settings(self):
      """
      Get the settings for the agent.
      This method returns an instance of the FilesSummarizerAgentSettings class.
      """
      return self.settings
   
   def _init_tools(self):
      """
      Initialize the tools for the agent.
      This method adds file tools.
      """
      self.add_tools(read_tools)
   
   def _get_agent_core_config(self) -> dict:
      settings = self.get_agent_settings()

      resolved_name = self.name or settings.name or DEFAULT_NAME
      resolved_description = settings.description or DEFAULT_DESCRIPTION
      resolved_instruction = settings.instruction or DEFAULT_INSTRUCTION

      return {
         "name": resolved_name,
         "model": settings.model,
         "description": resolved_description,
         "instruction": resolved_instruction,
         "tools": self.tools
      }

# This should be awaited when used - don't call directly
iq_agent = FilesSummarizerAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
