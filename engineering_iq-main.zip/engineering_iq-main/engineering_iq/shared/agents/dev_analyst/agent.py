from typing import ClassVar

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.base.base_analyst_agent import BaseAnalystAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.core.logger import get_logger

logger = get_logger(__name__)

class DevAnalystAgentSettings(AgentSettings):
   """
   Dev Analyst Agent Settings
   """
   config_section: ClassVar[str] = "dev_analyst_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

class DevAnalystAgent(BaseAnalystAgent):
    """
    Dev Analyst Agent
    This agent is responsible for analyzing code based on specified tasks and instructions.
    It uses language server and file tools to help understand the code.
    """

    settings: DevAnalystAgentSettings = DevAnalystAgentSettings()

    def __init__(self, **kwargs) -> None:
      """
      Initializes the DevAnalystAgent.
      """
      super().__init__(**kwargs)
      self.add_meta(
            AC.AGENT_PERSONA_DEVELOPER,
      )

    def get_agent_settings(self):
      """
      Get the agent settings.
      """
      return self.settings
        

# This should be awaited when used - don't call directly
iq_agent = DevAnalystAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
