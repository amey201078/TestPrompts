from typing import ClassVar

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.tools.file_tool import read_tools, write_tools

class DiagramerAgentSettings(AgentSettings):
   """
   Diagramer Agent Settings
   This class is responsible for setting up the agent settings for the diagramer agent.
   It inherits from the AgentSettings class and sets the default model and tools for the agent.
   """
   config_section: ClassVar[str] = "diagramer_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

DEFAULT_NAME = DiagramerAgentSettings.config_section
DEFAULT_DESCRIPTION = "Creates diagrams based on an analysis of the codebase."
DEFAULT_INSTRUCTION = """
You are responsible for creating or fixing mermaid diagrams provided to you.
If there is nothing to create the diagram for, you must provide detailed feedback on what is missing/needs change.
"""

class DiagramerAgent(EngineeringIQAgent):
    """
    Diagramer Agent
    This agent is responsible for creating or fixing mermaid diagrams based on a given input(s).
    It primarily uses file tools to read content and write diagram outputs.
    """

    settings: DiagramerAgentSettings = DiagramerAgentSettings()

    def __init__(self, **kwargs) -> None:
        """
        Initializes the DiagramerAgent.
        """
        super().__init__(**kwargs)
        self.add_meta(
            AC.AGENT_TYPE_UTILITY,
        )

    def get_agent_settings(self):
        """
        Get the agent settings.
        """
        return self.settings
    
    def _init_tools(self):
        """Initialize the tools for the agent."""
        self.add_tools([
            *read_tools,
            *write_tools,
        ])

    def _get_agent_core_config(self) -> dict:
        settings = self.get_agent_settings()

        resolved_name = self.name or settings.name or DEFAULT_NAME
        resolved_description = settings.description or DEFAULT_DESCRIPTION
        resolved_instruction = settings.instruction or DEFAULT_INSTRUCTION

        return {
            "name": resolved_name,
            "model": settings.model,
            "description": resolved_description,
            "instruction": resolved_instruction,
            "tools": self.tools
        }
        

# This should be awaited when used - don't call directly
iq_agent = DiagramerAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
