"""
Engineering IQ Agents

This module provides organized access to all available agents in the Engineering IQ toolkit.
Agents are automatically discovered and categorized by their meta information.
"""

import os
import importlib
from typing import Dict, List, Type, Optional
from pathlib import Path

from .engineeringiq_agent import EngineeringIQAgent
import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.core.logger import get_logger

# Initialize logger
logger = get_logger(__name__)


def _discover_agents() -> Dict[str, Type[EngineeringIQAgent]]:
    """
    Dynamically discover all agents by scanning subdirectories for modules with 'iq_agent'.
    
    Returns:
        Dictionary mapping agent names to agent classes
    """
    agents = {}
    agents_dir = Path(__file__).parent
    
    # Scan all subdirectories
    for item in agents_dir.iterdir():
        if item.is_dir() and not item.name.startswith('_') and not item.name.startswith('.'):
            agent_module_path = item / "agent.py"

            if agent_module_path.exists():
                logger.info(f"Discovered agent file: {agent_module_path}")
                try:

                    # Import the module
                    module_name = f"engineering_iq.shared.agents.{item.name}.agent"
                    module = importlib.import_module(module_name)

                    # Check if it has an iq_agent attribute
                    if hasattr(module, 'iq_agent'):
                        iq_agent_instance = getattr(module, 'iq_agent')
                        if isinstance(iq_agent_instance, EngineeringIQAgent):
                            # Get the agent class from the iq_agent instance
                            agent_class = type(iq_agent_instance)
                            agent_name = item.name
                            agents[agent_name] = agent_class

                except Exception as e:
                    # Skip agents that can't be imported - they might have missing dependencies
                    logger.exception(f"Could not import agent from {item.name}: {e}")
                    continue
    
    return agents


class AgentRegistry:
    """Central registry for all dynamically discovered agents."""
    
    def __init__(self):
        self._all_agents = _discover_agents()
        self._categories_cache = None
    
    @property
    def all_agents(self) -> Dict[str, Type[EngineeringIQAgent]]:
        """Get all discovered agents."""
        return self._all_agents.copy()
    
    @property
    def agent_names(self) -> List[str]:
        """Get list of all agent names."""
        return list(self._all_agents.keys())
    
    def get_agent_class(self, name: str) -> Optional[Type[EngineeringIQAgent]]:
        """Get an agent class by name."""
        return self._all_agents.get(name)
    
    def get_agents_by_type(self, agent_type: str) -> Dict[str, Type[EngineeringIQAgent]]:
        """
        Get agents by type (planner, analyzer, analyst, etc.).
        
        Args:
            agent_type: One of the agent types from agent_constants
            
        Returns:
            Dictionary of agent name -> agent class
        """
        result = {}
        for name, agent_class in self._all_agents.items():
            # Create a temporary instance to check meta
            try:
                temp_instance = agent_class()
                if temp_instance.has_meta(agent_type):
                    result[name] = agent_class
            except Exception:
                # If we can't instantiate, skip
                continue
        return result
    
    def get_agents_by_persona(self, persona: str) -> Dict[str, Type[EngineeringIQAgent]]:
        """
        Get agents by persona (developer, devsecops, qe, product, uncategorized).
        
        Args:
            persona: One of the personas from agent_constants
            
        Returns:
            Dictionary of agent name -> agent class
        """
        result = {}
        for name, agent_class in self._all_agents.items():
            # Create a temporary instance to check meta
            try:
                temp_instance = agent_class()
                if temp_instance.has_meta(persona):
                    result[name] = agent_class
            except Exception:
                # If we can't instantiate, skip
                continue
        return result
    
    def get_organized_categories(self) -> Dict[str, Dict[str, Type[EngineeringIQAgent]]]:
        """
        Get agents organized by logical categories based on their types.
        
        Returns:
            Dictionary with categories like 'planning', 'analysis', 'utility', etc.
        """
        if self._categories_cache is None:
            self._categories_cache = {
                'planning': self.get_agents_by_type(AC.AGENT_TYPE_PLANNER),
                'analysis': {
                    **self.get_agents_by_type(AC.AGENT_TYPE_ANALYZER),
                    **self.get_agents_by_type(AC.AGENT_TYPE_ANALYST)
                },
                'workflow': {
                    **self.get_agents_by_type(AC.AGENT_TYPE_LEAD),
                    **self.get_agents_by_type(AC.AGENT_TYPE_REVIEWER)
                },
                'utility': self.get_agents_by_type(AC.AGENT_TYPE_UTILITY),
            }
        return self._categories_cache.copy()
    
    def get_persona_organized(self) -> Dict[str, Dict[str, Type[EngineeringIQAgent]]]:
        """
        Get agents organized by persona.
        
        Returns:
            Dictionary mapping persona names to agent dictionaries
        """
        return {
            persona: self.get_agents_by_persona(persona)
            for persona in AC.AGENT_PERSONAS
        }
    
    def get_agent_info(self, name: str) -> Optional[Dict]:
        """
        Get detailed information about an agent.
        
        Args:
            name: Agent name
            
        Returns:
            Dictionary with agent information or None if not found
        """
        agent_class = self.get_agent_class(name)
        if not agent_class:
            return None
        
        try:
            temp_instance = agent_class()
            meta = temp_instance.get_meta()
            
            # Determine type and persona
            agent_type = None
            persona = None
            
            for meta_item in meta:
                if meta_item in AC.AGENT_TYPES:
                    agent_type = meta_item
                elif meta_item in AC.AGENT_PERSONAS:
                    persona = meta_item
            
            return {
                'name': name,
                'class': agent_class,
                'type': agent_type,
                'persona': persona,
                'meta': meta,
                'doc': agent_class.__doc__
            }
        except Exception as e:
            return {
                'name': name,
                'class': agent_class,
                'type': 'unknown',
                'persona': 'unknown',
                'meta': [],
                'doc': agent_class.__doc__,
                'error': str(e)
            }


# Create the global registry
REGISTRY = AgentRegistry()

# ============================================================================
# CATEGORIZED AGENT COLLECTIONS (derived from REGISTRY)
# ============================================================================

# Get organized categories
_categories = REGISTRY.get_organized_categories()

planning: Dict[str, Type[EngineeringIQAgent]] = _categories.get('planning', {})
analysis: Dict[str, Type[EngineeringIQAgent]] = _categories.get('analysis', {})
workflow: Dict[str, Type[EngineeringIQAgent]] = _categories.get('workflow', {})
utility: Dict[str, Type[EngineeringIQAgent]] = _categories.get('utility', {})

# All agents combined
all_agents: Dict[str, Type[EngineeringIQAgent]] = REGISTRY.all_agents

# Persona-based collections
personas = REGISTRY.get_persona_organized()
developer_agents: Dict[str, Type[EngineeringIQAgent]] = personas.get(AC.AGENT_PERSONA_DEVELOPER, {})
devsecops_agents: Dict[str, Type[EngineeringIQAgent]] = personas.get(AC.AGENT_PERSONA_DEVSECOPS, {})
qe_agents: Dict[str, Type[EngineeringIQAgent]] = personas.get(AC.AGENT_PERSONA_QE, {})
product_agents: Dict[str, Type[EngineeringIQAgent]] = personas.get(AC.AGENT_PERSONA_PRODUCT, {})
uncategorized_agents: Dict[str, Type[EngineeringIQAgent]] = personas.get(AC.AGENT_PERSONA_UNCATEGORIZED, {})

# ============================================================================
# CONVENIENCE LISTS (derived from REGISTRY)
# ============================================================================

planning_agents: List[str] = list(planning.keys())
analysis_agents: List[str] = list(analysis.keys())
workflow_agents: List[str] = list(workflow.keys())
utility_agents: List[str] = list(utility.keys())
all_agent_names: List[str] = REGISTRY.agent_names

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_agent_by_name(name: str) -> Optional[Type[EngineeringIQAgent]]:
    """
    Get an agent class by name.
    
    Args:
        name: Name of the agent (supports underscores and hyphens)
        
    Returns:
        Agent class or None if not found
    """
    # Normalize name
    normalized_name = name.lower().replace("-", "_")
    return REGISTRY.get_agent_class(normalized_name)


def get_agents_by_category(category: str) -> Dict[str, Type[EngineeringIQAgent]]:
    """
    Get all agents in a specific category.
    
    Args:
        category: Category name ('planning', 'analysis', 'workflow', 'utility', 'all')
        
    Returns:
        Dictionary mapping agent names to agent classes
        
    Raises:
        ValueError: If category is not valid
    """
    categories = {
        "planning": planning,
        "analysis": analysis,
        "workflow": workflow,
        "utility": utility,
        "all": all_agents,
    }
    
    if category.lower() not in categories:
        raise ValueError(f"Invalid category '{category}'. Available categories: {list(categories.keys())}")
    
    return categories[category.lower()]


def get_agents_by_type(agent_type: str) -> Dict[str, Type[EngineeringIQAgent]]:
    """
    Get agents by their meta type.
    
    Args:
        agent_type: One of the types from agent_constants (planner, analyzer, analyst, etc.)
        
    Returns:
        Dictionary mapping agent names to agent classes
    """
    return REGISTRY.get_agents_by_type(agent_type)


def get_agents_by_persona(persona: str) -> Dict[str, Type[EngineeringIQAgent]]:
    """
    Get agents by their meta persona.
    
    Args:
        persona: One of the personas from agent_constants (developer, devsecops, qe, product, uncategorized)
        
    Returns:
        Dictionary mapping agent names to agent classes
    """
    return REGISTRY.get_agents_by_persona(persona)


def list_agents_by_category() -> Dict[str, List[str]]:
    """
    Get a summary of all agents organized by category.
    
    Returns:
        Dictionary with category names as keys and lists of agent names as values
    """
    return {
        "planning": planning_agents,
        "analysis": analysis_agents,
        "workflow": workflow_agents,
        "utility": utility_agents,
    }


def list_agents_by_persona() -> Dict[str, List[str]]:
    """
    Get a summary of all agents organized by persona.
    
    Returns:
        Dictionary with persona names as keys and lists of agent names as values
    """
    return {
        persona: list(agents.keys())
        for persona, agents in personas.items()
    }


def get_agent_info(name: str) -> Optional[Dict]:
    """
    Get detailed information about an agent including its meta information.
    
    Args:
        name: Agent name
        
    Returns:
        Dictionary with agent information or None if not found
    """
    return REGISTRY.get_agent_info(name)


def list_all_agents() -> List[Dict]:
    """
    Get detailed information about all agents.
    
    Returns:
        List of dictionaries with agent information
    """
    return [REGISTRY.get_agent_info(name) for name in REGISTRY.agent_names]


# ============================================================================
# BACKWARD COMPATIBILITY ALIASES
# ============================================================================

# Maintain some backward compatibility with the old system
analyzers = analysis  # Old name for analysis category
team = workflow       # Old name for workflow category

analyzer_agents = analysis_agents  # Old naming
team_agents = workflow_agents      # Old naming

# ============================================================================
# EXPORTS
# ============================================================================

__all__ = [
    # Core registry and base class
    "REGISTRY",
    "EngineeringIQAgent",
    
    # CATEGORIES - Main agent collections organized by function
    "planning",           # Planning agents dictionary
    "analysis",          # Analysis agents dictionary (analyzers + analysts)
    "workflow",          # Workflow agents dictionary (leads + reviewers)
    "utility",           # Utility agents dictionary
    "all_agents",        # All agents combined dictionary
    
    # PERSONA COLLECTIONS - Agents organized by domain expertise  
    "developer_agents",   # Developer-focused agents
    "devsecops_agents",  # DevSecOps-focused agents
    "qe_agents",         # QE-focused agents
    "product_agents",    # Product-focused agents
    "uncategorized_agents", # Uncategorized agents
    "personas",          # All persona collections
    
    # CATEGORY LISTS - Lists of agent names by category
    "planning_agents",   # List of planning agent names
    "analysis_agents",   # List of analysis agent names
    "workflow_agents",   # List of workflow agent names
    "utility_agents",    # List of utility agent names
    "all_agent_names",   # List of all agent names
    
    # HELPER FUNCTIONS - Utility functions for agent discovery
    "get_agent_by_name",        # Get agent class by name
    "get_agents_by_category",   # Get agents by category
    "get_agents_by_type",       # Get agents by meta type
    "get_agents_by_persona",    # Get agents by meta persona
    "list_agents_by_category",  # List agents organized by category
    "list_agents_by_persona",   # List agents organized by persona
    "get_agent_info",           # Get detailed agent information
    "list_all_agents",          # Get detailed info for all agents
    
    # BACKWARD COMPATIBILITY - Old names for compatibility
    "analyzers",         # Alias for analysis
    "team",              # Alias for workflow
    "analyzer_agents",   # Alias for analysis_agents
    "team_agents",       # Alias for workflow_agents
]
