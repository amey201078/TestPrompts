from typing import ClassVar
from google.adk.agents import Agent

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.base.base_analyzer_agent import BaseAnalyzerAgent
from engineering_iq.shared.agents.dev_analyst.agent import DevAnalystAgent
from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.agents.agent_settings import AgentSettings

logger = get_logger(__name__)
class DevAnalyzerAgentSettings(AgentSettings):
   """
   Development Analyzer Agent Settings
   This class is responsible for setting up the agent settings for the development analyzer agent.
   It inherits from the AgentSettings class and sets the default model and tools for the agent.
   """
   config_section: ClassVar[str] = "dev_analyzer_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

class DevAnalyzerAgent(BaseAnalyzerAgent):
    """
    Development Analyzer Agent
    This agent is responsible for analyzing codebases from a development perspective,
    examining technical architecture, implementation details, and development practices.
    It orchestrates analysis by coordinating with DevAnalyst agents to provide comprehensive
    development-focused insights.
    """
    SETTINGS_CLASS = DevAnalyzerAgentSettings

    def __init__(self, **kwargs) -> None:
        """
        Initializes the DevAnalyzerAgent.
        """
        super().__init__(settings_obj=self.SETTINGS_CLASS(), **kwargs)
        self.name = self.SETTINGS_CLASS.config_section
        self.settings.description = self.__doc__
        self.add_meta(
            AC.AGENT_PERSONA_DEVELOPER,
        )

    @property
    def settings(self) -> DevAnalyzerAgentSettings:
        """
        Returns the agent settings.
        """
        return self._settings

    def _get_analyst_agent(self) -> Agent:
        """
        Gets the domain-specific analyst agent.
        """
        return self.create_sub_agent(DevAnalystAgent, additional_tools=self.tools)

# This should be awaited when used - don't call directly
iq_agent = DevAnalyzerAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
