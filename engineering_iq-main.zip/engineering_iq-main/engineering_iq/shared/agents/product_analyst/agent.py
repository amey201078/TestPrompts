from typing import ClassVar

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.base.base_analyst_agent import BaseAnalystAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.core.logger import get_logger

logger = get_logger(__name__)

class ProductAnalystAgentSettings(AgentSettings):
   """
   Product Analyst Agent Settings
   """
   config_section: ClassVar[str] = "product_analyst_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

class ProductAnalystAgent(BaseAnalystAgent):
    """
    Product Analyst Agent
    This agent is responsible for analyzing code from a business and functional perspective.
    It focuses on understanding business logic, user journeys, and feature value from code.
    """

    settings: ProductAnalystAgentSettings = ProductAnalystAgentSettings()

    def __init__(self, **kwargs) -> None:
      """
      Initializes the ProductAnalystAgent.
      """
      super().__init__(**kwargs)
      self.add_meta(
            AC.AGENT_PERSONA_PRODUCT,
      )

    def get_agent_settings(self):
        """
        Get the agent settings.
        """
        return self.settings

# This should be awaited when used - don't call directly
iq_agent = ProductAnalystAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
