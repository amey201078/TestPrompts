import types

from abc import ABC, abstractmethod
from contextlib import AsyncExitStack
import uuid

from pydantic import Field

from fastmcp import Context

from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.memory import BaseMemoryService, InMemoryMemoryService
from google.adk.sessions import BaseSessionService, InMemorySessionService
from google.adk.artifacts import BaseArtifactService, InMemoryArtifactService
from google.adk.tools import BaseTool, load_memory
from google.adk.tools.agent_tool import AgentTool
from google.adk.agents import Agent, BaseAgent
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, SseServerParams, BaseToolset

import google.genai.types as genai_types

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.core.extended_model_support import get_model
from engineering_iq.shared.core.models.app_settings import app_settings, AppSettings
from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.core.utils import create_validated_function_wrapper
from engineering_iq.shared.agents.agent_tool_runner import (
    agent_run_as_tool,
    agent_run_as_tool_background,
    stop_all_tasks,
)
from engineering_iq.shared.agents.custom_callbacks import (
    custom_before_model_callback_handler,
    custom_after_model_response_handler,
    custom_before_tool_callback_handler,
    custom_after_tool_callback_handler,
)

logger = get_logger(__name__)

MIN_CONTENT_OBJECTS_FOR_SUMMARY = 2 
MAX_CONTENT_OBJECTS_TO_SUMMARIZE_AT_ONCE = 10

class EngineeringIQAgent(ABC):
    """
    Base class for Engineering IQ agents.
    This class provides a template for creating agents with additional tools and memory services.
    """

    name:str = None
    tools:list[BaseTool] = []
    session_service:BaseSessionService = None
    memory_service:BaseMemoryService = None
    artifact_service:BaseArtifactService = None
    exit_stack:AsyncExitStack = None
    prompt_variables:dict[str,str] = None
    before_model_callback:callable = None
    after_model_callback:callable = None
    before_tool_callback:callable = None
    after_tool_callback:callable = None

    _tools_initialized: bool = False

    _meta: list[str] = [
        AC.AGENT_TYPE_UTILITY,
        AC.AGENT_PERSONA_UNCATEGORIZED,
    ]

    def __init__(self,
                 name:str=None,
                 additional_tools:list[BaseTool]=None, 
                 memory_service:BaseMemoryService=None,
                 session_service:BaseSessionService=None,
                 artifact_service:BaseArtifactService=None,
                 exit_stack:AsyncExitStack=None,
                 prompt_variables:dict[str,str]=None,
                 before_model_callback:callable=None,
                 after_model_callback:callable=None,
                 before_tool_callback:callable=None,
                 after_tool_callback:callable=None,
                 ):
        """Initialize the agent with additional tools and memory service."""
        self.tools = additional_tools if additional_tools else []
        self.memory_service = memory_service or InMemoryMemoryService()
        self.session_service = session_service or InMemorySessionService()
        self.artifact_service = artifact_service or InMemoryArtifactService()
        self.exit_stack = exit_stack or AsyncExitStack()
        self.prompt_variables = prompt_variables or {}
        self.name = name or self.get_agent_settings().name
        self.before_model_callback = before_model_callback or self.custom_before_model_callback_handler
        self.after_model_callback = after_model_callback or self.custom_after_model_response_handler
        self.before_tool_callback = before_tool_callback or self.custom_before_tool_callback_handler
        self.after_tool_callback = after_tool_callback or self.custom_after_tool_callback_handler

    @abstractmethod
    def get_agent_settings(self) -> AgentSettings:
        """Get the settings for the agent."""

    @abstractmethod
    def _get_agent_core_config(self) -> dict:
        """Subclasses implement this to provide core agent parameters.
        
        Expected dictionary keys: "name", "model", "instruction", "tools".
        Optional keys: "description".
        """

    @abstractmethod
    def _init_tools(self):
        """Initialize the tools for the agent."""

    def clear_meta(self):
        """Clear the meta information for the agent."""
        self._meta.clear()

    def add_meta(self, meta: str):
        """Add meta information to the agent."""
        self._meta.append(meta)

    def get_meta(self) -> list[str]:
        """Get the meta information for the agent."""
        return self._meta
    
    def has_meta(self, meta: str) -> bool:
        """Check if the agent has a specific meta information."""
        return meta in self._meta

    def get_prompt(self, override_instruction: str = None) -> str:
        """Get the instruction for the agent."""
        return override_instruction or self.get_agent_settings().instruction
    
    def get_agent(self) -> Agent:
        """Get the agent instance."""
        if not getattr(self, '_tools_initialized', False):
            self.initialize_tools()
            self._tools_initialized = True
        return self._get_agent()

    def _get_agent(self) -> BaseAgent:
        """
        Creates and returns the core ADK Agent instance based on the configuration
        provided by the subclass's _get_agent_core_config method.
        """        
        core_config = self._get_agent_core_config()
        
        # Ensure all mandatory keys are present in core_config from subclass
        # This is just a basic check, can be made more robust if needed
        expected_keys = ["name", "model", "instruction", "tools"]
        for key in expected_keys:
            if key not in core_config:
                raise ValueError(f"Key '{key}' missing from _get_agent_core_config() in {self.__class__.__name__}")
            
        model = get_model(core_config["model"])

        agent = Agent(
            name=core_config["name"],
            model=model,
            description=core_config.get("description") or self.get_agent_settings().description,
            instruction=self.get_merged_prompt(override_instruction=core_config["instruction"]),
            tools=core_config["tools"],
            before_model_callback=self.before_model_callback,
            after_model_callback=self.after_model_callback,
            before_tool_callback=self.before_tool_callback,
            after_tool_callback=self.after_tool_callback,
            # include_contents='none',
        )

        return agent
    
    def get_id(self) -> str:
        """Get the ID of the agent."""
        return self.get_agent_settings().short_name or self.get_agent_settings().name or self.get_agent_settings().config_section or uuid.uuid4().hex
    
    def get_app_settings(self) -> AppSettings:
        """Get the app settings for the agent."""
        return app_settings

    def get_merged_prompt(self, override_instruction: str = None, override_variables:dict[str,str]=None) -> str:
        """Get the merged prompt for the agent."""
        prompt_variables = self.get_agent_settings().prompt_variables or {}
        if self.prompt_variables:
            prompt_variables.update(self.prompt_variables)
        if override_variables:
            prompt_variables.update(override_variables)

        if not prompt_variables:
            return self.get_prompt(override_instruction=override_instruction)

        return self.get_prompt(override_instruction=override_instruction).format(**prompt_variables)

    def load_mcp_servers(self):
        """Load MCP servers for the agent. This method is now synchronous."""

        if not self.get_agent_settings().mcp_servers:
            logger.debug(f"No MCP servers configured for agent: {self.get_id()}")
            return

        for server_config in self.get_agent_settings().mcp_servers:
            logger.debug(f"Loading tools for agent {self.get_id()} from MCP server: {server_config.name}")
            try:
                remote_tools = MCPToolset(
                    connection_params=SseServerParams(
                        url=server_config.sse_url,
                        headers={'Accept': 'text/event-stream'},
                    )
                )
                self.add_tool(remote_tools)
                logger.info(f"Loaded tools from MCP server: {server_config.name}")
            except Exception as e:
                logger.error(f"Failed to load tools from MCP server {server_config.name}: {e}")

    def initialize_tools(self):
        """Initialize the tools for the agent. This method is now synchronous."""
        self._init_tools() # Now a synchronous call
        self.load_mcp_servers() # Now a synchronous call
        self.add_tools([
            # load_memory,
        ])

    def add_tools(self, tools:list[BaseTool]):
        """Add additional tools to the agent."""
        for tool in tools:
            self.add_tool(tool)

    def add_tool(self, tool: any):
        """
        Add a single tool to the agent.
        If the tool is a Python function, it will be wrapped for validation and error handling.
        """

        # don't mess with mcp servers
        if isinstance(tool, BaseToolset):
            self.tools.append(tool)
            return

        current_tool_ids = [self._get_tool_id(t) for t in self.tools]
        new_tool_id = self._get_tool_id(tool)

        if new_tool_id in current_tool_ids:
            logger.debug(f"Tool with ID '{new_tool_id}' already exists. Skipping.")
            return

        new_name = self.get_id()

        if isinstance(tool, types.FunctionType):
            logger.debug(f"Wrapping Python function: {tool.__name__}")
            wrapped_function = create_validated_function_wrapper(tool, new_name=new_name+ "_" + tool.__name__)
            self.tools.append(wrapped_function)
        elif isinstance(tool, BaseTool):
            self.tools.append(tool)
        else:
            if callable(tool):
                logger.debug(f"Wrapping callable (non-function type): {getattr(tool, '__name__', uuid.uuid4().hex)}")
                wrapped_callable = create_validated_function_wrapper(tool, new_name=new_name+ "_" + {getattr(tool, '__name__', uuid.uuid4().hex)}) # type: ignore
                self.tools.append(wrapped_callable)
            else:
                # Consider raising an error or logging more severely
                logger.error("Tool must be a Python function, a callable, or an instance of BaseTool.")
                return {"status": "error", "error_message": "Tool must be a Python function, a callable, or an instance of BaseTool."}
            
    def _get_tool_id(self, tool: any, new_name: str = "") -> str: # Changed type hint
        """Get the ID of the tool."""
        if hasattr(tool, '_is_adk_wrapped_tool') and tool._is_adk_wrapped_tool:
            return tool.name # type: ignore
        if isinstance(tool, types.FunctionType):
            name = tool.__name__
            if new_name:
                name = new_name + "_" + name
            return f"func:{name}"
        elif isinstance(tool, AgentTool):
            return f"agent_tool:{tool.agent.name}"
        elif isinstance(tool, BaseTool):
            return f"base_tool:{tool.name}"
        elif callable(tool) and hasattr(tool, '__name__'): # For other callables that might have a name
            return f"callable:{getattr(tool, '__module__', '')}.{tool.__name__}"
        else:
            return str(id(tool))

    def create_sub_agent(self, agent_class: type["EngineeringIQAgent"], additional_tools: list[BaseTool] = None, prompt_variables: dict[str, str] = None) -> BaseAgent:
        """
        Create the sub-agents for the agent. This method is now synchronous.
        """

        if not additional_tools:
            additional_tools = []

        # Don't explicitly add memory tools here since they'll be added by initialize_tools()
        agent = agent_class(
            additional_tools=additional_tools,
            memory_service=self.memory_service,
            session_service=self.session_service,
            artifact_service=self.artifact_service,
            exit_stack=self.exit_stack, # type: ignore
            prompt_variables=prompt_variables,
        )
        
        return agent.get_agent()
    
    async def cancel_all_run_as_tool(
            self,
            ctx: Context,
        ) -> None:
        """
        Cancel all executions of agent as a tool.
        """
        return await stop_all_tasks()

    async def run_as_tool(
        self,
        ctx: Context,
        input_str: str = Field(description="The input content for the agent"),
    ) -> str:
        """
        Runs the agent as a tool.
        Args:
            ctx: The context for the tool execution.
            input_str: The input content to be processed by the agent.
        Returns:
            str: The complete output from the agent execution.
        """
        content = genai_types.Content(role='user', parts=[genai_types.Part(text=input_str)])
        return await self._run_as_tool(ctx=ctx, content=content)
    
    async def _run_as_tool(
        self,
        ctx: Context,
        content: genai_types.Content = None,
    ) -> str:
        """
        Runs the agent as a tool.

        Args:
        ctx: The context for the tool execution.
        content: The content to be processed by the agent.

        Returns:
        str: The complete output from the agent execution.
        """
        await agent_run_as_tool(
            agent=self,
            ctx=ctx,
            content=content,
        )

    async def run_tool_in_background(
        self,
        ctx: Context,
        input_str: str = Field(description="The input content for the agent"),
    ) -> dict:
        """
        Runs the agent as a tool in the background.
        
        Args:
            ctx: The context for the tool execution.
            input_str: The input content to be processed by the agent.
            
        Returns:
            dict: Dictionary containing session_id, user_id, and app_name while the agent runs in background.
        """
        content = genai_types.Content(role='user', parts=[genai_types.Part(text=input_str)])
        return await self._run_tool_in_background(ctx=ctx, content=content)
    
    async def _run_tool_in_background(
        self,
        ctx: Context,
        content: genai_types.Content = None,
    ) -> dict:
        """
        Runs the agent as a tool in the background.

        Args:
        ctx: The context for the tool execution.
        content: The content to be processed by the agent.

        Returns:
        dict: Dictionary containing session_id, user_id, and app_name while the agent runs in background.
        """
        return await agent_run_as_tool_background(
            agent=self,
            ctx=ctx,
            content=content,
        )
    
    async def custom_before_model_callback_handler(
            self,
            callback_context: CallbackContext, 
            llm_request: LlmRequest
        ) -> LlmResponse | None:
        """
        Callback to modify LlmRequest before model call, primarily to reduce token count.
        It attempts summarization of multiple content objects and implements fallback strategies.
        """
        return await custom_before_model_callback_handler(
            agent=self,
            callback_context=callback_context, 
            llm_request=llm_request
        )

    async def custom_after_model_response_handler(
            self,
            callback_context: CallbackContext, 
            llm_response: LlmResponse
        ) -> LlmResponse:
        """
        Handles the LLM response: if it's a context size error message, transforms it into a tool call.
        """
        return await custom_after_model_response_handler(
            agent=self,
            callback_context=callback_context, 
            llm_response=llm_response
        )
    
    async def custom_before_tool_callback_handler(
            self,
            tool: BaseTool, 
            args: dict, 
            tool_context: dict
        ) -> dict | None:
        """
        Callback function to be executed before a tool is called.
        """
        return await custom_before_tool_callback_handler(
            agent=self,
            tool=tool, 
            args=args, 
            tool_context=tool_context
        )
    
    async def custom_after_tool_callback_handler(
            self,
            tool: BaseTool, 
            args: dict, 
            tool_context: dict,
            tool_response: any,
        ) -> dict | None:
        """
        Callback function to be executed after a tool is called.
        """
        return await custom_after_tool_callback_handler(
            self,
            tool=tool, 
            args=args, 
            tool_context=tool_context,
            tool_response=tool_response
        )
