from typing import ClassVar
from google.adk.tools import google_search

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent

class SimpleSearchSettings(AgentSettings):
   """Specific settings for the simple search agent."""
   config_section: ClassVar[str] = "simple_search_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

DEFAULT_NAME = SimpleSearchSettings.config_section
DEFAULT_DESCRIPTION = """
You are responsible for answering questions or performing research using Google Search.
"""
DEFAULT_INSTRUCTION = """
Review the user's request and provide a detailed response based on the information available via the search.
"""

class SimpleSearchAgent(EngineeringIQAgent):
   """Simple search agent that can answer questions using Google Search."""
    
   settings: SimpleSearchSettings = SimpleSearchSettings()

   def __init__(self, **kwargs) -> None:
      """
      Initializes the SimpleSearchAgent.
      """
      super().__init__(**kwargs)
      self.add_meta(
            AC.AGENT_TYPE_UTILITY,
      )

   def get_agent_settings(self):
      """
      Get the settings for the agent.
      This method returns an instance of the SimpleSearchSettings class.
      """
      return self.settings
   
   def _init_tools(self):
      """
      Initialize the tools for the agent.
      This method adds the Google Search tool.
      """
      self.add_tools([google_search])
   
   def _get_agent_core_config(self) -> dict:
      settings = self.get_agent_settings()

      resolved_name = self.name or settings.name or DEFAULT_NAME
      resolved_description = settings.description or DEFAULT_DESCRIPTION
      resolved_instruction = settings.instruction or DEFAULT_INSTRUCTION
      
      # Original _get_agent used self.get_agent_settings().model, which is settings.model
      return {
         "name": resolved_name,
         "model": settings.model, 
         "description": resolved_description,
         "instruction": resolved_instruction,
         "tools": self.tools
      }

# This should be awaited when used - don't call directly
iq_agent = SimpleSearchAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
