import asyncio
import json
from typing import AsyncGenerator
from typing_extensions import override

from google.adk.agents import SequentialAgent, BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events.event import Event
from google.genai.types import Content, Part

from engineering_iq.shared.core.logger import get_logger

logger = get_logger(__name__)

class SequentialAgentWithErrorHandling(SequentialAgent):
    """
    SequentialAgentWithErrorHandling is a subclass of SequentialAgent that
    provides error handling for the sub-agents.
    """

    retries: int = 3
    sleep_between_retries: int = 3

    model_config = {
        "arbitrary_types_allowed": True,
    }

    def wrap_error(self, error: Exception, msg: str, ctx: InvocationContext) -> Event:
        """
        Wrap the error in a message and return a valid Event object.
        """

        error_details_dict = {
            "error_type": type(error).__name__,
            "error_message_original": str(error), # Original error message
            "context_message": msg, # Your custom message (e.g., about retrying)
        }

        error_details_json_str = json.dumps(error_details_dict, indent=2)
        event_content = Content(parts=[Part(text=error_details_json_str)])

        # The Event.error_message field is intended for a concise error string.
        # You can use the original error's message or your custom message here.
        concise_error_message = f"Error in sub-agent: {str(error)}"


        return Event(
            error_message=concise_error_message, # Main error message for the event
            content=event_content,              # Structured content
            author="ErrorHandler",
            actions=None, # Should be acceptable as Event.actions is Optional[EventActions]
            long_running_tool_ids=None,
            branch=None,
            invocation_id=ctx.invocation_id if hasattr(ctx, 'invocation_id') else "",
        )


    @override
    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        """Run the agent asynchronously."""
        for sub_agent in self.sub_agents:
            async for val in self._run_yield_impl(ctx, sub_agent, sub_agent.run_async):
                yield val

    @override
    async def _run_live_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        """
        Run the agent live.
        """
        for sub_agent in self.sub_agents:
            async for val in self._run_yield_impl(ctx, sub_agent, sub_agent.run_live):
                yield val

    async def _run_yield_impl(
        self, ctx: InvocationContext, sub_agent: BaseAgent, callback: callable
    ) -> AsyncGenerator[Event, None]:
        """Run the callback and yield the results."""
        attempts = self.retries + 1
        while attempts > 0:
            try:
                async for event in callback(ctx):
                    yield event
                break
            except Exception as e:
                logger.exception(
                    f"Error in sub-agent {sub_agent.name}: {e}. Retrying... ({self.retries - attempts + 1}/{self.retries})",
                )
                attempts -= 1
                if attempts == 0:
                    yield self.wrap_error(e, f"Error in sub-agent {sub_agent.name}: {e}. Max retries {self.retries} exceeded.", ctx)
                else:
                    await asyncio.sleep( (self.retries - attempts + 1) * self.sleep_between_retries)
                    raise e
