from typing import ClassVar
import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.tools.git_tool import all_git_tools
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings

class GitAgentSettings(AgentSettings):
   """
   Specific settings for the Git agent.
   This class inherits from AgentSettings and is used to configure the Git agent.
   """
   config_section: ClassVar[str] = "git_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

DEFAULT_NAME = GitAgentSettings.config_section
DEFAULT_DESCRIPTION = "You are responsible for checking out a repository from git."
DEFAULT_INSTRUCTION = """
You are a git maven, adept at managing repositories and assisting with Git operations.
Use the tools provided to clone repositories and perform other Git-related tasks.
"""

class GitHelperAgent(EngineeringIQAgent):
   """
   Git Helper Agent that assists with Git operations such as cloning repositories.
   """

   settings: GitAgentSettings = GitAgentSettings()

   def __init__(self, **kwargs) -> None:
      """
      Initializes the GitHelperAgent.
      """
      super().__init__(**kwargs)
      self.add_meta(
            AC.AGENT_TYPE_UTILITY,
      )

   def get_agent_settings(self):
      """
      Get the settings for the agent.
      This method returns an instance of the GitAgentSettings class.
      """
      return self.settings

   def _init_tools(self):
      """
      Initialize the tools for the agent.
      """
      self.add_tools(all_git_tools)

   def _get_agent_core_config(self) -> dict:
      settings = self.get_agent_settings()

      resolved_name = self.name or settings.name or DEFAULT_NAME
      resolved_description = settings.description or DEFAULT_DESCRIPTION
      resolved_instruction = settings.instruction or DEFAULT_INSTRUCTION

      return {
         "name": resolved_name,
         "model": settings.model,
         "description": resolved_description,
         "instruction": resolved_instruction,
         "tools": self.tools
      }

# This should be awaited when used - don't call directly
iq_agent = GitHelperAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
