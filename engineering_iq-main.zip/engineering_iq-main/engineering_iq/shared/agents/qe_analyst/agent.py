from typing import ClassVar

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.base.base_analyst_agent import BaseAnalystAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.core.logger import get_logger

logger = get_logger(__name__)

class QEAnalystAgentSettings(AgentSettings):
   """
   QE Analyst Agent Settings
   """
   config_section: ClassVar[str] = "qe_analyst_agent"

   model_config = {
      **AgentSettings.model_config,
      "env_prefix": f"{config_section.upper()}_AGENT_",
   }

class QEAnalystAgent(BaseAnalystAgent):
    """
    QE Analyst Agent
    Responsible for quality engineering tasks - planning, analysis, and execution.
    """

    settings: QEAnalystAgentSettings = QEAnalystAgentSettings()

    def __init__(self, **kwargs) -> None:
      """
      Initializes the QEAnalystAgent.
      """
      super().__init__(**kwargs)
      self.add_meta(
            AC.AGENT_PERSONA_QE,
      )

    def get_agent_settings(self):
        """
        Get the agent settings.
        """
        return self.settings

# This should be awaited when used - don't call directly
iq_agent = QEAnalystAgent()
root_agent = iq_agent.get_agent()
session_service = iq_agent.session_service
artifact_service = iq_agent.artifact_service
memory_service = iq_agent.memory_service
