from abc import ABCMeta, abstractmethod
from typing import Any
from typing_extensions import override

from google.adk.agents import Agent, LoopAgent
from google.adk.tools.exit_loop_tool import exit_loop
import google.genai.types as genai_types

from pydantic import Field

from fastmcp import Context

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.agents.final_reviewer.agent import FinalReviewerAgent
from engineering_iq.shared.agents.planner.agent import PlannerAgent
from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.tools.file_tool import read_tools, write_tools


class BaseAnalysisPlannerAgent(EngineeringIQAgent, metaclass=ABCMeta):
  """
  Base class for analysis planner agents.
  """
  logger = get_logger(__name__)

  _settings: AgentSettings = None

  def __init__(self, settings_obj: AgentSettings, **kwargs) -> None:
    """
    Initializes the BaseAnalysisPlannerAgent.

    Args:
      settings_obj: The settings object for the agent.
      **kwargs: Additional keyword arguments.
    """
    self._settings = settings_obj
    super().__init__(**kwargs)
    self.clear_meta()
    self.add_meta(
        AC.AGENT_TYPE_PLANNER,
    )

  @property
  @abstractmethod
  def settings(self) -> Any:
    """
    Abstract property for agent settings.
    """
    return self._settings

  def get_agent_settings(self) -> AgentSettings:
    """
    Returns the agent settings.

    Returns:
      The agent settings.
    """
    return self.settings

  def _get_agent_core_config(self) -> dict:
    """
    No op
    """

  def _init_tools(self) -> None:
    """
    Initializes the tools for the agent.
    """
    super()._init_tools()
    self.add_tools([
      *read_tools,
      *write_tools,
    ])

  def _get_additional_reports(self) -> str:
    """
    Gets additional report sections.

    Returns:
      A string containing additional report sections, or an empty string if none are found.
    """
    additional_report_sections = self.settings.additional_report_sections
    if not additional_report_sections:
      return ""
    return "\n".join(additional_report_sections)

  def _get_agent(self) -> Agent:
    """
    Gets the agent.

    Returns:
      The initialized agent.
    """
    settings = self.get_agent_settings()
    instruction = settings.instruction or ""

    if "{additional_sections}" in instruction:
      instruction = instruction.format(
          additional_sections=self._get_additional_reports(),
          **settings.prompt_variables,
      )

    prompt_variables = {
        **settings.prompt_variables,
        "analysis_instructions": instruction,
    }

    planner_agent = PlannerAgent(
        name=f"{self.get_id()}_planner_agent",
        prompt_variables=prompt_variables,
    )

    final_reviewer_agent = self.create_sub_agent(
        FinalReviewerAgent,
        additional_tools=[exit_loop] + self.tools,
        prompt_variables=prompt_variables,
    )

    loop_agent = LoopAgent(
        name=f"{self.get_id()}_planner_tasks",
        sub_agents=[planner_agent.get_agent(), final_reviewer_agent],
    )
    return loop_agent

  @override
  async def run_as_tool(
      self,
      ctx: Context,
      input_str: str = Field(description="The git url for the repo"),
      codebase_path: str = Field(description="The base folder for the repo")
  ) -> str:
    """
    Runs the agent as a tool.

    Args:
      input_str: The git url for the repo.
      codebase_path: The base folder for the repo.
    
    Returns:
      str: The session ID of the agent run.
    """
    query = f"Analyze the codebase at {codebase_path} with repo {input_str}."
    content = genai_types.Content(role='user', parts=[genai_types.Part(text=query)])
    return await self._run_as_tool(
        ctx=ctx,
        content=content,
    )
  
  @override
  async def run_tool_in_background(
      self,
      ctx: Context,
      input_str: str = Field(description="The git url for the repo"),
      codebase_path: str = Field(description="The base folder for the repo")
  ) -> str:
    """
    Runs the agent as a tool.

    Args:
      input_str: The git url for the repo.
      codebase_path: The base folder for the repo.
    
    Returns:
      str: The session ID of the agent run.
    """
    query = f"Analyze the codebase at {codebase_path} with repo {input_str}."
    content = genai_types.Content(role='user', parts=[genai_types.Part(text=query)])
    return await self._run_tool_in_background(
        ctx=ctx,
        content=content,
    )