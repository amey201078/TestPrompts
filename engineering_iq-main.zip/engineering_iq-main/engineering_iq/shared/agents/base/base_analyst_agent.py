from fastmcp import Context

from typing_extensions import override

from pydantic import Field

from google.genai import types as genai_types

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.tools.lsp_tool import all_lsp_tools
from engineering_iq.shared.tools.ast_tool import all_ast_tools
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.tools.file_tool import read_tools, write_tools
from engineering_iq.shared.tools.structured_data_tool.structured_data_tool import StructuredDataTool
from engineering_iq.shared.tools.document_tool import DocumentAnalysisTool

class BaseAnalystAgent(EngineeringIQAgent):
    """
    Base class for analyst agents.
    """

    def __init__(self, **kwargs) -> None:
        """
        Initializes the BaseAnalystAgent.
        
        Args:
            **kwargs: Additional keyword arguments.
        """
        super().__init__(**kwargs)
        self.clear_meta()
        self.add_meta(
            AC.AGENT_TYPE_ANALYST,
        )

    def _init_tools(self):
        """Initialize the tools for the agent."""
        self.add_tools([
            StructuredDataTool(),
            DocumentAnalysisTool(),
            *read_tools,
            *write_tools,
            *all_lsp_tools,
            *all_ast_tools,
        ])
        
    def _get_agent_core_config(self) -> dict:
        settings = self.get_agent_settings()
        return {
            "name": self.name or settings.name,
            "model": settings.model,
            "description": settings.description,
            "instruction": settings.instruction,
            "tools": self.tools
        }
    
    @override
    async def run_as_tool(
        self,
        ctx: Context,
        input_str: str = Field(description="The task for the agent to perform"),
    ) -> str:
        """
        Runs the agent as a tool.

        Args:
        input_str: The task for the agent to perform.

        Returns:
        str: The complete output from the agent execution.
        """
        content = genai_types.Content(role='user', parts=[genai_types.Part(text=input_str)])
        return await self._run_as_tool(
            ctx=ctx,
            content=content,
        )
    
    @override
    async def run_tool_in_background(
        self, 
        ctx: Context, 
        input_str: str = Field(description="The task for the agent to perform")
    ):
        """
        Runs the agent as a tool.

        Args:
        input_str: The task for the agent to perform.

        Returns:
        str: The complete output from the agent execution.
        """
        content = genai_types.Content(role='user', parts=[genai_types.Part(text=input_str)])
        return await self._run_tool_in_background(
            ctx=ctx,
            content=content,
        )
