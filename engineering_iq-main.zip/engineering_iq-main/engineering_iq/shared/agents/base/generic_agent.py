"""Generic Agent that can be configured dynamically."""

from typing import List, Optional
from google.adk.tools import BaseTool

from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.agents.agent_settings import AgentSettings

class GenericAgent(EngineeringIQAgent):
    """
    Generic Agent that can be configured dynamically.
    
    This agent allows you to create simple agents on the fly by passing
    configuration parameters directly without needing to create a new class.
    
    Example:
        agent = GenericAgent(
            agent_settings=self.settings
            tools=read_tools + write_tools,
        )
    """

    custom_tools: Optional[List[BaseTool]] = None
    
    def __init__(
        self,
        agent_settings: AgentSettings = None,
        tools: Optional[List[BaseTool]] = None,
        **kwargs
    ):
        """
        Initialize a generic agent with custom configuration.
        
        Args:
            agent_settings: the agent settings object
            tools: list of tools for the agent to use
            **kwargs: Additional arguments passed to parent class
        """

        self._custom_tools = tools
        self.settings = agent_settings

        # Initialize parent
        super().__init__(**kwargs)
    
    def get_agent_settings(self) -> AgentSettings:
        """Get the agent settings."""
        return self.settings
    
    def _init_tools(self):
        """Initialize tools - adds any custom tools provided."""
        # Add custom tools if provided
        if self._custom_tools:
            self.add_tools(self._custom_tools)
    
    def _get_agent_core_config(self) -> dict:
        """Get the core agent configuration."""
        settings = self.get_agent_settings()
        
        return {
            "name": settings.name,
            "model": settings.model,
            "description": settings.description,
            "instruction": settings.instruction,
            "tools": self.tools
        }