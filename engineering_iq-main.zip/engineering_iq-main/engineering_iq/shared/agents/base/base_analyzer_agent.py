from abc import ABCMeta, abstractmethod
from typing_extensions import override

from fastmcp import Context

from pydantic import Field

from google.adk.agents import Agent, LoopAgent
import google.genai.types as genai_types

import engineering_iq.shared.agents.agent_constants as AC
from engineering_iq.shared.agents.agent_settings import AgentSettings
from engineering_iq.shared.agents.engineeringiq_agent import EngineeringIQAgent
from engineering_iq.shared.agents.final_reviewer.agent import FinalReviewerAgent
from engineering_iq.shared.agents.sequential_agent_with_error_handling import SequentialAgentWithErrorHandling
from engineering_iq.shared.agents.task_adherence.agent import TaskAdherenceAgent
from engineering_iq.shared.agents.team_lead.agent import TeamLeadAgent
from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.tools.lsp_tool import all_lsp_tools
from engineering_iq.shared.tools.ast_tool import all_ast_tools
from engineering_iq.shared.tools.file_tool import all_read_tools
from engineering_iq.shared.tools.structured_data_tool.structured_data_tool import StructuredDataTool
from engineering_iq.shared.tools.document_tool import DocumentAnalysisTool
from engineering_iq.shared.tools.exit_loop import exit_loop

class BaseAnalyzerAgent(EngineeringIQAgent, metaclass=ABCMeta):
  """
  Base class for analyzer agents.
  """
  logger = get_logger(__name__)  

  _settings: AgentSettings = None

  def __init__(self, settings_obj: AgentSettings, **kwargs) -> None: # Changed BaseAgentSettings to AgentSettings
    """
    Initializes the BaseAnalyzerAgent.

    Args:
      settings_obj: The settings object for the agent.
      **kwargs: Additional keyword arguments.
    """
    self._settings = settings_obj  # Assign _settings before calling super().__init__
    super().__init__(**kwargs)
    self.clear_meta()
    self.add_meta(
        AC.AGENT_TYPE_ANALYZER,
    )

  @property
  @abstractmethod
  def settings(self) -> AgentSettings: # Changed BaseAgentSettings to AgentSettings
    """
    Abstract property for agent settings.
    Subclasses must implement this to return their specific settings object.
    """
    raise NotImplementedError

  def get_agent_settings(self) -> AgentSettings: # Changed BaseAgentSettings to AgentSettings
    """
    Returns the agent settings.

    Returns:
      The agent settings.
    """
    return self.settings

  def _init_tools(self) -> None:
    """
    Initializes the tools for the agent.
    """
    super()._init_tools()
    self.add_tools([
        StructuredDataTool(),
        DocumentAnalysisTool(),
        *all_read_tools,
        *all_lsp_tools,
        *all_ast_tools,
    ])
    
  @abstractmethod
  def _get_analyst_agent(self) -> Agent:
    """
    Abstract method to get the domain-specific analyst agent.
    Subclasses must implement this to provide their specific analyst agent.

    Returns:
      The domain-specific analyst agent.
    """
    pass

  def _get_agent_core_config(self) -> dict:
    """
    No op
    """

  # This is the existing method that defines the orchestrator
  def _get_agent(self) -> Agent:
    """
    Gets the main orchestration agent.

    Returns:
      The initialized orchestration agent.
    """
    team_lead_agent = self.create_sub_agent(
        TeamLeadAgent,
        additional_tools=[exit_loop] + self.tools,
    )

    analyst_sub_agent = self._get_analyst_agent()

    task_adherence_agent = self.create_sub_agent(
        TaskAdherenceAgent,
        additional_tools=self.tools,
    )

    analysis_tasks_agent = LoopAgent(
        name=f"{self.get_id()}_tasks",
        sub_agents=[team_lead_agent, analyst_sub_agent, task_adherence_agent],
    )

    final_reviewer_agent = self.create_sub_agent(
        FinalReviewerAgent,
        additional_tools=[exit_loop] + self.tools,
    )

    orchestration_agent = SequentialAgentWithErrorHandling(
        name=f"{self.get_id()}_orch",
        sub_agents=[analysis_tasks_agent, final_reviewer_agent],
    )

    return orchestration_agent
  

  @override
  async def run_as_tool(
      self,
      ctx: Context,
      input_str: str = Field(description="The path to the analysis file"),
  ) -> str:
    """
    Runs the agent as a tool.

    Args:
      input_str: The input content for the agent.

    Returns:
      str: The complete output from the agent execution.
    """
    content = genai_types.Content(role='user', parts=[genai_types.Part(text=input_str)])
    return await self._run_as_tool(
        ctx=ctx,
        content=content,
    )
 
  @override
  async def run_tool_in_background(
      self,
      ctx: Context,
      input_str: str = Field(description="The path to the analysis file"),
  ) -> str:
    """
    Runs the agent as a tool.

    Args:
      input_str: The input content for the agent.

    Returns:
      str: The complete output from the agent execution.
    """
    content = genai_types.Content(role='user', parts=[genai_types.Part(text=input_str)])
    return await self._run_tool_in_background(
        ctx=ctx,
        content=content,
    )
 
