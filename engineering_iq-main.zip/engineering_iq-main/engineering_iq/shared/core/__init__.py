"""
Core functionality for the code analyzer.
"""

from .logger import configure_logger, get_logger

__all__ = [
    'configure_logger',
    'get_logger',
]
