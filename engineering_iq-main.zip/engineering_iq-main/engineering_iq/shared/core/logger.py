"""
Logger configuration and utilities for the code analyzer.
"""

import inspect
import sys
import logging
from pathlib import Path

from loguru import logger

import litellm

from .models.logger_settings import logger_settings

# Flag to track if logger has been configured
_LOGGER_CONFIGURED = False

LOGGERS = (
    "uvicorn",
    "uvicorn.access",
    "uvicorn.error",
    "fastapi",
    "asyncio",
    "starlette",
)

class InterceptHandler(logging.Handler):
    """
    Redirects logging messages to Loguru logger.
    """
    def emit(self, record: logging.LogRecord) -> None:
        # Get corresponding Loguru level if it exists.
        try:
            level: str | int = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        # Find caller from where originated the logged message.
        frame, depth = inspect.currentframe(), 0
        while frame:
            filename = frame.f_code.co_filename
            is_logging = filename == logging.__file__
            is_frozen = "importlib" in filename and "_bootstrap" in filename
            if depth > 0 and not (is_logging or is_frozen):
                break
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())

def configure_logger() -> None:
    """
    Configure the logger based on settings from the YAML configuration.
    This function should be called once at application startup.
    """
    global _LOGGER_CONFIGURED
    
    # Only configure once
    if _LOGGER_CONFIGURED:
        logger.debug("Logger already configured, skipping")
        return
        
    config = logger_settings
    
    # Remove all existing handlers
    logger.remove()

    # Add a default handler to intercept standard logging
    logging.basicConfig(handlers=[InterceptHandler()], level=0, force=True)
    
    # Configure handlers from the configuration
    for handler_config in config.handlers:
        sink = handler_config.sink
        
        # Handle special sinks
        if sink == "stdout":
            sink = sys.stdout
        elif sink == "stderr":
            sink = sys.stderr
        elif not sink.startswith(("sys.", "ext://")):
            # Ensure the directory exists for file sinks
            sink_path = Path(sink)
            sink_path.parent.mkdir(parents=True, exist_ok=True)
            sink = str(sink_path)
        
        # Extract standard parameters
        standard_params = {
            "level": handler_config.level,
            "format": handler_config.format,
            "colorize": handler_config.colorize,
            "serialize": handler_config.serialize,
            "backtrace": handler_config.backtrace,
            "diagnose": handler_config.diagnose,
            "enqueue": handler_config.enqueue,
            "catch": handler_config.catch,
        }
        
        # Handle file-specific parameters
        if isinstance(sink, str) and not sink.startswith(("sys.", "ext://")):
            # For file sinks, we need to pass rotation/retention/compression differently
            logger.add(
                sink=sink,
                **standard_params,
                rotation=handler_config.rotation,
                retention=handler_config.retention,
                compression=handler_config.compression
            )
        else:
            # For non-file sinks, don't pass file-specific parameters
            logger.add(
                sink=sink,
                **standard_params
            )

    for logger_name in LOGGERS:
        logging_logger = logging.getLogger(logger_name)
        logging_logger.handlers = []
        logging_logger.propagate = True
    
    # Set the global log level
    logger.level(config.level)
    
    # Mark as configured
    _LOGGER_CONFIGURED = True
    
    logger.info(f"Logger configured with level {config.level}")

def get_logger(name: str):
    """
    Get a logger with the specified name.
    
    If the logger hasn't been configured yet, it will be configured
    with default settings.
    
    Args:
        name: The name of the logger
        
    Returns:
        A configured logger instance
    """
    # Ensure logger is configured
    if not _LOGGER_CONFIGURED:
        configure_logger()
        
    return logger.bind(name=name)
