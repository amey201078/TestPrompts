"""
Configuration settings for the code analyzer.
"""

import os
import copy
import sys
import importlib.resources
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, Tuple, MutableMapping, Callable

import yaml
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource

# Define the type for settings source callables
SettingsSourceCallable = Callable[[Type[BaseSettings]], Dict[str, Any]]

class BaseAnalyzerSettings(BaseSettings):
    """Base class for all analyzer settings."""
    
    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }
    
    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> Tuple[PydanticBaseSettingsSource, ...]:
        section_name = getattr(cls, "config_section", None)
        
        # Create a custom settings source for YAML config
        class YamlConfigSettingsSource(PydanticBaseSettingsSource):
            def get_field_value(self, field_name: str, field_info: Any) -> Any:
                config = yaml_settings_source(settings_cls)
                if section_name and section_name in config:
                    config = config[section_name]
                return config.get(field_name, None)
                
            def prepare_field_value(self, field_name: str, field_info: Any, value: Any) -> Any:
                return value
                
            def __call__(self) -> Dict[str, Any]:
                config = yaml_settings_source(settings_cls)
                if section_name and section_name in config:
                    return config[section_name]
                return config
        
        return (
            init_settings,
            YamlConfigSettingsSource(settings_cls),
            env_settings,
            dotenv_settings,
            file_secret_settings,
        )

def extract_section(config: Dict[str, Any], section_name: Optional[str] = None) -> Dict[str, Any]:
    """
    Extract a specific section from the configuration.
    
    Args:
        config: The configuration dictionary
        section_name: The name of the section to extract (if None, returns the entire config)
        
    Returns:
        The extracted section configuration or the original config if section not found
    """
    if section_name is not None and section_name in config:
        return config[section_name]
    return config

def merge_lists_by_id(
    base_list: List[Any],
    override_list: List[Any],
    id_key: str = "id"
) -> List[Any]:
    """
    Merge two lists of dicts by matching on `id_key`. 
    - Dicts with the same id are replaced by override.
    - Items without id_key (or non-dicts) from base_list are preserved in order.
    - New items from override_list without matching id are appended at end.
    """
    # Map existing dict-items by id
    id_to_item: Dict[Any, Dict] = {}
    preserved: List[Any] = []
    for item in base_list:
        if isinstance(item, dict) and id_key in item:
            id_to_item[item[id_key]] = item
        else:
            preserved.append(item)

    # Apply overrides and collect new non-id items
    new_items: List[Any] = []
    for item in override_list:
        if isinstance(item, dict) and id_key in item:
            id_to_item[item[id_key]] = item
        else:
            new_items.append(item)

    # Reconstruct: preserved originals, then all id’d items in original insertion order,
    # then new non-id items at end
    merged = preserved + list(id_to_item.values()) + new_items
    return merged

def deep_merge(
    base: MutableMapping[str, Any],
    override: MutableMapping[str, Any],
    list_id_key: str = "id"
) -> Dict[str, Any]:
    """
    Recursively deep-merge two dicts. Lists of dicts merge via `merge_lists_by_id`.
    Other values in override replace base.
    """
    result = copy.deepcopy(base)
    for key, ov in override.items():
        if key in result:
            bv = result[key]
            if isinstance(bv, dict) and isinstance(ov, dict):
                result[key] = deep_merge(bv, ov, list_id_key)
            elif isinstance(bv, list) and isinstance(ov, list):
                result[key] = merge_lists_by_id(bv, ov, list_id_key)
            else:
                result[key] = ov
        else:
            result[key] = ov
    return result

# --- YAML loading ---

def load_yaml(path: Path) -> Dict[str, Any]:
    """
    Load a YAML file into a dictionary.
    
    Args:
        path: Path to the YAML file
        
    Returns:
        Dictionary containing the YAML content, or empty dict if loading fails
    """
    try:
        with path.open() as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        print(f"ERROR: Failed to parse YAML {path}: {e}", file=sys.stderr)
        return {}

def load_config_source(source: Path) -> Dict[str, Any]:
    """
    Load configuration from a file or directory of YAML files,
    merging them in sorted filename order.
    
    Args:
        source: Path to a YAML file or directory containing YAML files
        
    Returns:
        Dictionary containing the merged configuration
    """
    if not source.exists():
        print(f"DEBUG: No config at {source}", file=sys.stderr)
        return {}
    if source.is_file():
        return load_yaml(source)
    if source.is_dir():
        merged: Dict[str, Any] = {}
        for file in sorted(source.glob("*.yml")) + sorted(source.glob("*.yaml")):
            merged = deep_merge(merged, load_yaml(file))
        return merged
    print(f"WARNING: Ignoring unsupported config source: {source}", file=sys.stderr)
    return {}

# --- Pydantic Settings Source ---

# Get the config path using importlib.resources to avoid multiple parent directory navigation
def get_default_config_path() -> Path:
    """Get the default configuration directory path using importlib.resources."""
    try:
        # For Python 3.9+
        with importlib.resources.files('engineering_iq.static') as static_dir:
            return static_dir / 'config'
    except (ImportError, AttributeError):
        # Fallback for older Python versions
        import engineering_iq.static
        static_path = Path(engineering_iq.static.__file__).parent
        return static_path / 'config'

DEFAULT_CONFIG_PATH = get_default_config_path()
CWD = Path.cwd()
CWD_CONFIG_FILENAME = "config.yaml"
ENV_VAR_CONFIG_PATH = "CODE_ANALYZER_CONFIG_PATH"

def yaml_settings_source(
    settings_cls: Type[BaseSettings],
) -> Dict[str, Any]:

    final: Dict[str, Any] = {}

    # 1️⃣ Defaults
    final = deep_merge(final, load_config_source(DEFAULT_CONFIG_PATH))

    # 2️⃣ CWD
    final = deep_merge(final, load_config_source(CWD / CWD_CONFIG_FILENAME))

    # 3️⃣ Env var override
    env_path = os.getenv(ENV_VAR_CONFIG_PATH)
    if env_path:
        final = deep_merge(final, load_config_source(Path(env_path)))

    return final
