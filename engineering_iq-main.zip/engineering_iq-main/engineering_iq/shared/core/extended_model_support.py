import os
from typing import Union

from google.adk.models.lite_llm import LiteLlm, completion
from google.adk.models.base_llm import BaseLlm
from google.adk.models.registry import LLMRegistry
from google.adk.models.anthropic_llm import Claude

from google.genai import types

from litellm.types.utils import ModelResponse

from engineering_iq.shared.core.models.app_settings import app_settings
from engineering_iq.shared.core.logger import get_logger
from engineering_iq.shared.tools.file_tool import count_tokens

logger = get_logger(__name__)

LITELLM_MODEL_PREFIX: str = "LiteLlm:"
DEFAULT_MODEL = app_settings.default_model

LLMRegistry.register(Claude)

def get_model(model: Union[str, BaseLlm] = DEFAULT_MODEL) -> Union[str, BaseLlm]:
    """
    Get the model object for use within an ADK agent
    See: https://docs.litellm.ai/docs/providers for details
    Examples (str):
        - anthropic/claude-opus-4-20250514
        - bedrock/anthropic.claude-3-sonnet-20240229-v1:0
        - azure/<deployment_name>
    IMPORTANT: Set up your auth via credentials or environment vars for this to work.
    """

    if isinstance(model, BaseLlm):
        return model
    
    if model.startswith(LITELLM_MODEL_PREFIX):
        return LiteLlm(model=model[len(LITELLM_MODEL_PREFIX):])
    
    return model


def do_completion(prompt: str, model: Union[str, BaseLlm] = DEFAULT_MODEL) -> ModelResponse:
    """
    Handle a completion for a model and return the response.
    """

    return completion(
        model=get_model(model),
        messages=[{"role": "user", "content": prompt}],
        stream=False,
        api_key=os.environ["GOOGLE_API_KEY"]
    )

def do_str_completion(prompt: str, model: Union[str, BaseLlm] = DEFAULT_MODEL) -> str:
    """
    Handle a structured completion for a model and return the content as a string.
    """

    results = do_completion(
        prompt=prompt,
        model=model
    )

    try:
        return results.choices[0].message.content.strip()
    except (IndexError, AttributeError):
        return str(results.json())

async def summarize_content_objects(
    content_objects: list[types.Content], model_name: str
) -> types.Content:
    """
    Summarizes a list of Content objects into a single Content object.
    (e.g., calling an LLM to summarize the concatenated text).
    """
    logger.info(f"Summarizing {len(content_objects)} Content objects using model {model_name}.")
    all_text_parts = []
    for content_obj in content_objects:
        for part in content_obj.parts:
            if part.text:
                all_text_parts.append(part.text)
            if part.function_response:
                all_text_parts.append(part.function_response.model_dump_json())

    if not all_text_parts:
        summarized_text = "Summarized Content: No textual input found to summarize."
    else:
        summarized_text = do_str_completion(
            model=model_name,
            prompt=app_settings.summarize_context_prompt.format(conversation_segment="\n".join(all_text_parts)),
        )

    role = 'user' 
    if content_objects and content_objects[0].role:
        role = content_objects[0].role

    new_summarized_part = types.Part(text=summarized_text)
    new_summarized_content_object = types.Content(role=role, parts=[new_summarized_part])
    
    try:
        original_tokens = sum(
            count_tokens(part.text, model_name)
            for obj in content_objects
            for part in obj.parts if part.text
        )
        summary_tokens = count_tokens(new_summarized_part.text, model_name)
        logger.info(f"Original text parts tokens (approx): {original_tokens}, Summarized part tokens (approx): {summary_tokens}.")
    except Exception as e:
        logger.warning(f"Could not calculate token counts for logging: {e}")

    return new_summarized_content_object