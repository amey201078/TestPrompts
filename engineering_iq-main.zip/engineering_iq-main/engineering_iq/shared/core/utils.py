import functools
import inspect
from typing import Callable, Any, Dict

from google.adk.tools.tool_context import ToolContext

from engineering_iq.shared.core.logger import get_logger

FAILURES_ARTIFACT_KEY = "user:failures"

logger = get_logger(__name__)

class ContextExecutionException(Exception):
    """Custom exception for errors during context execution."""

def create_validated_function_wrapper(original_func: Callable, new_name: str | None = None) -> Callable:
    """
    Creates a wrapper around a Python function to add validation, error handling,
    and optionally rename the function.

    Args:
        original_func: The function to wrap.
        new_name: An optional new name for the wrapped function.
                  This will be used for its __name__ attribute and in logging/errors.
    """
    
    effective_display_name = new_name if new_name is not None else original_func.__name__

    @functools.wraps(original_func)
    def wrapper(*args: Any, **kwargs: Any) -> Dict[str, Any]:
        tool_context_arg: ToolContext | None = None
        
        # Attempt to find ToolContext if the original function expects it
        param_signature = inspect.signature(original_func)
        original_func_param_names = list(param_signature.parameters.keys())

        if 'tool_context' in original_func_param_names:
            # 1. Check keyword arguments
            if 'tool_context' in kwargs and isinstance(kwargs['tool_context'], ToolContext):
                tool_context_arg = kwargs['tool_context']
            else:
                # 2. Check positional arguments by matching signature
                try:
                    tool_context_param_index = original_func_param_names.index('tool_context')
                    if tool_context_param_index < len(args) and isinstance(args[tool_context_param_index], ToolContext):
                        tool_context_arg = args[tool_context_param_index]
                except ValueError:
                    # Should not happen if 'tool_context' is in original_func_param_names
                    pass
        
        logger.debug(f"--- Wrapped Tool: {effective_display_name} called with args: {args}, kwargs: {kwargs} ---")

        try:
            result = original_func(*args, **kwargs)
            if isinstance(result, dict):
                if "status" not in result: # Add default status if tool didn't provide one
                    result["status"] = "success"
                return result
            else:
                # If the tool returned a non-dict, wrap it as ADK expects
                return {"status": "success", "result": result}

        except Exception as e:
            error_message = f"Error in tool '{effective_display_name}': {str(e)}"
            logger.error(error_message, exc_info=True) # Added exc_info=True for full traceback
            if tool_context_arg and hasattr(tool_context_arg, 'actions') and hasattr(tool_context_arg.actions, 'skip_summarization'):
                tool_context_arg.actions.skip_summarization = True
            return {"status": "error", "error_message": error_message}
    
    if new_name is not None:
        wrapper.__name__ = new_name
        wrapper.__qualname__ = new_name

    return wrapper
