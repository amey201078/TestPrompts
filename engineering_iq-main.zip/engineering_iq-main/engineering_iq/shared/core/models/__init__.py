"""
Core data models for the code analyzer.
"""

from .logger_settings import LogHandlerConfig, LoggerSettings

__all__ = [
    'LogHandlerConfig',
    'LoggerSettings',
]
