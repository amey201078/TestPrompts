"""
App configuration models for the code analyzer.
"""

from typing import ClassVar, Optional
from pydantic import Field

from ..settings import BaseAnalyzerSettings

class AppSettings(BaseAnalyzerSettings):
    """Misc settings for the app."""

    config_section: ClassVar[str] = "app"

    git_dir: Optional[str] = Field(
        default=None,
        description="Directory for git operations. "
                    "If not set, the current working directory will be used.",
    )
    
    trace_lsp_communication: bool = Field(
        default=False,
        description="Enable tracing of LSP communication. "
                    "This is useful for debugging but may slow down the application.",
    )

    enable_lsp_tools: bool = Field(
        default=False,
        description="Enable LSP tools for code analysis.",
    )

    default_model: str = Field(
        default="gpt-4o",
        description="Default model to use for the app.",
    )

    default_max_tokens: int = Field(
        default=None,
        description="Default token limit for the app.",
    )

    default_merge_parameters: dict[str, str] = Field(
        default={},
        description="Default parameters for the merged prompt.",
    )

    summarize_context_prompt: str = Field(
        default=None,
        description="Prompt to use for summarizing context when hitting context limits.",
    )

    target_reduction_ratio: float = Field(
        default=0.5,
        description="Target ratio for token reduction, 0.5 = reduce by 50%"
    )

    default_tool_max_tokens: int = Field(
        default=12000,
        description="Default token limit for any tool to return.",
    )

    agent_retries: int = Field(
        default=3,
        description="Number of retries for agent execution in case of errors.",
    )

    context_size_error_message: str = Field(
        default="CONTEXT_WINDOW_EXCEEDED_ERROR: Current token size of memory and context.",
        description="Context window exceeded error message"
    )
    
    model_config = {
        **BaseAnalyzerSettings.model_config,
        "env_prefix": "APP_",
        "populate_by_name": True,  # Allow population by field name or alias
    }

app_settings = AppSettings()
