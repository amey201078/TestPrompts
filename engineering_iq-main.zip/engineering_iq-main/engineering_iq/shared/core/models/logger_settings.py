"""
Logger configuration models for the code analyzer.
"""

from typing import List, Optional, ClassVar
from pydantic import BaseModel, Field

from ..settings import BaseAnalyzerSettings

class LogHandlerConfig(BaseModel):
    """Configuration for a log handler."""
    sink: str = "stdout"
    level: str = "INFO"
    format: str = "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    colorize: bool = True
    rotation: Optional[str] = None
    retention: Optional[str] = None
    compression: Optional[str] = None
    enqueue: bool = False
    serialize: bool = False
    backtrace: bool = True
    diagnose: bool = True
    catch: bool = True

class LoggerSettings(BaseAnalyzerSettings):
    """Configuration for the logger."""
    config_section: ClassVar[str] = "logger"
    level: str = "INFO"
    handlers: List[LogHandlerConfig] = Field(default_factory=lambda: [LogHandlerConfig()])

    model_config = {
        **BaseAnalyzerSettings.model_config,
        "env_prefix": "LOGGER_",
    }

logger_settings = LoggerSettings()