"""
Engineering IQ CLI - Main command line interface
"""
import typer
from typing import Optional

# Import the dev_server functionality
from engineering_iq.shared.mcp.dev_server import main as dev_server_main

app = typer.Typer(
    name="engineering_iq",
    help="🚀 Engineering IQ - Your Agentic Engineering Team",
    add_completion=False,
    rich_markup_mode="rich"
)

# Add the dev_server as a subcommand
app.command("dev_server", help="🖥️  Start the MCP development server")(dev_server_main)

# Also add it as 'server' for shorter command
app.command("server", help="🖥️  Start the MCP development server (alias for dev_server)")(dev_server_main)

@app.command("web", help="🌐 Start the ADK web interface for agent testing")
def web_interface(
    port: int = typer.Option(8080, "--port", "-p", help="Port to run the web interface on"),
    host: str = typer.Option("localhost", "--host", "-h", help="Host to bind the web interface to")
) -> None:
    """
    🌐 Start the ADK Web Interface
    
    Launches the Google ADK web interface for testing and interacting
    with Engineering IQ agents in a browser-based environment.
    """
    import subprocess
    import os
    
    # Change to the project directory
    project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    agents_path = os.path.join(project_dir, "engineering_iq", "shared", "agents")
    
    typer.echo(f"🌐 Starting ADK Web Interface...")
    typer.echo(f"   Agents Path: {agents_path}")
    typer.echo(f"   Host: {host}")
    typer.echo(f"   Port: {port}")
    typer.echo("")
    
    try:
        # Run the adk web command
        cmd = ["adk", "web", agents_path, "--host", host, "--port", str(port)]
        typer.echo(f"Executing: {' '.join(cmd)}")
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Error running ADK web interface: {e}")
        raise typer.Exit(1)
    except FileNotFoundError:
        typer.echo("❌ Error: 'adk' command not found. Make sure Google ADK is installed.")
        typer.echo("   Run: pip install google-adk")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        typer.echo("\n🛑 Web interface stopped by user")

def main():
    """Main entry point for the engineering_iq CLI"""
    app()

if __name__ == "__main__":
    main()
