# Engineering IQ: Your AI-Powered Engineering Analysis Platform

## 🚀 Transform How You Understand and Document Code

Engineering IQ is an intelligent platform that automates comprehensive codebase analysis, documentation generation, and technical assessment. Using a team of specialized AI agents built with Google's Agent Development Kit (ADK), it provides deep insights that would typically take weeks of manual effort in just hours.

### Who Is This For?
- **Development Teams** - Quickly understand unfamiliar codebases and generate documentation
- **Technical Leads** - Assess technical debt and plan refactoring efforts
- **Architects** - Analyze system design and identify improvement opportunities
- **Product Managers** - Get clear technical insights for planning and decision-making
- **Consultants** - Perform rapid technical due diligence and assessments

### What Makes Engineering IQ Different?
- **Multi-Agent Architecture** - Specialized agents work together like an engineering team
- **Comprehensive Analysis** - Goes beyond code metrics to understand business logic and architecture
- **Actionable Insights** - Generates specific recommendations, not just observations
- **Customizable Workflows** - Adapt analysis to your specific needs and domains
- **Enterprise Ready** - Integrates with Jira, supports multiple AI models, handles large codebases

## 📚 Documentation

**[Complete Documentation](docs/README.md)** - Comprehensive guides and references

### Quick Links
- [Installation Guide](docs/INSTALLATION.md)
- [Configuration Guide](docs/CONFIGURATION.md)
- [Agents Reference](docs/AGENTS.md)
- [Workflows](docs/WORKFLOWS.md)
- [Analysis Reports Guide](docs/ANALYSIS_REPORTS.md)
- [Best Practices](docs/BEST_PRACTICES.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)

## 🎯 Why Engineering IQ?

### Problems We Solve

**❌ Without Engineering IQ:**
- Weeks spent manually reviewing code to understand a system
- Inconsistent documentation that's always out of date
- Technical debt hidden until it causes problems
- Difficult to assess impact of proposed changes
- Knowledge silos when team members leave

**✅ With Engineering IQ:**
- Automated analysis generates comprehensive reports in hours
- Consistent, detailed documentation for any codebase
- Proactive identification of technical debt and risks
- Clear impact analysis for new features
- Preserved institutional knowledge

### Real Value Delivered
- **80% Time Reduction** in codebase onboarding
- **Comprehensive Documentation** that stays current
- **Risk Identification** before they become issues
- **Data-Driven Decisions** based on thorough analysis
- **Knowledge Preservation** across team changes

## 🛠️ Key Capabilities

### 🔍 Deep Code Analysis
- Architecture patterns and design analysis
- Code quality and maintainability assessment
- Security vulnerability identification
- Performance bottleneck detection
- Technical debt quantification

### 📊 Intelligent Reporting
- Business requirements documentation
- Technical architecture diagrams
- Test strategy and coverage analysis
- Feature impact assessments
- Executive summaries with actionable insights

### 🤖 AI-Powered Features
- Multi-model support (Google, Anthropic, OpenAI)
- Smart memory management for large codebases
- Natural language requirement clarification
- Automated Jira ticket creation
- Custom analysis workflows

### 💡 IDE-Like Code Intelligence (LSP Tools)
Engineering IQ's unique Language Server Protocol (LSP) integration gives agents capabilities similar to modern IDEs:

- **Symbol Navigation** - Jump to definitions, find references, understand inheritance
- **Context-Aware Analysis** - Understand code relationships and dependencies
- **Semantic Understanding** - Go beyond text matching to understand code meaning
- **Cross-File Intelligence** - Track how changes ripple through the codebase
- **Type-Aware Navigation** - Understand interfaces, implementations, and contracts

This means our agents don't just read code—they understand it like a developer using an IDE, enabling:
- Accurate impact analysis across files
- Understanding of complex inheritance hierarchies
- Detection of subtle dependencies
- Comprehensive refactoring recommendations

📖 **[Learn more about LSP Tools](docs/LSP_TOOLS.md)** - Deep dive into how LSP powers our analysis

### 🔧 Enterprise Integration
- Jira integration for task management
- Excel data processing and analysis
- Git repository management
- MCP server support for extensibility
- RESTful API for automation
- **CLI Tools** - Convenient command-line interface with shortcuts

### 🚀 CLI Tools
Engineering IQ provides a comprehensive CLI (defined in `pyproject.toml`) with convenient shortcuts:

```bash
# Web interface shortcuts
eiq web --port 8085                     # Start web interface (short)
engineering_iq web --port 8085          # Start web interface (full)

# MCP server shortcuts  
eiq server --port 8000                  # Start MCP server (short)
eiq dev_server --port 8000              # Start MCP server (full options)
engineering_iq server --port 8000       # Start MCP server (full command)

# All commands support help
eiq --help
eiq server --help
engineering_iq --help
```

## 🚀 Quick Start

### 1. Install Engineering IQ

```bash
pip install "engineering_iq @ git+https://techinnovation.accenture.com/software-engineering-generative-ai/engineering_iq.git"
```

### 2. Configure Your Environment

Create a `config.yaml` file:

```yaml
app:
  default_model: gemini-2.0-flash-exp  # or claude-3-5-sonnet-latest
  git_dir: workdir/repos
  
# Optional: Configure Jira integration
jira:
  url: https://your-domain.atlassian.net
  email: your-email@company.com
  api_token: your-api-token
```

### 3. Start the Interface

**Option A: Web Interface (Recommended)**
```bash
# Using Engineering IQ CLI shortcut
engineering_iq web --port 8085
```

**Option B: MCP Server (For MCP-compatible clients)**
```bash
# Start the MCP server
engineering_iq server --port 8000

# Or full command
engineering_iq dev_server --port 8000 --host localhost
```

### 4. Run Your First Analysis

Navigate to `http://localhost:8085` and try this workflow:

```
1. Git Helper → Clone repository
2. Product Analysis Planner → Create analysis plan
3. Product Analyzer → Generate business requirements report
```

## 👥 Meet Your AI Engineering Team

Engineering IQ employs four categories of specialized agents:

### 1. 📋 Analysis Planners
Create structured analysis plans tailored to your goals:
- **Product Analysis Planner** - Business and functional requirements
- **Dev Analysis Planner** - Technical architecture and code quality
- **DevSecOps Analysis Planner** - Security, infrastructure, and operational analysis
- **QE Analysis Planner** - Testing strategy and quality engineering
- **Feature Analysis Planner** - New feature impact assessment

### 2. 📈 Report Generators
Execute analysis plans and generate comprehensive reports:
- **Product Analyzer** - Business requirements documentation
- **Dev Analyzer** - Technical documentation and diagrams
- **DevSecOps Analyzer** - Security, infrastructure, and operational analysis
- **QE Analyzer** - Test strategies and coverage reports
- **Feature Analyzer** - Feature impact and implementation guides

### 3. 💬 Interactive Agents
Iterate with users to refine requirements:
- **Idea Iterator** - Clarifies vague requirements through structured Q&A
  - Transforms ideas into clear acceptance criteria
  - Identifies business outcomes and assumptions
  - Outputs structured markdown documents

### 4. 🔧 Utility Agents
Specialized tools for specific tasks:
- **Git Helper** - Repository cloning and management
- **File Helper** - Advanced file operations
- **Jira Helper** - Jira integration and ticket management
- **Diagrammer** - Architecture visualization
- **Search Agent** - Code and documentation search

## 📖 Common Use Cases

### 1. Onboarding to a New Codebase
```
Workflow: Git Helper → All Planners → All Analyzers
Result: Complete technical and business documentation
Time Saved: 2-3 weeks → 4-6 hours
```

### 2. Planning a Major Feature
```
Workflow: Idea Iterator → Feature Planner → Feature Analyzer
Result: Clear requirements, impact analysis, implementation plan
Time Saved: 1-2 weeks → 1-2 days
```

### 3. Technical Due Diligence
```
Workflow: Git Helper → Dev Planner → Dev Analyzer → Task Loader
Result: Comprehensive technical assessment with Jira tickets
Time Saved: 3-4 weeks → 1-2 days
```

### 4. Legacy System Documentation
```
Workflow: Full Analysis Pipeline
Result: Complete system documentation for maintenance/migration
Time Saved: 4-6 weeks → 2-3 days
```

### 5. Requirements Clarification
```
Workflow: Idea Iterator → Product Planner → Product Analyzer
Result: Clear acceptance criteria and business outcomes
Time Saved: Multiple meetings → Structured process
```

### 6. Security and Compliance Assessment
```
Workflow: Git Helper → DevSecOps Planner → DevSecOps Analyzer
Result: Security posture analysis, compliance gaps, infrastructure assessment
Time Saved: 2-3 weeks → 1-2 days
```

## 📊 Sample Report Output

Engineering IQ generates detailed, actionable reports. Here's what you can expect:

### Business Requirements Report
```markdown
# Product Analysis Report

## Executive Summary
- **Purpose**: E-commerce platform for B2B transactions
- **Key Features**: Order management, inventory tracking, payment processing
- **Users**: 3 personas identified (Admin, Buyer, Seller)
- **Integrations**: 5 external systems (Payment, Shipping, ERP, CRM, Analytics)

## Feature Catalog
### Order Management
- Create, update, and track orders
- Multi-stage approval workflow
- Bulk order processing
[... detailed analysis continues ...]
```

### Technical Architecture Report
```markdown
# Technical Analysis Report

## Architecture Overview
- **Pattern**: Microservices with API Gateway
- **Stack**: Node.js, React, PostgreSQL, Redis
- **Deployment**: Kubernetes on AWS

## Code Quality Metrics
- **Maintainability Index**: 72/100
- **Technical Debt**: 47 days estimated
- **Test Coverage**: 68%
[... detailed metrics and recommendations ...]
```

### DevSecOps Analysis Report
```markdown
# DevSecOps Analysis Report

## Security Posture Summary
- **Security Controls**: Spring Security with JWT authentication
- **Secrets Management**: Google Cloud Secret Manager integration
- **Container Security**: Distroless base images, non-root execution
- **Compliance Status**: Partial GDPR compliance, audit trail gaps identified

## Infrastructure Analysis
- **Deployment**: Kubernetes on GCP with auto-scaling
- **CI/CD Pipeline**: Maven-based with SonarQube integration
- **Monitoring**: Spring Boot Actuator + Prometheus metrics
- **Backup Strategy**: Automated GCP snapshots configured

## Identified Risks
- **High**: Hardcoded credentials in legacy config files
- **Medium**: Missing security headers in web responses  
- **Low**: Container image vulnerability scan not automated
[... detailed security analysis continues ...]
```

## 🔧 Advanced Configuration

### Multi-Model Support
```yaml
# Use different models for different agents
dev_analyst:
  model: claude-3-5-sonnet-latest  # Better for code analysis

product_analysis_planner:
  model: gemini-2.0-flash-exp  # Faster for planning
```

### Custom Analysis Sections
```yaml
# Add domain-specific analysis
product_analyzer:
  custom_sections:
    - compliance_requirements
    - accessibility_assessment
    - performance_benchmarks
```

### Memory Optimization
```yaml
# Configure for large codebases
app:
  memory_optimization: true
  chunk_size: 50000
  max_file_size: 10485760  # 10MB
```

## 🚦 Getting Started Guide

### For First-Time Users

1. **Start Small**: Begin with a small repository to understand the workflow
2. **Use Templates**: Start with provided configurations and customize later
3. **Review Plans**: Always review analysis plans before execution
4. **Iterate**: Use feedback to refine analysis approaches

### Best Practices

1. **Repository Preparation**
   - Ensure code is up-to-date
   - Include documentation files
   - Have test files available

2. **Choosing Agents**
   - Use Idea Iterator for unclear requirements
   - Run planners before analyzers
   - Combine multiple perspectives for comprehensive analysis

3. **Optimizing Results**
   - Provide context in your requests
   - Use custom sections for domain-specific needs
   - Review and refine generated plans

## 🛡️ Requirements

- Python 3.11+
- Google ADK
- Git
- 8GB+ RAM recommended
- SSD storage for better performance

## 🤝 Contributing

We welcome contributions! See our [Developer Notes](docs/DEVELOPER_NOTES.md) for guidelines.

### Development Setup

```bash
git clone https://techinnovation.accenture.com/software-engineering-generative-ai/engineering_iq.git
cd engineering_iq
pip install -e ".[dev]"
```

### Running Tests

```bash
pytest tests/
```

## 📄 License

[Your license information here]

## 💡 Support

- 📖 [Complete Documentation](docs/README.md)
- 🐛 [Troubleshooting Guide](docs/TROUBLESHOOTING.md)
- 💡 [Best Practices](docs/BEST_PRACTICES.md)
- 🔧 [Configuration Reference](docs/CONFIGURATION.md)

---

**Ready to revolutionize your code analysis?** Start with the [Installation Guide](docs/INSTALLATION.md) →
